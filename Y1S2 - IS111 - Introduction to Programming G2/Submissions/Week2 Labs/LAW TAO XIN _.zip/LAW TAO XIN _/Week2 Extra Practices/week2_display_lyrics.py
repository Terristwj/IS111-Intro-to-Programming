def display_lyrics():
    verse_number='first'
    first_line= f'On the {verse_number} of Christmas my true love sent to me'
    add_var= '\nA partridge in a pear tree'
    verse= first_line+add_var
    print(verse+'\n')
    
    verse_number='second'
    first_line= f'On the {verse_number} of Christmas my true love sent to me'
    add_var= '\nTwo turtle doves, and'+add_var
    verse= first_line+add_var
    print(verse+'\n')
    
    verse_number='third'
    first_line= f'On the {verse_number} of Christmas my true love sent to me'
    add_var= '\nThree French hens'+add_var
    verse= first_line+add_var
    print(verse+'\n')
    
    verse_number='fourth'
    first_line= f'On the {verse_number} of Christmas my true love sent to me'
    add_var= '\nFour colly birds'+add_var
    verse= first_line+add_var
    print(verse+'\n')
    
    verse_number='fifth'
    first_line= f'On the {verse_number} of Christmas my true love sent to me'
    add_var= '\nFive gold rings'+add_var
    verse= first_line+add_var
    print(verse+'\n')

    verse_number='sixth'
    first_line= f'On the {verse_number} of Christmas my true love sent to me'
    add_var= '\nSix geese a-laying'+add_var
    verse= first_line+add_var
    print(verse+'\n')

    verse_number='seventh'
    first_line= f'On the {verse_number} of Christmas my true love sent to me'
    add_var= '\nSeven swans a-swimming'+add_var
    verse= first_line+add_var
    print(verse+'\n')
    
    verse_number='eighth'
    first_line= f'On the {verse_number} of Christmas my true love sent to me'
    add_var= '\nEight maids a-milking'+add_var
    verse= first_line+add_var
    print(verse+'\n')
    
    verse_number='nineth'
    first_line= f'On the {verse_number} of Christmas my true love sent to me'
    add_var= '\nNine ladies dancing'+add_var
    verse= first_line+add_var
    print(verse+'\n')
    
    verse_number='tenth'
    first_line= f'On the {verse_number} of Christmas my true love sent to me'
    add_var= '\nTen lords a-leaping'+add_var
    verse= first_line+add_var
    print(verse+'\n')
    
    verse_number='eleventh'
    first_line= f'On the {verse_number} of Christmas my true love sent to me'
    add_var= '\nEleven pipers piping'+add_var
    verse= first_line+add_var
    print(verse+'\n')

    verse_number='twelfth'
    first_line= f'On the {verse_number} of Christmas my true love sent to me'
    add_var= '\nTwelve drummers drumming'+add_var
    verse= first_line+add_var
    print(verse+'\n')
    
display_lyrics()