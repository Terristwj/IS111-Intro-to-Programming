# Name: Loh Zhen Sheng Sean
# Email ID: sean.loh.2020@accountancy.smu.edu.sg
def get_ppl_with_fever(ppl_list):

    # Modify the code below.
    if len(ppl_list) == 0:
        return []
    
    fever_list = []
    
    for info in ppl_list:
        name, temp_list = info
        
        temp_sum = 0
        for temp in temp_list:
            temp_sum += temp
        avg_temp = temp_sum / len(temp_list)
        
        if avg_temp > 37.5:
            fever_list.append(name)
    
    return fever_list

