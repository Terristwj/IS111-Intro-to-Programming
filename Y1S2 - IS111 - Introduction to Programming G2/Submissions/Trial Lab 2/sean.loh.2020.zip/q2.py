# Name: Loh Zhen Sheng Sean
# Email ID: sean.loh.2020@accountancy.smu.edu.sg
def process_numbers(given_file, result_file):
    # Modify the code below.
    with open (result_file, 'w') as output_file:
        with open (given_file, 'r') as input_file:
            for line in input_file:
                num_list = line.rstrip('\n').split('*')
                num_of_groups = len(num_list)
                
                maxnum_list = []
                for group in num_list:
                    groupnum_list = group.split()
                    if len(groupnum_list) == 0:
                        max_num = "NA"
                    else:
                        max_num = groupnum_list[0]
                        for num in groupnum_list:
                            if int(num) > int(max_num):
                                max_num = num
                    maxnum_list.append(max_num)
                
                final_output = ""
                for element in maxnum_list:
                    if len(final_output) == 0:
                        final_output += str(element)
                    else:
                        final_output = final_output + "*" + str(element) 
                
                output_file.write(str(num_of_groups) + ": " + str(final_output) + "\n")
    


