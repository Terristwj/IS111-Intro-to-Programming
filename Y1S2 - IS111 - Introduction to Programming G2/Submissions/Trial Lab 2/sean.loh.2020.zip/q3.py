# Name: Loh Zhen Sheng Sean
# Email ID: sean.loh.2020@accountancy.smu.edu.sg
def create_email_dict(email_list):
    # Modify the code below.
    email_dict = {}
    for email in email_list:
        to_ignore = False
        email_id, domain = email.split('@')
        domain_info = domain.split('.')
        if domain_info[0] == "smu":
            to_ignore = True
        
        contain_num = False
        for char in email_id:
            if char in '1234567890':
                contain_num = True
        
        if contain_num == False:
            to_ignore = True
        
        if to_ignore == False:
            id_info = email_id.split('.')
            email_key = domain_info[0] + '-' + id_info[len(id_info)-1]
            if email_key not in email_dict:
                email_dict[email_key] = [email]
            else:
                list_to_append = email_dict[email_key]
                list_to_append.append(email)
    
    return email_dict
    

    
