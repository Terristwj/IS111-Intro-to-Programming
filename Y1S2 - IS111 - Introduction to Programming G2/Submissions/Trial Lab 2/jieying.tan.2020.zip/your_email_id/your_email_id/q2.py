# Name: Tan Jie Ying
# Email ID: jieying.tan.2020
def process_numbers(input_filename, output_filename):
    
    # Modify the code below.
    
    # open the input file 
    with open (input_filename, "r") as my_file:
        # open the output file
        with open (output_filename, "w") as output_file:
        
            # using a for-loop, go thru each line in the input file
            for line in my_file:
                # separate the groups in each line using .split("*")
                line = line.rstrip("\n")
                grp_in_line = line.split("*")
                
                # count the number of groups
                num_of_grps = len(grp_in_line)
                              
                # for each groups
                for indi_grp in grp_in_line:
                    
                    result_for_line = ""
                    
                    # if grp is not empty:
                    if indi_grp != "":
                        # max_num = first num
                        max_num = indi_grp[0]
                        
                        # for each num in the grp
                        for num_in_grp in indi_grp:
                            # then go thru subsequent num, compare to get the largest number 
                            # if num > max_num, update max_num
                            if num_in_grp > max_num:
                                max_num = num_in_grp
                        return max_num 
                    
                    # if grp is empty:
                    elif indi_grp == "":
                        # return NA
                        max_num = "NA"
                        return max_num
                
                    result_for_line = max_num + "*"
                    return result_for_line
                
                result_for_line = result_for_line[:-1]
                return num_of_grps, result_for_line
                
            # print the results accordingly into output_file
            output_file.write(num_of_grps + ": " + result_for_line)
    


