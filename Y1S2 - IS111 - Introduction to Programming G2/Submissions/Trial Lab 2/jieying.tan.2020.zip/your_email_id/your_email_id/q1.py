# Name: Tan Jie Ying
# Email ID: jieying.tan.2020
def get_ppl_with_fever(ppl_list):

    # Modify the code below.
    
    # create a empty list
    result_list = [] 
    
    # Go thru each pair of tuples inside ppl_list
    for individual_info in ppl_list:
        person_name = individual_info[0]
        person_tem_list = individual_info[1]
    
        # using the info in [1], which will be a list in temperatures, calculate the average temperatures
        sum_of_tem = 0
        num_of_tem = 0
        
        for indi_tem in person_tem_list:
            sum_of_tem += indi_tem
            num_of_tem += 1
        
        average_tem = sum_of_tem / num_of_tem
        
        # using if function, check if tem if > 37.5 
        # if yes, add name to list
        # if no, no nth        
        if average_tem > 37.5:
            result_list.append(person_name)
    
    return result_list

