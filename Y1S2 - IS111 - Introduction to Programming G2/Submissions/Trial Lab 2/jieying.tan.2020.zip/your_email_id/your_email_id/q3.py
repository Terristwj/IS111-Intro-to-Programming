# Name:
# Email ID:
def create_email_dict(email_list):
    # Modify the code below.
    return None
    

    
