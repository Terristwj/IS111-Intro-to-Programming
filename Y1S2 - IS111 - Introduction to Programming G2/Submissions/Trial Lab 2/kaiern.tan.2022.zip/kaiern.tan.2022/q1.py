# Name: Tan Kai Ern
# Email ID:kaiern.tan.2022

def average_temp(list):
    total=0
    divisor=len(list)
    for temp in list:
        total+=temp
    return total/divisor
        

def get_ppl_with_fever(ppl_list):
    fever_list=[]
    if ppl_list==[]:
        return fever_list
    else:
        for tuple in ppl_list:
            name=tuple[0]
            templist=tuple[1]
            avg=average_temp(templist)
            if avg>37.5:
                fever_list.append(name)
        return fever_list
            
    

    # Modify the code below.
 

