# Name: Tan Kai Ern
# Email ID:kaiern.tan.2022

def staffchecker(email):
    nos='1234567890'
    if nos in email:
        return True
    else:
        return False
 
 def findindex(email):
    for i in range(len(email)):
        if email[i]=='@':
        return i
                                  

def create_email_dict(email_list):
    returndict{}
    for email in emaillist:
        check=staffchecker(email)
        if staffchecker(email)==False
            divide=email.split(@)
            nameyear=divide[0]
            school=divide[1]

    
    
    
    
    
    
    
    
    
    
    
    return returndict
    
    

    
