# Name: Tan Kai Ern
# Email ID:kaiern.tan.2022

def convert_group_to_list(group):
    nolist=[]
    if group=='':
        return nolist
        
    number=group.split(' ')
    for number in group
        nolist.append(number)
    return nolist
    

def find_max_in_group(list):
    max=0
    if len(list)==0
        return 'NA'
    for i in list:
        if i>max:
            max=i
    return max
   
 def maxlist(groupslist):
    maxlist=[]
    for group in groups:
        max=find_max_in_group(list)
        maxlist.append(max)
    return maxlist
   
 def get_grouplists(input_filename):
     with open (input_filename, 'r') as myfile:
        groupslist=[]
        for line in myfile:
            line=line.rstrip('\n')
            groups=line.split('*')
            for groups in line:
                grouplist=convert_group_to_list(group)
                groupslist.append(grouplist)
        return groupslist
          

def process_numbers(input_filename, output_filename):
    grouplists=get_grouplists(input_filename)
    maxs=maxlist(groupslist)
    message=''
    with open (output_filename, 'w') as outfile:
         for i in range(len(maxs)):
            message+=(str(i)+'*')
        editedmessage=message[::-1]
        outfile.write(editedmessage)
        
         
         


        
            
                
    


