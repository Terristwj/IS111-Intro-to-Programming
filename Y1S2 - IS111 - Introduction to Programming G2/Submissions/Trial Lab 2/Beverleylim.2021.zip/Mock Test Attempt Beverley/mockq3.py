# -*- coding: utf-8 -*-
"""
Created on Fri Mar 31 09:49:21 2023

@author: Verle
"""
#Beverley Lim


def create_email_dict():
    