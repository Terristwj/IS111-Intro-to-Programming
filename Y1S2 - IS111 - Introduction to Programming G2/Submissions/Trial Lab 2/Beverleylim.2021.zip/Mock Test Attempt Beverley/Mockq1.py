# -*- coding: utf-8 -*-
"""
Created on Fri Mar 31 09:28:21 2023

@author: Verle
"""
#Beverley Lim


def get_ppl_with_fever(name, temperature):
    if temperature == 0:
        return []
    elif temperature >= 37.5:
        return name

get_ppl_with_fever('John', 38.5)

    

