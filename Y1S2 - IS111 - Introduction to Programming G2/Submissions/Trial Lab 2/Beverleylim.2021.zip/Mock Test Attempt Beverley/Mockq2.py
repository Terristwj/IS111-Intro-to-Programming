# -*- coding: utf-8 -*-
"""
Created on Fri Mar 31 09:41:13 2023

@author: Verle
"""
#Beverley Lim

#full_name = input('What is your file?')
#file_split = len(full_name.split('*'))
#print(full_name.split('*'))
#print(file_split ,': ', full_name)
def process_numbers():
    full_name = input('What is your file?')
    file_split = len(full_name.split('*'))
    if file_split == 0:
        print('NA')
    else:
        #x = '**'
        #for x in full_name:
         #   print('NA')
        print(file_split ,': ', full_name)
        
process_numbers()