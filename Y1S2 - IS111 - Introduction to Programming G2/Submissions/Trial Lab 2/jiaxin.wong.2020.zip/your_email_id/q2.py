# Name: Wong Jia Xin
# Email ID: jiaxin.wong.2020
def process_numbers(input_filename, output_filename):
    # Modify the code below.
    
    with open(input_filename, 'r') as input_file:
        output_list = []
        for line in input_file:
            line = line.rstrip('\n')
            list_of_groups = line.split('*')
            no_of_groups = len(list_of_groups)
            
            list_largest_num = []
            for group in list_of_groups:
                if group == '':
                    list_largest_num.append("NA")
                else:
                    largest_num = -1000000000
                    nums = group.split()
                    for num in nums:
                        if int(num) > largest_num:
                            largest_num = int(num)
                    list_largest_num.append(largest_num)

                    largest_num_str = ''
                    for i in list_largest_num:
                        largest_num_str += str(i) + "*"
                        to_return = largest_num_str[:-1]

            to_print = str(no_of_groups) + ": " + to_return + '\n'
            output_list.append(to_print)
            
            
    with open(output_filename, 'w') as output_file:
        for i in output_list:
            output_file.write(i)
    


