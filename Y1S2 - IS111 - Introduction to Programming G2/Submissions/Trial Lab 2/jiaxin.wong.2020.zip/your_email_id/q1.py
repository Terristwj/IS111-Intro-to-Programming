# Name: Wong Jia Xin
# Email ID: jiaxin.wong.2020
def get_ppl_with_fever(ppl_list):

    # Modify the code below.
    if ppl_list == []:
        return []
    else:
        output_list = []
        for person in ppl_list:
            name = person[0]
            temp_list = person[1]
            running_sum = 0
            for temp in temp_list:
                running_sum += temp
            avg_temp = running_sum / len(temp_list)
            if avg_temp > 37.5:
                output_list.append(name)
        
        return output_list
                

