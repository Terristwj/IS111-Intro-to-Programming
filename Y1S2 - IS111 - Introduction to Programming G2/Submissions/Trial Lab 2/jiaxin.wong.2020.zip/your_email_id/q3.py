# Name: Wong Jia Xin
# Email ID: jiaxin.wong.2020
def create_email_dict(email_list):
    # Modify the code below.
    
    # create dict
    # iterate through all emails in email list and retrieve those that are valid
    # create a list before that, and append these emails to valid_emails_list
    # to check through spliting each email at @, with two conditions
    # condition 1: check if the part after @ is smu.edu.sg >> if yes, do not append
    # condition 2: check if last 4 ch of the part before @ is a year >> if no, do not append
    
    # to then iterate through list of valid emails
    # find position of @
    # year = position indexes of the four indexes before position of @
    # school >> to split 2nd part of email after @ through '.', and retrieve first index
    # create key, add it to dict if it's unique, and add values through in function
    
    email_dict = {}
    
    student_proper_emails = []
    for email in email_list:
        parts = email.split('@')
        email_id = parts[0]
        domain = parts[1]
        parts_of_email_id = email_id.split('.')
        if len(parts_of_email_id[-1]) == 4 and domain != 'smu.edu.sg':
            student_proper_emails.append(email)
    
    unique_keys = []
    for i in student_proper_emails:
        position_at = i.find('@')
        year = i[position_at - 4 : position_at]
        parts = i.split('@')
        part2 = parts.split('.')
        sch = part2[0]
        key = sch + '-' + year
        if key not in unique_keys:
            unique_keys.append(key)
    
    
    
    return None
    

    
