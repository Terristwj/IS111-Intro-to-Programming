# Name:Zhang Yaowen
# Email ID:ywzhang.2021
def get_ppl_with_fever(ppl_list):

    # Modify the code below.
    
    #create a empty string:
    string_return = []
    #first we need to separate the name and the temperature
    for element in ppl_list:
        name = element[0]
        temperature = element[1]  
    #we find the average temperature
    #create a dummy call total_temp for later use to find average_temp
    total_temp = 0
    #create a dummy call average_temp to store average_temp
    average_temp = 0
    for tem in temperature:
        total_temp += int(tem)
        average_temp = int(total_temp)/len(temperature) 
    #if average temperature is higher than 37.5, we print the name
        if average_temp > 37.5:
            string_return.append(name)
    return string_return

