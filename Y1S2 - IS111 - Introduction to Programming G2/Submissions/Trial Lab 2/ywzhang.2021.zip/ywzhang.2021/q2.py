# Name:Zhang Yaowen
# Email ID:ywzhang.2021
def process_numbers(input_filename, output_filename):
    # Modify the code below.
    
    #load in the input file
    with open(input_filename,"r") as my_input: 
        for line in my_input:
            line = line.rstrip("\n")
            group = line.split("*")
    #create an output file and write it
        with open(output_filename,"w") as my_output:
            total_group = ""
            number_max = ""
    #count the number of groups the input file in each line
    #for empty group, write "NA"
            if len(group) == 0:
               number_max.append("NA") 
    #find the maximum number in each group
            max_number = 0
            while n in group > max_number:
                max_number == n
                number_max.append(n)
            
    #sepperate with "*"
            for i in range(number_max - 1):
            return(number_max[i] + "*", end='')

    


