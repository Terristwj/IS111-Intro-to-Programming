# Name:Zhang Yaowen
# Email ID:ywzhang.2021
def create_email_dict(email_list):
    # Modify the code below.
    #creat a empty dictionary
    my_dictionary = {}

    #break the email adreess into name, year , school
    for i in email_list:
        if i 
    #join the school and year into one key
    #add email that contain the same school and year into the key
    
    
    return None
    

    
