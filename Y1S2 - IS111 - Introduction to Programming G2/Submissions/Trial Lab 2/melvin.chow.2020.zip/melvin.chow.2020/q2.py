# Name: Melvin Chow Jia Le
# Email ID: melvin.chow.2020
def process_numbers(input_filename, output_filename):
    # Modify the code below.
    my_dict = {}
    with open(input_filename, 'r') as input: 
        for line in input: 
            columns = line.split('*')
            count = 0 
            my_dict[count] = []
            max_number_list = []
            for column in columns:
                count+=1
                sub_column = column.split(' ')
                num_list = []
                max_number = 0
                for number in sub_column: 
                    num_list.append(number)
                    if number == "": 
                        pass
                    elif float(number) > float(max_number): 
                        max_number = number
                max_number_list.append(max_number)
            my_dict[count] = max_number_list

    with open('output_filename', 'w') as output: 
        for key in my_dict: 
            output = ""
            output += str(key) + ": "
            for values in my_dict[key]: 
                if values == 0: 
                    output+= "*" + "NA"
                else: 
                    output+= "*" + str(values)

    return None
    


