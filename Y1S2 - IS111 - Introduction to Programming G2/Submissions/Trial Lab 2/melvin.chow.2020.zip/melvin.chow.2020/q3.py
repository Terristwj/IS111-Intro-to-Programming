# Name:melvin 
# Email ID:melvin.chow.2020
def create_email_dict(email_list):
    # Modify the code below.
    result_keys = []
    result_dict = {}
    for email in email_list: 
        school_year = ""
        columns = email.split('@')
        sub_column = columns[1].split('.')
        sub_column_count = 0 
        for element in sub_column:
            sub_column_count +=1
        if sub_column_count == 4: 
            school = sub_column[0]
            year = columns[1]
            school_year = school + "-" + year 
        else: 
            year = columns[1] 

        if school_year not in result_keys: 
            result_keys.append(school_year)

    for keys in result_keys: 
        values = [] 
        for email in email_list: 
            columns = email.split('@')
            sub_column = columns[1].split('.')
            if keys.split("-")[1] == columns[1] and keys.split("-")[0] == columns[0]:
                values.append(email)
        result_dict[keys] = values

    return result_dict
    

    
