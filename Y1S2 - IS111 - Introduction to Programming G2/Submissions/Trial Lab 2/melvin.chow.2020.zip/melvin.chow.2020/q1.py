# Name: Melvin Chow Jia Le
# Email ID: melvin.chow.2020
def get_ppl_with_fever(ppl_list):
    fever_list = []
    for person in ppl_list: 
        sum = 0
        count = 0
        for temperature in person[1]: 
            sum += temperature
            count += 1
        temp_average = sum/count 

        if temp_average > 37.5: 
            fever_list.append(person[0])
    return fever_list
    