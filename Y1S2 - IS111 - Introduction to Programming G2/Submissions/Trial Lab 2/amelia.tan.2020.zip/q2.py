# Name: TAN CHOR TENG AMELIA
# Email ID: amelia.tan.2020
def process_numbers(input_filename, output_filename):
    # Modify the code below.
    with open (input_filename, "r") as input, open (output_filename, "w") as output:    
        for line in input_filename: 
            by_group = line.strip('')
            by_numbers = by_group.split('*')
            total_groups = len(by_group)
            count = len(by_numbers)
        return (total_groups, by_numbers)
        for no in by_group: 
            length = len(by_numbers)
            big = max(length)
            if big >= 0: 
                output_filename.write(total_group, by_group )
    return None
    


