# Name: TAN CHOR TENG AMELIA
# Email ID: amelia.tan.2020
def get_ppl_with_fever(ppl_list):
    ppl_list= [name, temperatures] 
    name = ppl_list[0]
    while temperatures in ppl_list [1]: 
        average_temp = sum(temperatures) / len(temperatures)
        return (name, average_temp)
        if average_temp >= 37.5:
            ppl_list += ppl_list.append

    # Modify the code below.
    return None

