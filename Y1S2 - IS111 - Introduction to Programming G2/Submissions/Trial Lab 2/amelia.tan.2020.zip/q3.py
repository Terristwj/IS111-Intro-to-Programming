# Name: TAN CHOR TENG AMELIA
# Email ID: amelia.tan.2020

email_dict = {}
school = ()

def create_email_dict(email_list):
    # Modify the code below.
    for line in email_list:
        emailid , domain = line.strip('').split('@')
        school = domain.strip('.smu.edu.sg')
        year = emailid.strip('.').split(' ')
        email_dict[emailid] = domain
        if (school in domain) and (year in emailid):
            email_dict += email_dict.append(',')
                          
            
    return None
    

