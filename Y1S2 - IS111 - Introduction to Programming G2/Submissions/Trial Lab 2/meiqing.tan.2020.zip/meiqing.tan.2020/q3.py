# Name: Tan Mei Qing
# Email ID:meiqing.tan.2020
def create_email_dict(email_list):

    if len(email_list) == 0:
        return []


    email_dict = {} # key is sch and values are the valid emails
    for email in email_list:
        if is_valid_email(email) == True:
            
            email_dict[str(sch_ID[1].split('.')[0]) + '-' + str(year)] = value

            if email_dict[str(sch_ID[1].split('.')[0]) + '-' + str(year)] not in email_dict:
                

def is_valid_email(email):
    digits = '0123456789'

    year = ''
    num_digits = 0
    for ch in emaiL:
        if ch in digits:
            num_digits += 1
            year += ch

    sch_ID = email.split('@')

    if not (sch_ID[1].split('.')[0] != 'smu' and num_digits == 4):
        return False

    return True



