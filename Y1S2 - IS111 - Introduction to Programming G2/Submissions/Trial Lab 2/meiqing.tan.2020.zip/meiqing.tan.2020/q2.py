# Name: Tan Mei Qing
# Email ID: meiqing.tan.2020
def process_numbers(input_filename, output_filename):

    with open(input_filename, 'r') as input_file:
        num_col = 0
        for line in input_file:
            line = line.rstrip('\n')
            col = line.split('*') # ['10 20 30', '100 400 200 300', '-10 -20', '9 3']

            num_col += 1
            
            result = ''
            max_number_list = []
            max_number = 0
            for group in col:
                number = group.split(' ') #[['10', '20', '30'], ['100', '400', '200', '300'], ['-10', '-20'], ['9', '3']]
                for individual_num in number:
                    individual_num = int(individual_num)
                    if individual_num > max_number:
                        max_number = individual_num
                    
                        max_number_list.append(max_number)

    with open(output_filename, 'w') as output_file:
        max_number_str = ''
        for max_number in max_number_list:
            max_number_str += str(max_number) + '*'
            output_file.write(str(len(max_number_list)) + ': ' + max_number_str[:-1])