# Name: Tan Mei Qing
# Email ID: meiqing.tan.2020
def get_ppl_with_fever(ppl_list):

    if len(ppl_list) == 0:
        return []
    name_list = []
    for ppl in ppl_list:
        (name, temp_list) = ppl

        
        for temp in temp_list:
            if temp > 37.5:
                if name not in name_list:
                    name_list.append(name)
    return name_list

