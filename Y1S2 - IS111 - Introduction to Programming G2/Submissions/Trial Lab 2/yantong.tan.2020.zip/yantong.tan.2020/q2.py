# Name: Tan Yan Tong
# Email ID: yantong.tan.2020
def process_numbers(input_filename, output_filename):
        
    # Modify the code below.
    with open (input_filename, 'r') as input_file:
        with open(output_filename, 'w') as output_file:
            for lines in input_file:
                    lines = lines.rstrip('\n')
                    columns = lines.split('\t')
                    num_star = lines.count('*')
                    num_groups = int(num_star) +1
                    max_num = max(columns)
                
                    output_file.write(str(num_groups) + ":" + max_num)
        #with open('output_1.txt', 'w') as output_file:
            #numbers = columns
            #output_file.write(numbers)
            
    #return None
    


