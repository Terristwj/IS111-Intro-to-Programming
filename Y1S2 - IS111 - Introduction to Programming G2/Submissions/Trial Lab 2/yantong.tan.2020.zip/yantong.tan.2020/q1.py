# Name: Tan Yan Tong
# Email ID: yantong.tan.2020

#ppl_list contains tuple: (name, temperature)

def get_ppl_with_fever(ppl_list):
    

    # Modify the code below.
    new_list = []
    
    if ppl_list != []:
        total_name = ""
        for item in ppl_list:
            ppl_info = ppl_list[0]
            temperature = ppl_info[1]
            
            average_temp = (sum(temperature))/len(temperature)
            
        
            if float(average_temp) > 37.5:
                name = ppl_info[0]
             
                new_list = name
        return new_list
            
    else:
        return new_list
        #
        
            #new_list.append(name)
    #return None
    
    
    
    #return empty list if ppl_list empty

