def display_fibonacci(i): 
    i = 0
    for i in range(0,999999999999,i):
        fibonacci_sum = fibonacci_sum + i
        print(fibonacci_sum)