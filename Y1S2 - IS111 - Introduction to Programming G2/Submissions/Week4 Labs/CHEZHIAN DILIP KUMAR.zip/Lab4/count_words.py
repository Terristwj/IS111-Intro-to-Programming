def count_a(msg):
    ch=0
    for ch in range(0,len(msg)): 
        if "a" in msg:
            ch = ch + 1
            return ch
def count_an(msg):
    m = 0
    for m in range(0, len(msg)):
        if " an " in msg:
            m = m + 1
            return m