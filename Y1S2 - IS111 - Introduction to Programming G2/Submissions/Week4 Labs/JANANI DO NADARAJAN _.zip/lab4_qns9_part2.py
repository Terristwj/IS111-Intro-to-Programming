str = input("Enter a message :")

for n in range(len(str)):
        print(str[0:len(str)-n])