def count_a(str):
	num_of_a = 0
	for i in str:
		if i == "a":
			num_of_a += 1
		else:
			num_of_a += 0
	return num_of_a

def count_an(str):
	num_of_an = 0
	for i in range(len(str)): 
		if str[i] == "a" and str[i-1] == " " and str[i+1] == "n" and str[i+2] == " ":
			num_of_an += 1
		else:
			num_of_an += 0
	return num_of_an