str = input("Enter a message :")

str_new = ''
for i in range(len(str)):
    str_new = str_new+str[i]
    print(str_new)
    