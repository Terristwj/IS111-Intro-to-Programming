def display_fibonacci(n):
    n1 = 1
    n2 = 1
    print(n1, n2, end= ' ')
    
    for i in range(2, n):
        n3 = n1 + n2
        print(str(n3), end= ' ')
        n1 = n2
        n2 = n3
    print()
    
      
        