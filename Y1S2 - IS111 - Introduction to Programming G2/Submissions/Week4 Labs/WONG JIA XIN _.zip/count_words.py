def count_a(msg):
    running_a_count = 0
    for i in range(0, len(msg)):
        if msg[i] == ' ' and msg[i+1] == 'a' and msg[i+2] == ' ':
            running_a_count += 1
        else:
            running_a_count += 0
    return running_a_count
    
def count_an(msg):
    running_an_count = 0
    for i in range(0, len(msg) - 2):
        if msg[i] == ' ' and msg[i+1] == 'a' and msg[i+2] == 'n' and msg[i+3] == ' ':
            running_an_count += 1
        else:
            running_an_count += 0
    return running_an_count