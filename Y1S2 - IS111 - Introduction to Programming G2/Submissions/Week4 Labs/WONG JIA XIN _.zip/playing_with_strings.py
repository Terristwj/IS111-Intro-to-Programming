def playing_with_strings():
    msg = input("Enter a message :")
    
    for ch in range(0, len(msg)):
        print(msg[:ch+1])

playing_with_strings()

def playing_upside_down_strings():
    msg = input("Enter a message :")
    
    for ch in range(0, len(msg)):
        print(msg[:len(msg) - ch])
        
playing_upside_down_strings()