import count_words

def count_a(str):
    a_counter = 0
    for i in range(len(str)):
        if str[i] == 'a' and str[i-1] == str[i + 1] == ' ':
            a_counter += 1
    return a_counter 

def count_an(str_2):
    an_counter = 0
    for j in range(len(str_2)):
        if str_2[j] == 'a' and str_2[j-1] == str_2[j + 2] == ' ' and str_2[j + 1] == 'n':
            an_counter += 1
    return an_counter

print(count_words.count_a('I have a room with a window, a desk and a chair.'))

print(count_words.count_an('Every day I have an egg, an apple and a banana for breakfast.'))