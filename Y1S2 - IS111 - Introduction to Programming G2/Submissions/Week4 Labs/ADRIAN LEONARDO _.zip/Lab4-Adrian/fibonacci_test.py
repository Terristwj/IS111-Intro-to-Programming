import fibonacci
def display_fibonacci(int):
    sequence = [1, 1, 2]
    if int == 3:
        for i in sequence:
            print(i, end = ' ')
    else:
        for j in range(3):
            print(sequence[j], end = ' ')
        for k in range(3, int):
            new_element = sequence[k-1] + sequence[k-2]
            sequence.append(new_element)
            print(sequence[k], end = ' ')

number_input = int(input("Enter a number for fibonacci function: "))

fibonacci.display_fibonacci(3)
fibonacci.display_fibonacci(5)
fibonacci.display_fibonacci(10)