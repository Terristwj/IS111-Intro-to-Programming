msg = input("Enter a message: ")

x = 0
for n in range(0,len(msg)):  
    if n == 0:
        print(msg[0])
    else:  
        x += 1
        print(" "*x + msg[0:n+1])

y = 0    
test = ""
for c in msg:
    y += 1
    test += msg[len(msg)-y]
    print(test)
