#Q7a
def count_a(text):
    count = 0
    for n in range(0, len(text)):
        if text[n] == "a" and text[n+1] == " " and text[n-1] == " ":
            count += 1
    return count
    
def count_an(text):
    count = 0
    for n in range(0, len(text)):
        if text[n] == "a" and text[n+1] == "n" and text[n-1] == " " and text[n+2] == " ":
            count +=1
    return count
        


