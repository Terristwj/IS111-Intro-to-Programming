def display_fibonacci(n):
    for x in range(1, n+1):
        sum = 0
        if x <=2:
            print(1, end = " ")
        else:
            sum += (max(1,(x-2)) + max(1,(x-1)))
            print(sum, end = " ")
 