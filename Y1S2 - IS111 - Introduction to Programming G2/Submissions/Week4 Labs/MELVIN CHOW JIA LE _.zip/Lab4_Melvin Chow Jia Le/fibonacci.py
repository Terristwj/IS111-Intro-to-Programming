def display_fibonacci(n): 
	#first two numbers of the fibonacci
	fib = [1,1] 
	for i in range(3, n+1): 
		fib.append(fib[i-3]+fib[i-2])
	for i in fib: 
		print(i, end = " ")	
	print("\n")
	return None
