def count_a(text): 
	a_count = 0 
	for i in range(len(text)): 
		if (text[i-1] == " ") and (text[i] == 'a') and text[i+1] == ' ': 
			a_count+=1 
	return a_count

def count_an(text): 
	an_count = 0 
	for i in range(len(text)): 
		if (text[i-1] == " ") and (text[i] == 'a') and text[i+1] == 'n' and text[i+2] == ' ':
			an_count+=1 
	return an_count
