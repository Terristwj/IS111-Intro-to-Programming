msg= input('Enter a message: ') 
for row in range(len(msg)): 
    for column in range(len(msg)-row): 
        print(msg[column], end ='')
    print()