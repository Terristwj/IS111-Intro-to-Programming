def display_fibonacci(number):
    counter = 0
    n1= 1
    n2= 1 
    temp = 0
    for x in range(0,number): 
        print(n1, end = ' ')
        temp = n1 + n2
        n1= n2
        n2 = temp
        counter += 1
    print ()
        