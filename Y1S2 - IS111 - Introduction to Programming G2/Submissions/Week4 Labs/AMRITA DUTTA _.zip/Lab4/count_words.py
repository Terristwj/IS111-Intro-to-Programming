def count_a(string): 
    count = 0
    list1= string.split(' ')
    for i in list1: 
        if i== 'a':
            count = count + 1
    return count 

def count_an(string):
    list2=  []
    count = 0
    list2= string.split(' ')
    for b in list2: 
        if b == "an": 
            count = count +1 
    return count   