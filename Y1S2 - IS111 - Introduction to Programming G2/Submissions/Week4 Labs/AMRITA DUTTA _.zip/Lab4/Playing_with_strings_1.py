msg= input('Enter a message: ') 
for row in range(len(msg)): 
    for column in range(row+1): 
        print(msg[column], end ='')
    print()
    