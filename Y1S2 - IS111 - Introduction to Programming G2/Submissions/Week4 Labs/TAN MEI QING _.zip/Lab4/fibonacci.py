def display_fibonacci(n):
	prev_prev_number = 1 # assume that theres at least 3 numbers
	prev_number = 1
	print('1 1 ', end='')

	for num in range(2, n+1): # ensure numbers from 2 till n are included
		curr_number = prev_prev_number + prev_number
		print(str(curr_number) + ' ', end=' ') # to ensure theres space between the numbers

		prev_prev_number = prev_number
		prev_number = curr_number

	print()