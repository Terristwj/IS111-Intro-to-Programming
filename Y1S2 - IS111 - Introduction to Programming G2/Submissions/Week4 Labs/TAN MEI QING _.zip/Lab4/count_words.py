def count_a(text):
	sum_of_a = 0
	text = ' ' + text + ' '
	for i in range(0, len(text)-2): # to ensure that only 'a' with spaces will be included
		if text[i] == ' ' and text[i+1] == 'a' and text[i+2] == ' ':
			sum_of_a += 1
	return sum_of_a


def count_an(text):
	sum_of_an = 0
	text = ' ' + text + ' '
	for i in range(0, len(text)-3): # to ensure that only 'an' with spaces will be included
		if text[i] == ' ' and text[i+1] == 'a' and text[i+2] == 'n' and text[i+3] == ' ':
			sum_of_an += 1
	return sum_of_an
