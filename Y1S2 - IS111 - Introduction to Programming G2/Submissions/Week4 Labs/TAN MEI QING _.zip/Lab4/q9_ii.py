msg = input("Enter a message :")

for n in range(0, len(msg)):
	j = len(msg) - n # from solution but not sure why
	print(msg[0:j]) 