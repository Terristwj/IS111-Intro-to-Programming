def count_a(text):
    #the function is to count word 'a' not the letter 'a'
    count = 0
    # We add a space to the text on both sides in case there is the word 'a' in the beginning or the end
    text = ' ' + text + ' '
    for i in range(0, len(text)-2):
        if text[i]==' ' and text[i+1]=='a' and text[i+2]==' ':
            count += 1
    return count
    
def count_an(text):
    count = 0
    # We add a space to the text on both sides in case there is the word 'an' in the beginning or the end
    text = ' ' + text + ' '
    for i in range(0, len(text)-3):
        if text[i]==' ' and text[i+1]=='a' and text[i+2]=='n' and text[i+3]==' ':
            count += 1
    return count

