msg=input("Enter a message: ")

for n in range(0,len(msg)):
    print(msg[0:n+1])