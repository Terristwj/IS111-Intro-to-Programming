msg=input("Enter a message: ")

for n in range(0,len(msg)):
    x=len(msg)-n
    print(msg[0:x])