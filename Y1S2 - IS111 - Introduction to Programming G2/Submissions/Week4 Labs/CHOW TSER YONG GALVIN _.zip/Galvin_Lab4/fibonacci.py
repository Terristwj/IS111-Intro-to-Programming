
def display_fibonacci(n):
    first, second = 0, 1
    for i in range(n):
        print(second, end=' ')
        first, second = second, first + second
    print()
