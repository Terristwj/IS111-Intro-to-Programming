# Part I
msg = input("Enter a message :")
length = len(msg)
for n in range (length):
    print(msg[:n+1])
    
    
# Part II
msg = input("Enter a message :")
length = len(msg)
for n in range (length, 0, -1):
    print(msg[:n])