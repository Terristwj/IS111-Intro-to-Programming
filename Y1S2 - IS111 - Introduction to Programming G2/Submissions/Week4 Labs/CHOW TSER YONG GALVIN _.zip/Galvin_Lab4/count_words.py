
def count_a (text):
    count_a = 0
    for n in range (len (text)):
        if text [n] == "a" and text [n-1] == " " and text [n+1] == " ":
            count_a += 1
    return count_a 

def count_an (text):
    count_an = 0
    for n in range (len (text)):
        if text [n] == "a" and text [n+1] == "n" and text [n-1] == " " and text [n+2] == " ":
            count_an += 1
    return count_an 