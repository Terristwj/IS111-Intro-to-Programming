def display_fibonacci(number):
    
    # Check if number is less than 3
    if (number < 3):
        print("Please enter a number greater or equal to 3")
    else:
        # print initial numbers
        print("1 1", end=" ")
        
        # calculate
        prev_number = 1
        prev_prev_number = 1
        for i in range(2, number):
            current_number = prev_prev_number + prev_number
            print(str(current_number), end=" ")
            
            prev_prev_number = prev_number
            prev_number = current_number     
    print()
 