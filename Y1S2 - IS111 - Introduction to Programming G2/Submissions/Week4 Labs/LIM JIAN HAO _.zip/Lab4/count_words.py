def count_a(text):
    index = 0
    counter = 0
    for char in text:
        if (char == "a") and (text[index+1] == " ") and (text[index-1] == " "):
            counter += 1
        else:
            pass
        index += 1
    return counter
    
def count_an(text):
    index = 0
    counter = 0
    for char in text:
        if (char == "a") and (text[index+1] == "n") and (text[index+2] == " ") and (text[index-1] == " "):
            counter += 1
        else:
            pass
        index += 1
    return counter
