def display_fibonacci(n):

    prev_prev_number = 1
    prev_number = 1
    print("1 1 ", end="")
    
    for i in range (2, n):
        current_number = prev_prev_number + prev_number
        print(str(current_number) + " ", end="")
        
        prev_prev_number = prev_number
        prev_number = current_number
    
    print()
        