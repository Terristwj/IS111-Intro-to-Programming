msg = input("Enter a message :")

for i in range (0, len(msg)):
    j = len(msg) - i
    print(msg[0:j])