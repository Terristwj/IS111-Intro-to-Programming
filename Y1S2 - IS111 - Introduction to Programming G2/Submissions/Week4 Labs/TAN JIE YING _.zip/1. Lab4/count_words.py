def count_a(text):
    
    count = 0 
    
    for i in range (0, len(text)):
        if text[i] == " " and text[i+1] == "a" and text [i+2] == " ":
            count = count + 1
    return count 

def count_an(text):

    count = 0 
    
    for i in range (0, len(text)):
        if text[i] == " " and text[i+1] == "a" and text [i+2] == "n" and text [i+3] == " ":
            count = count + 1
    return count
    
    
