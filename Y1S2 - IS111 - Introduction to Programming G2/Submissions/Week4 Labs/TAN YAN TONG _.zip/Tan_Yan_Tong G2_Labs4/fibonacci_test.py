import fibonacci

fibonacci.display_fibonacci(3)
fibonacci.display_fibonacci(5)
fibonacci.display_fibonacci(10)

def display_fibonacci():
    if n >= 3:
    print fibonacci.display_fibonacci(3)