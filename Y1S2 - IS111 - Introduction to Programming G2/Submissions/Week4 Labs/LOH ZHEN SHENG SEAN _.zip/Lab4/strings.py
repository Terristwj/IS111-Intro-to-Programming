message = input("Enter a message :")
num_char = 0

for n in range(len(message)):
    print(message[:num_char+1])
    num_char += 1