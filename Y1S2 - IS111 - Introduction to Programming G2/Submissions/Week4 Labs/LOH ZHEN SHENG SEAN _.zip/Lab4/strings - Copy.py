message = input("Enter a message :")
num_char = len(message)

for n in range(len(message)):
    print(message[:num_char])
    num_char -= 1