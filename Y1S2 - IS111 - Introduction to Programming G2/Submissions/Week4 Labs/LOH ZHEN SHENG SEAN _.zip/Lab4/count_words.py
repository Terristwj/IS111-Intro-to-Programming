def count_a(text):
    num_a = 0
    text_list = text.split()
    
    for i in text_list:
        if i == "a":
            num_a += 1
    
    return num_a

def count_an(text):
    num_an = 0
    text_list = text.split()
    
    for i in text_list:
        if i == "an":
            num_an += 1
    
    return num_an