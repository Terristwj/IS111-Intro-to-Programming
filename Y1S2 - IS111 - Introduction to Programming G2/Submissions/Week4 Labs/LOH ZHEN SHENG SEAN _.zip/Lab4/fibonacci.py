def display_fibonacci(n):
    x = 1
    y = 1
    if n == 1:
        print(x)
    elif n == 2:
        print(x, y)
    elif n >= 3:
        print(x, y, end=" ")
        for i in range(n-2):
            z = x + y
            x = y
            y = z
            print(z, end=" ")
    print()