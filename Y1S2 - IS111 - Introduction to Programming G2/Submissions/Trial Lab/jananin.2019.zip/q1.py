# Name: Janani
# Email ID: jananin.2019

def add_first_odd_digits(str_list):

    # Modify the code below
    num = []
    sum = 0
    # if str_list == []:
    #     return 0 
    for index in range(len(str_list)):
        for i in str_list[index]:
            if i.isnumeric():
                num = num + [i]
        for i in range(len(num)):
            if int(num[i]) % 2 != 0:
                sum = sum + int(num[i])
                i = i +1

    return sum 