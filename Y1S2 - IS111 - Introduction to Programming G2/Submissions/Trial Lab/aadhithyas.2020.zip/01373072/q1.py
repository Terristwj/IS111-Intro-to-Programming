# Name: Aadhithya Selvakumar
# Email ID: aadhithyas.2020@economics.smu.edu.sg

def add_first_odd_digits(str_list):
    running_total = 0
    if len(str_list) == 0:
        return 0

    else:
        for string in str_list:
            x = string
            for i in range(0,len(x)):
                if x[i].isnumeric == True:
                    if x[i] % 2 != 0 or x[i] == 1:
                        running_total += int((x[i])
            return running_total


        



