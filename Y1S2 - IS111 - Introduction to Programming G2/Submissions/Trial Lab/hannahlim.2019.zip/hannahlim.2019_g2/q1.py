# Name: Hannah Lim Fung
# Email ID: hannahlim.2019@accountancy.smu.edu.sg

def add_first_odd_digits(str_list):

    # Modify the code below
    odd_numbers = 0

    if len(str_list) == 0:
        return 0

    if len(str_list) != 0:
        



