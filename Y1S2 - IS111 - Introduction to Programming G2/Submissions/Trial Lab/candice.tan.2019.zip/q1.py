# Name: Candice Tan
# Email ID: candice.tan.2019

def add_first_odd_digits(str_list):

    # Modify the code below
    sum = 0 
    
    for i in str_list: 
        if i = '1' or i = '3' or i = '5' or i = '7' or i = '9':
            sum += int(i)   
            
    return sum
 
 
 