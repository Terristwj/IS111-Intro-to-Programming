# Name: Galvin Chow
# Email ID: galvin.chow.2021

def add_first_odd_digits(str_list):

#     # Modify the code below
    sum = 0
    for el in str_list:
        for i in range(len(el)):
            if el[i] == 1 or 3 or 5 or 7 or 9:
                first_odd = el[i]
                break
        sum += int(first_odd)
    return sum
    
# add_first_odd_digits(['abc123def', 'SMU2345SIS', 'XYZ0', '7777'])