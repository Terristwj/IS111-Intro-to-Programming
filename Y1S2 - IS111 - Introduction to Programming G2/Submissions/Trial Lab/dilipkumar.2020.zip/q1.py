# Name: Chezhian Dilip Kumar
# Email ID: dilipkumar.2020

# Try to find the index of the first odd integer in each string in the list by using the find. function
# Then write a for-loop with an if else statement to sum the odd integers together if the integer exits in the string. 
def add_first_odd_digits(str_list):

    # Modify the code below
    sum_of_numbers= 0
    
    for str in range(len(str_list)):
        if int(str[0:len(str)]%2==1:
            return string_index = 
        string_index= str.find(
        if string_index==-1:
            return sum_of_numbers
        elif string_index > 0:
            return sum_of_numbers= sum_of_numbers + str[string_index]
            return None