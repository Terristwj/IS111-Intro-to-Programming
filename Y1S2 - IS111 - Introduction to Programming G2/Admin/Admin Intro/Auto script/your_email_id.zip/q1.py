# Name: 
# Email ID:

def add_first_odd_digits(str_list):

    # Modify the code below
    return None