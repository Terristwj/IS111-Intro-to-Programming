# Name: Tan Mei Qing
# Email ID: meiqing.tan.2020

from q3a import create_avg_income_per_person_dict

def retrieve_low_income_households(income_dict, avg_income_per_person_across_all_households):
    #for the avg income in new dict from prev function
    for avg_income in avg_income_per_person_across_all_households(income_dict):
    #if the avg income from previous function has lower TOTAL avg income
        if avg_income_per_person_across_all_households(income_dict) < create_avg_income_per_person_dict(a_dict):
         #THEN WE return the list of them by adding their household ID to a list
            final.append(household_ID)

    return final