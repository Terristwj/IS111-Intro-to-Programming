# Name: Tan Mei Qing
# Email ID: meiqing.tan.2020

def sort_summary_data(summary_data):

    region_dict ={}

    with open('region_data.txt', 'r') as input_file:
        for line in input_file:
            line = line.rstrip('\n')
            col = line.split('|')

            if col[0] not in region_dict:
                region_dict[col[0]] = [int(col[2])]

            else:
                if col[1] == 'north': #to ensure north values are added, followed by south then east etc
                    region_dict[col[0]].append(int(col[2]))

                elif col[1] == 'south':
                    region_dict[col[0]].append(int(col[2]))

                elif col[1] == 'east':
                    region_dict[col[0]].append(int(col[2]))

                elif col[1] == 'west':
                    region_dict[col[0]].append(int(col[2]))

                elif col[1] == 'central':
                    region_dict[col[0]].append(int(col[2]))


    final_list = []
    for key in region_dict:
        new_tup = (key, region_dict[key])
        final_list.append(new_tup)

    # Modify the code below
    return final_list