# Name: Tan Mei Qing
# Email ID: meiqing.tan.2020

def get_ordered_list(int_1, int_2):

    final = []
    if int_1 < int_2:
        final.append(int_1)
        final.append(int_2)

    elif int_2 < int_1:
        final.append(int_2)
        final.append(int_1)

    elif int_1 == int_2:
        final.append(int_1)
        final.append(int_2)


    return final