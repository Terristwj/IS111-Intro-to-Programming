# Name: Tan Mei Qing
# Email ID: meiqing.tan.2020

def read_file(beverage_preference):

    with open('beverage_preference.txt', 'r') as input_file:
        drink_dict = {}
        for line in input_file:
            line = line.rstrip('\n')
            col = line.split('|')
            name = col[0]

            for tea_info in col[1:]:
                (tea_final) = (tea_info[0], tea_info[1], tea_info[2])
                


                if name not in drink_dict:
                    drink_dict[name] = [(tea_final)]

                else:
                    drink_dict[name].append((tea_final))


    return drink_dict