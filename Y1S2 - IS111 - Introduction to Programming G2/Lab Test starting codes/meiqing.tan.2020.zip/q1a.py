# Name: Tan Mei Qing
# Email ID: meiqing.tan.2020

def get_cif_in_sgd(cost_in_usd, insurance_rate, freight_charges):
    cost_in_sgd = 1.35*(cost_in_usd)
    insurance_fee = cost_in_sgd*insurance_rate
    insurance_fee = cost_in_sgd + insurance_fee + freight_charges

    return round(insurance_fee,2)
