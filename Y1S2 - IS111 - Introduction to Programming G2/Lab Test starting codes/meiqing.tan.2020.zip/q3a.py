# Name: Tan Mei Qing
# Email ID: meiqing.tan.2020

def create_avg_income_per_person_dict(a_dict):
    new_dict = {}
    for household_id in a_dict:
        (total_income, num_ppl) = a_dict[household_id]


        avg = round(total_income/num_ppl, 2)

        new_dict[household_id] = avg

    return new_dict