# Name: Tan Mei Qing
# Email ID: meiqing.tan.2020



def get_user_rating_for(beverage_preference, beverage):

    with open('beverage_preference.txt', 'r') as input_file:
        list_of_tup = []
        for line in input_file:
            line = line.rstrip('\n')
            col = line.split('|')
            name = col[0]
            rating = col[2]
            tup = (name, rating)

            list_of_tup.append(tup)

    return list_of_tup
