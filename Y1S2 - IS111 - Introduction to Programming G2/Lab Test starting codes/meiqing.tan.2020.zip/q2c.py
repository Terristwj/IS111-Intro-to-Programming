# Name: 
# Email ID:

from q2a import get_ordered_list
from q2b import insert_into_list

def return_ordered_ints(unordered_list):

    # Modify the code below
    return None