# Name: 
# Email ID:

def get_user_with_highest_rating(beverage_preference, beverage):

    # Modify the code below
    return None