# Name: Tan Mei Qing
# Email ID: meiqing.tan.2020

def get_bill_with_gst(cif_in_SGD, purchase_year):
    
    if purchase_year < 2023:
        if cif_in_SGD <= 400:
            total_bill = cif_in_SGD*(1+0.00)
            return round(total_bill, 2)


        elif cif_in_SGD > 400:
            total_bill = cif_in_SGD*(1+0.07)
            return round(total_bill, 2)

    elif purchase_year == 2023:
        if cif_in_SGD > 0:
            total_bill = cif_in_SGD*(1+0.08)
            return round(total_bill, 2)

    elif purchase_year > 2023:
        if cif_in_SGD > 0:
            total_bill = cif_in_SGD*(1+0.09)
            return round(total_bill, 2)


    

