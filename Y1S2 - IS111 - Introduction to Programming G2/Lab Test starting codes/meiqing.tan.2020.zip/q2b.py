# Name: Tan Mei Qing
# Email ID: meiqing.tan.2020




def insert_into_list(ordered_list, new_int):

    if len(ordered_list) == 0:
        return [new_int]

    #for the numner in the ordered list i go thru them first
    #see which is smaller then i add to the list first
    #then if its the same i just add the new int
    #but if num is larger i add the new int

    final = []
    for num in ordered_list:
        if num < new_int:
            final.append(num)

        elif num == new_int:
            final.append(num)
            final.append(new_int)

        elif num > new_int:
            final.append(new_int)
            final.append(num)


    return final