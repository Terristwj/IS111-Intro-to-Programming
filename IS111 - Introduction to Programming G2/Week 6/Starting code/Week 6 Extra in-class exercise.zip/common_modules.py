# Name: 
# Email ID:

def check_common_modules(student_list):
    
    # Modify the code below
    return None