item_file_name = './static/items.txt'
loan_file_name = './static/loans.txt'

criterion_list = [('0', 'title'), ('1', 'library'), ('2', 'format'), ('3', 'language'), ('4', 'status')]

item_list = []
loan_dict = {}

