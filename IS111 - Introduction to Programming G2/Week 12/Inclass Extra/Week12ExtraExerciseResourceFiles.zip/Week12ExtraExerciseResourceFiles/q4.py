def get_document_pair(filename):
    # Modify the code below.
    return None
    
print(get_document_pair('documents.txt'))