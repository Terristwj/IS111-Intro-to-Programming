import math as m

#variables
flag_down_fare = float(input("What's the flag down fare: $"))
first_rate = float(input("What's the rate per 400 meters within 9.8km? $"))
second_rate = float(input("What's the rate per 350 meters beyond 9.8km? $"))
distance = float(input("What's the distance travelled (in meters)? "))
is_peak = input("Is the ride during a peak period? [yes|no] ") == 'yes'

is_night = ''
if not is_peak:
    is_night = input("Is the ride between midnight and 6am? [yes|no] ") == 'yes'

is_location_surcharge = input("Is there any location surcharge? [yes|no] ") == 'yes'

location_surcharge = 0
if is_location_surcharge:
    location_surcharge = float(input("What's the amount of location surcharge? $"))

#functions
def calculate_meter(flag_down_fare, first_rate, second_rate, distance):
    price= 0
    additional = 0
    remainder_distance = 0

    if distance < 1000:
        price += flag_down_fare
    elif distance < 9800:
        remainder_distance = distance - 1000
        additional = m.ceil(remainder_distance/400) * first_rate
        price = flag_down_fare + additional
    else:
        remainder_distance = distance - 9800
        additional = m.ceil(8800 / 400) * first_rate + m.ceil(remainder_distance/350) * second_rate
        price = flag_down_fare + additional
    return price

def calculate_surcharge(meter_fare, location_surcharge = 0):
    surcharge = 0
    if is_peak:
        surcharge += meter_fare * 0.25
    if is_night:
        surcharge += meter_fare * 0.5
    if is_location_surcharge:
        surcharge += location_surcharge
    return surcharge


#call
meter_fare = calculate_meter(flag_down_fare, first_rate, second_rate, distance)
total_surcharge = calculate_surcharge(meter_fare, location_surcharge)
total_fare = round(meter_fare + total_surcharge, 2)
print(f'The total fare is ${total_fare}')
