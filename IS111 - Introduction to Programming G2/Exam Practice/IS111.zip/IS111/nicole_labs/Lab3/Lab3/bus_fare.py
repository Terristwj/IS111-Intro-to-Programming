# The following function is provided to you.
# Do not modify the function definition!
def get_personal_info():
    """
    This function prompts the user for his/her name, gender, age and whether
    or not he/she is a student.
    The function returns a tuple that contains all the information entered
    by the user.
    """
    name = input("What's your name? ")
    gender = input("What's your gender? [M|F] ")
    age = int(input("What's your age? "))
    is_student = input("Are you a student? [yes|no] ")
    return (name, gender, age, is_student == 'yes')

# Write your code below:
info = get_personal_info()
name = info[0]
gender = info[1]
age = info[2]
is_student = info[3]

if age <= 6:
    print(f'{name}, you can travel for free.')
elif age >= 60:
    if gender == 'M':
        print(f'Mr. {name}, you can get concessionary fare for senior citizens.')
    else:
        print(f'Mrs. {name}, you can get concessionary fare for senior citizens.')
elif 6 < age < 60:
    if is_student:
        if gender == 'M':
            print(f'Mr. {name}, you can get concessionary fare for students.')
        else:
            print(f'Ms. {name}, you can get concessionary fare for students.')
    else:
        if gender == 'M':
            print(f'Mr. {name}, you need to pay full fare.')
        else:
            print(f'Ms. {name}, you need to pay full fare.')