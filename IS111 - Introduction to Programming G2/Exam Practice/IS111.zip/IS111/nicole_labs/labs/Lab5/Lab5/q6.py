import random 
# Put your code below
######################
def get_all_combinations(str_list, num_list):
    list = []
    for word in str_list:
        for number in num_list:
            list.append((word, number))
    return list

def get_larger_numbers(num_list1, num_list2):
    maximum = max(num_list2)
    list = []
    for num in num_list1:
        if num > maximum:
            list.append(num)

    return list

def get_non_common_strings(str_list1, str_list2):
    list= []
    for string in str_list1:
        if string not in str_list2:
            list.append(string)

    for string in str_list2:
        if string not in str_list1:
            list.append(string)

    return list

    # setA = set(str_list1)
    # setB = set(str_list2)
    #
    # return sorted(setA.union(setB) - setA.intersection(setB))

# Test Cases to test your code
##############################

r_list = get_all_combinations(["a", "b"], [1, 2, 3])
print("Expected: [('a', 1), ('a', 2), ('a', 3), ('b', 1), ('b', 2), ('b', 3)]")
print("Actual  : " + str(r_list))
print()

r_list = get_larger_numbers([4, 6, 10], [1, 3, 5])
print("Expected: [6, 10]")
print("Actual  : " + str(r_list))
print()

r_list = get_non_common_strings(["a", "b", "c", "d"], ["b", "d", "e", "f"])
print("Expected: ['a', 'c', 'e', 'f']")
print("Actual  : " + str(r_list))
print()

print(random.randint(1,10))