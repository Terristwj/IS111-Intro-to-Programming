#part I
message = input('Enter a message :')
string = ''
for ch in message:
    string += ch
    print(string)

#part II
message2 = input('Enter a message :')
for i in range(len(message2), 0, -1):
    print(message2[0:i])