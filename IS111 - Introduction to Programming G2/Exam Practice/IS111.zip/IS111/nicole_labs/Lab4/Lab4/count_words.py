def count_a(string):
    count = 0
    list_of_words = string.split(' ')
    for word in list_of_words:
        if word == 'a':
            count += 1
    return count

def count_an(string):
    count = 0
    list_of_words = string.split(' ')
    for word in list_of_words:
        if word == 'an':
            count += 1
    return count