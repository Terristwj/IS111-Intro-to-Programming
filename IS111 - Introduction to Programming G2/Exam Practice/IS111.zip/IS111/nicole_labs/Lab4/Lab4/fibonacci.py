def display_fibonacci(number):
    n1 = 0
    n2 = 1
    print(1,end=' ')
    for i in range(number-1):
        n3 = n1 + n2
        print(n3,end=' ')
        n1 = n2
        n2 = n3
    print()

