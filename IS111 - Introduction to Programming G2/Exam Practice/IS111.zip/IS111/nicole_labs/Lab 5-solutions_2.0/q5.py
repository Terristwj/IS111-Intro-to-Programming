TAX_INFO = [
    (20000, 0, 0.02),
    (30000, 200, 0.035),
    (40000, 550, 0.07),
    (80000, 3350, 0.115),
    (120000, 7950, 0.15),
    (160000, 13950, 0.18),
    (200000, 21150, 0.19),
    (240000, 28750, 0.195),
    (280000, 36550, 0.2),
    (320000, 44550, 0.22)
]

def calculate_tax(income):

    upper_bound = TAX_INFO[0][0]
    if (income <= upper_bound):
        return 0.0

    for index in range(0, len(TAX_INFO) - 1):
        upper_bound = TAX_INFO[index + 1][0]
        if (income <= upper_bound):
            lower_bound = TAX_INFO[index][0]
            base_tax = TAX_INFO[index][1]
            tax_rate = TAX_INFO[index][2]
            total_tax = base_tax + (income - lower_bound) * tax_rate
            return total_tax

    lower_bound = TAX_INFO[len(TAX_INFO)-1][0]
    base_tax = TAX_INFO[len(TAX_INFO)-1][1]
    tax_rate = TAX_INFO[len(TAX_INFO)-1][2]
    total_tax = base_tax + (income - lower_bound) * tax_rate
    return total_tax

tax = calculate_tax(15000)
print("Expected: 0.0")
print("Actual  : " + str(tax))
print()
    
tax = calculate_tax(35000)
print("Expected: 375.0")
print("Actual  : " + str(tax))
print()
    
tax = calculate_tax(100000)
print("Expected: 5650.0")
print("Actual  : " + str(tax))
print()

tax = calculate_tax(350000)
print("Expected: 51150.0")
print("Actual  : " + str(tax))
print()

