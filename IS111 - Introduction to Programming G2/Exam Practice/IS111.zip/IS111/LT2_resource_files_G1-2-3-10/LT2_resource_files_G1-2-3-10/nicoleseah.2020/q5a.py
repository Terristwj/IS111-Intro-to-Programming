# Name: Nicole Seah
# Email ID: nicoleseah.2020
def get_power(eqn):
    #[1,2,3]
    highest_power = len(eqn)-1
    res_list = []
    for num in eqn:
        num_power = (num,highest_power)
        res_list.append(num_power)
        highest_power -= 1
    return res_list


def multiply(polynomials):
    poly_with_powers = []
    for eqn in polynomials:
        eqn_power = get_power(eqn)
        poly_with_powers.append(eqn_power)
        if eqn == [0]:
            return [0]
    if len(polynomials) == 1:
        return polynomials[0]
    new_list = []
    for num in poly_with_powers[0]:
        coeff = num[0]
        power = num[1]
        for num2 in poly_with_powers[1]:
            new_coeff = coeff*num2[0]
            new_power = power+num2[1]
            new_list.append((new_coeff,new_power))

    if len(polynomials) > 2:
        index = 2
        while index != len(polynomials):
            newlist2 = new_list[:]
            for num in new_list:
                coeff = num[0]
                power = num[1]
                for num2 in poly_with_powers[index]:
                    new_coeff = coeff * num2[0]
                    new_power = power + num2[1]
                    newlist2.append((new_coeff, new_power))

            new_list = newlist2[len(new_list):]
            index += 1

    power_dict = {}
    for tup in new_list:
        coeff = tup[0]
        power = tup[1]
        if power not in power_dict:
            power_dict[power] = coeff
        elif power in power_dict:
            power_dict[power] += coeff

    res_list = []
    sorted_powers = sorted(list(power_dict),reverse=True)

    for power in sorted_powers:
        res_list.append(power_dict[power])




    return res_list

# DO NOT MODIFY THE CODE BELOW!
if __name__ == "__main__":
    tc_num = 0
    
    tc_num += 1
    print('-' * 40)
    
    polynomials = [(1, 2, 3), (5, 6, 7)]
    print(f"Test Case {tc_num} : multiply({polynomials})")
    print("Expected : [5, 16, 34, 32, 21]")
    result = multiply(polynomials)
    print(f"Actual   : {result}")
    print() 

    print("Expected return type : <class 'list'>")
    print(f"Actual return type   : {type(result)}")    
    
    print()
    
    print("Expected return type of the first element of the list : <class 'int'>")
    print("Actual return type of the first element of the list   : ", end="")
    if (isinstance(result, list)):
        print(type(result[0]))
    else:
        print("N/A")    

    tc_num += 1
    print('-' * 40)
    
    polynomials = [[1, 2], [3, 4, 5], [6, 7, 8]]
    print(f"Test Case {tc_num} : multiply({polynomials})")
    print('Expected : [18, 81, 172, 231, 174, 80]')
    print(f"Actual   : {multiply(polynomials)}")
    print() 
    
    tc_num += 1
    print('-' * 40)
    
    polynomials = [[1, 2], [0], [3, 4, 5], [6, 7, 8]]
    print(f"Test Case {tc_num} : multiply({polynomials})")
    print('Expected : [0]')
    print(f"Actual   : {multiply(polynomials)}")
    print()     

    tc_num += 1
    print('-' * 40)
    
    polynomials = [[1, 2, 3], [5, 6, 7], [8, 9, 0]]
    print(f'Test Case {tc_num} : multiply({polynomials})')
    print('Expected : [40, 173, 416, 562, 456, 189, 0]')
    print(f'Actual   : {multiply(polynomials)}')
    print()    

    tc_num += 1
    print('-' * 40)
    
    polynomials = [[1, 1, -1, 1], [2, 0], [8, 9, 0]]
    print(f'Test Case {tc_num} : multiply({polynomials})')
    print('Expected : [16, 34, 2, -2, 18, 0, 0]')
    print(f'Actual   : {multiply(polynomials)}')
    print()    

    tc_num += 1
    print('-' * 40)
    
    polynomials = [[1], [0]]
    print(f'Test Case {tc_num} : multiply({polynomials})')
    print('Expected : [0]')
    print(f'Actual   : {multiply(polynomials)}')
    print()    

    tc_num += 1
    print('-' * 40)
    
    polynomials = [[1, 5, 0, 4]]
    print(f'Test Case {tc_num} : multiply({polynomials})')
    print(f'multiply({polynomials})')
    print('Expected : [1, 5, 0, 4]')
    print(f'Actual   : {multiply(polynomials)}')
    print()    