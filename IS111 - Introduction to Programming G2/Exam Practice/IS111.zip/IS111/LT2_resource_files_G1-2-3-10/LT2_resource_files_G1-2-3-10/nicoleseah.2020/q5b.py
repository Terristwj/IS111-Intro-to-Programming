# Name: Nicole Seah
# Email ID: nicoleseah.2020
def get_polynomial(poly_str):
    index = 0
    num_list = []
    while index != len(poly_str):
        power = 1
        if poly_str[index].isdigit():
            num = ''
            while poly_str[index].isdigit():
                num += poly_str[index]
                index += 1
            if poly_str[index+1] == ' ':
                num_list.append((int(num),0))

        elif poly_str[index] == 'x':
            if poly_str[index+1] == '^':
                if poly_str[index+2].isdigit():
                    power = poly_str[index+2]
                    num_list.append((int(num),int(power)))
                    index += 3
            else:
                index += 2
                num_list.append((int(num),int(power)))

        elif poly_str[index] == ' ' or poly_str[index]=='+':
            index += 1

        elif poly_str[index] == '-':
            num = -int(num)
            index += 1

    power_dict = {}
    for tup in num_list:
        coeff = tup[0]
        power = tup[1]
        if power not in power_dict:
            power_dict[power] = coeff
        elif power in power_dict:
            power_dict[power] += coeff

    res_list = []
    sorted_powers = sorted(list(power_dict),reverse=True)

    for power in sorted_powers:
        res_list.append(power_dict[power])
    return res_list

# DO NOT MODIFY THE CODE BELOW!
if __name__ == "__main__":
    tc_num = 0
    
    tc_num += 1
    print('-' * 40)
    
    poly_str = '2x - 2x^2 + 3x - 1 + 6x^3'
    print(f"Test Case {tc_num} : get_polynomial('{poly_str}')")
    print("Expected : [6, -2, 5, -1]")
    result = get_polynomial(poly_str)
    print(f"Actual   : {result}")
    print() 

    print("Expected return type : <class 'list'>")
    print(f"Actual return type   : {type(result)}")    
    
    print()
    
    print("Expected return type of the first element of the list : <class 'int'>")
    print("Actual return type of the first element of the list   : ", end="")
    if (isinstance(result, list)):
        print(type(result[0]))
    else:
        print("N/A")    

    tc_num += 1
    print('-' * 40)
    
    poly_str = '  4x -2x^2 +   3x^5 -   6x^2'
    print(f"Test Case {tc_num} : get_polynomial('{poly_str}')")
    print('Expected : [3, 0, 0, -8, 4, 0]')
    result = get_polynomial(poly_str)
    print(f"Actual   : {result}")
    print()  

    tc_num += 1
    print('-' * 40)
    
    poly_str = '3x^2 - 2x - 3x^2'
    print(f"Test Case {tc_num} : get_polynomial('{poly_str}')")
    print('Expected : [-2, 0]')
    result = get_polynomial(poly_str)
    print(f"Actual   : {result}")
    print()      

