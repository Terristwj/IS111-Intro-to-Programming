# =====
# q1.py
# =====
# Name: Nicole Seah
# Email ID: nicoleseah.2020@sis.smu.edu.sg

def add_first_odd_digits(str_list):
    list = []
    new_list = []
    for item in str_list:
        for ch in item:
            if ch in ['1','3','5','7','9']:
                list.append(ch)
                break

    if len(list) == 0:
        return 0

    for number in list:
        new_list.append(int(number))

    return sum(new_list)