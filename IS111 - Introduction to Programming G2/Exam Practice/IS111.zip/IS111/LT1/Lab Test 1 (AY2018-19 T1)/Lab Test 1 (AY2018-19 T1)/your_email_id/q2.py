#
# Name: 
# Email ID: 
#
def represent_numbers (start, end):
    if end < start:
        return ''
    string = ''
    for i in range(start,end):
       if i < 0:
           string += (-i)*'-'
           string += '#'
       else:
           string += i*'-'
           string += '#'
    if end < 0:
        string += (-end)*'-'
    else:
        string+= end*'-'
    return string
    #endcode


print('Test 1')
print('Expected:-#--#---#----#-----')
print('Actual  :' + represent_numbers(1, 5))
print()

print('Test 2')
print('Expected:---#----#-----')
print('Actual  :' + represent_numbers(3, 5))
print()

print('Test 3')
print('Expected:-')
print('Actual  :' + represent_numbers(1, 1))
print()

print('Test 4')
print('Expected:[]')
print('Actual  :[' + represent_numbers(4, 1) + ']')
print()

print('Test 5')
print('Expected:----#---#--#-##-')
print('Actual  :' + represent_numbers(-4, 1))
print()
