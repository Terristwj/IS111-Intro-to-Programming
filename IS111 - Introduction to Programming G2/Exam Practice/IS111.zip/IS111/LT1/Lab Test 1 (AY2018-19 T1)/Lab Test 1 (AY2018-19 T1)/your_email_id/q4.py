#
# Name: 
# Email ID: 
#
def print_dancing_string(sentence, start):
    list1 = []
    for ch in sentence:
        list1.append(ch)
    line1 = []
    line2 = []
    line3 = []

    length = len(list1)
    length_res = len(list1)+1

    if start == 'T': #start from top row
        str1 = '|'
        str2 = '| '
        str3 = '|  '

        for i in range(0,length):
            if i % 2 != 0:
                line2.append(list1[i])
            elif i % 4 == 0 or i == 0:
                line1.append(list1[i])
            else:
                line3.append(list1[i])

        for ch in line1:
            str1 += (ch + '   ')
        for ch in line2:
            str2 += (ch + ' ')
        for ch in line3:
            str3+= (ch + '   ')

        res_str1 = str1[0:length_res] + '|'
        res_str2 = str2[0:length_res] + '|'
        res_str3 = str3[0:length_res] + '|'

        print(res_str1)
        print(res_str2)
        print(res_str3)

    elif start == 'B':
        str3 = '|'
        str2 = '| '
        str1 = '|  '

        for i in range(0, length):
            if i % 2 != 0:
                line2.append(list1[i])
            elif i % 4 == 0 or i == 0:
                line3.append(list1[i])
            else:
                line1.append(list1[i])

        for ch in line1:
            str1 += (ch + '   ')
        for ch in line2:
            str2 += (ch + ' ')
        for ch in line3:
            str3 += (ch + '   ')

        res_str1 = str1[0:length_res] + '|'
        res_str2 = str2[0:length_res] + '|'
        res_str3 = str3[0:length_res] + '|'

        print(res_str1)
        print(res_str2)
        print(res_str3)

    if start == 'M':
        str1 = '| '
        str2 = '|'
        str3 = '|   '

        for i in range(0, length):
            if i % 2 == 0 or i ==0:
                line2.append(list1[i])
            elif i % 4 == 1 or i == 1:
                line1.append(list1[i])
            else:
                line3.append(list1[i])

        for ch in line1:
            str1 += (ch + '   ')
        for ch in line2:
            str2 += (ch + ' ')
        for ch in line3:
            str3 += (ch + '   ')

        res_str1 = str1[0:length_res] + '|'
        res_str2 = str2[0:length_res] + '|'
        res_str3 = str3[0:length_res] + '|'

        print(res_str1)
        print(res_str2)
        print(res_str3)

    #end


print('Test 1')
print('Expected:')
print('| |')
print('|a|')
print('| |')
print('-' * 20)
print('Actual:')
print_dancing_string('a', 'M') 
print()

print('Test 2')
print('Expected:')
print('| b|')
print('|a |')
print('|  |')
print('-' * 20)
print('Actual:')
print_dancing_string('ab', 'M') 
print()

print('Test 3')
print('Expected:')
print('| b |')
print('|a c|')
print('|   |')
print('-' * 20)
print('Actual:')
print_dancing_string('abc', 'M') 
print()

print('Test 4')
print('Expected:')
print('| b  |')
print('|a c |')
print('|   d|')
print('-' * 20)
print('Actual:')
print_dancing_string('abcd', 'M') 
print()

print('Test 5')
print('Expected:')
print('| b   f   |')
print('|a c e g i|')
print('|   d   h |')
print('-' * 20)
print('Actual:')
print_dancing_string('abcdefghi', 'M')
print()

print('Test 6')
print('Expected:')
print('|a   e   i|')
print('| b d f h |')
print('|  c   g  |')
print('-' * 20)
print('Actual:')
print_dancing_string('abcdefghi', 'T')
print()

print('Test 7')
print('Expected:')
print('|  c   g  |')
print('| b d f h |')
print('|a   e   i|')
print('-' * 20)
print('Actual:')
print_dancing_string('abcdefghi', 'B')
print()

print('Test 8')
print('Expected:')
print('||')
print('||')
print('||')
print('-' * 20)
print('Actual:')
print_dancing_string('', 'T') 
print()


