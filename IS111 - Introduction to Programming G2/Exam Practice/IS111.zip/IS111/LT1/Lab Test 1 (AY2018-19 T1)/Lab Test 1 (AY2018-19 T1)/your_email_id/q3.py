#
# Name: 
# Email ID: 
#
def mask_out(sentence, banned, substitutes):
    new_string = ''

    for ch in sentence:
        if ch in banned:
            index = banned.find(ch)
            if index+1 > len(substitutes):
                new_string += substitutes[0]
            else:
                new_string += substitutes[index]

        else:
            new_string += ch
    return new_string
    #end


print('Test 1')
print('Expected:abcd#')
print('Actual  :' + mask_out('abcde', 'e', '#'))
print()

print('Test 2')
print('Expected:#$solute')
print('Actual  :' + mask_out('absolute', 'ab', '#$'))
print()

print('Test 3')
print('Expected:121hon')
print('Actual  :' + mask_out('python', 'pyt', '12'))
print()





