#
# Name: Nicole Seah G1
# Email ID: 
#
string = 'c'
print(string[0:4])
def get_replacement_string(start_pos, end_pos, cleaned_string):
    string_to_replace = cleaned_string[start_pos:end_pos+1]
    len_of_str_to_replace = end_pos - start_pos + 1
    print(string_to_replace)
    print(len_of_str_to_replace)
    if len_of_str_to_replace != len(string_to_replace):
        string_to_replace = string_to_replace.ljust(len_of_str_to_replace, "?")

    return string_to_replace
    

def expand(text):
    cleaned_string = text
    result_string = text
    index_positions = []
    index_references = []

    #Get all positions of '&' within the input string and store in list
    for pos, char in enumerate(text):
        if char == '&':
            index_positions.append(pos)

    #if nothing found, return input string
    if len(index_positions) == 0:
        return text

    #Get all the individual index references and store in list
    for pos in index_positions:
        entry = "&"
        pos = pos + 1
        current_char = text[pos]
        
        while current_char.isdigit() or current_char == "-":
            entry += current_char
            pos = pos + 1
            if pos >= len(text):
                break
            current_char = text[pos]
        index_references.append(entry)

    #Clean up the string to remove all index references
    for item in index_references:
        cleaned_string = cleaned_string.replace(item, '')


    #Start replacing all the strings
    for item in index_references:
        
        start_pos = int(item.partition("&")[2].partition("-")[0])
        end_pos = int(item.partition("-")[2])
            
        result_string = result_string.replace(item, get_replacement_string(start_pos, end_pos, cleaned_string))

    return result_string


def expand2(text):
    replacement_text = ''
    if '&' not in text:
        return text
    list1 = text.split('&')
    if '&' in list1[0]:
        list2 = list1
    else:
        list2 = list1[1:]
    list3 = []
    list4 = []
    new_text = ''
    res_text = ''

    for item in list2:
        str1 =''
        for ch in item:
            if ch in '0123456789-':
                str1 += ch
        list3.append(str1)

    for item in list3:
        list_item = item.split('-')
        for parts in list_item:
            list4.append(int(parts))
    print(list4)

    # number_of_sets = int(len(list4)/2)
    # for i in range(number_of_sets):
    #     to_remove = '&'+ str(list4[i*2])+'-'+ str(list4[i*2+1])
    #     new_text += text.replace(to_remove, '')
    #
    #
    # for i in range(number_of_sets):
    #     res_text += text.replace(to_remove, new_text[list4[i*2]:list4[i*2+1]+1])
    #
    # return res_text
    for i in range(0, len(list4), 2):
        for i in range(int(list4[i]), int(list4[i + 1]) + 1):
            if i >= len(new_text):
                replacement_text += '?'
            else:
                replacement_text += new_text[i]

    text = text.replace(text_to_replace, replacement_text)
    return text
    #end


def expand1(text):
    new_text = ''
    replacement_text = ''
    text_to_replace = ''
    range_num_list = []
    stored_index = ''
    counter = 0

    for index, ch in enumerate(text):
        next_index = index + 1

        if next_index >= len(text):
            next_index = None

        if ch.isalpha() or ch == ' ':
            new_text += ch

        elif ch.isdigit() and ch != ' ':
            if counter == 2:
                counter = 1
                pass
            else:
                if next_index != None:
                    if text[next_index].isdigit() and ch != ' ':
                        range_num_list.append(ch + text[next_index])
                        stored_index += str(next_index)
                        counter = 2
                    else:
                        range_num_list.append(ch)
                        stored_index += str(next_index)
                elif str(index) in stored_index:
                    pass
                else:
                    range_num_list.append(ch)

        if not ch.isalpha():
            text_to_replace += ch
    text_to_replace = text_to_replace.strip()
    print(range_num_list)

    for i in range(0, len(range_num_list), 2):
        for i in range(int(range_num_list[i]), int(range_num_list[i + 1]) + 1):
            if i >= len(new_text):
                replacement_text += '?'
            else:
                replacement_text += new_text[i]

    text = text.replace(text_to_replace, replacement_text)
    return text

print('Test 1')
print('Expected:ABC XYZ XYZ')
result = expand('ABC &5-7 XYZ')
print('Actual  :' + result)
print()

print('Test 2')
print('Expected:ABC XYZABC XYZ')
result = expand('&0-3&4-6ABC XYZ')
print('Actual  :' + result)
print()

print('Test 3')
print('Expected:C???ABC')
result = expand('&2-5ABC')
print('Actual  :' + result)
print()

print('Test 4')
print('Expected:[a b A B a b A a b A B ]')
result = expand('a b A B &0-5&0-7')
print('Actual  :[' + result + ']')
print()

#print('Test 5')
#print('Expected:[UVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ]')
#result = expand('&20-25ABCDEFGHIJKLMNOPQRSTUVWXYZ')
#print('Actual  :[' + result + ']')
#print()

print('Test 6')
print('Expected:[]')
result = expand('')
print('Actual  :[' + result + ']')
print()

print('Test 7')
print('Expected:abc')
result = expand('abc')
print('Actual  :' + result)
print()
