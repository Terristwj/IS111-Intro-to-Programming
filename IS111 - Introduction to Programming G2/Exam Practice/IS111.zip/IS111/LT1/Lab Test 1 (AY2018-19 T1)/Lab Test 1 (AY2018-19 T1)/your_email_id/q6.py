#
# Name: 
# Email ID: 
#
def print_snake(sequence, w):
    # write your answer between #start and #end
    #start
    rows = []
    length = len(sequence) - w # for use later
    tail = sequence[-w:]
    num_rows = 0
    if len(sequence)%(w+1) != 0:
        num_rows += 2*(len(sequence)//(w+1)) + 1
    else:
        num_rows += 2*(len(sequence)//(w+1))

    for i in range(num_rows-1):
        rows.append('')

    if num_rows % 2 != 0: #sorts alphabets into rows
        for i in range(num_rows-2,-1,-1):
            if i % 2 != 0: #single letter rows
                rows[i] += sequence[length-1]
                length -= 1
            elif i % 2 == 0 and i != 0: #all except 1st row
                rows[i] += sequence[length-w:length]
                length -= w
            elif i == 0:
                rows[i] += sequence[0:length]

    if num_rows % 2 == 0:
        for i in range(num_rows - 2, -1, -1):
            if i % 2 == 0 and i != 0:
                rows[i] += sequence[length - 1]
                length -= 1
            elif i % 2 != 0:
                rows[i] += sequence[length - w:length]
                length -= w
            elif i == 0:
                rows[i] += sequence[0:length]

    for i in range(num_rows-3,-1,-4):
        str1 = ''
        for n in range(len(rows[i])-1,-1,-1):
            str1 += rows[i][n]
        rows[i] = str1

    for i in range(num_rows-2,0,-4):
        rows[i] += (w-(len(rows[i])))*' '

    for i in range(num_rows-4,-1,-4):
        rows[i] = (w-(len(rows[i])))*' ' + rows[i]

    for i in range(num_rows-5,-1,-4):
        rows[i] = (w-(len(rows[i])))*' ' + rows[i]

    for row in rows:
        print(row)
    print(tail)

    #end

print('Test 1')
print('Expected:')
print('abcd')
print('   e')
print('ihgf')
print('j   ')
print('klmn')
print('-' * 20)
print('Actual:')
print_snake('abcdefghijklmn', 4)
print('\n')

print('Test 2')
print('Expected:')
print('cba')
print('d  ')
print('efg')
print('  h')
print('kji')
print('l  ')
print('mno')
print('-' * 20)
print('Actual:')
print_snake('abcdefghijklmno', 3)
print('\n')

print('Test 3')
print('Expected:')
print('    a')
print('fedcb')
print('g    ')
print('hijkl')
print('-' * 20)
print('Actual:')
print_snake('abcdefghijkl', 5)
print('\n')

print('Test 4')
print('Expected:')
print('   a')
print('   b')
print('fedc')
print('g   ')
print('hijk')
print('-' * 20)
print('Actual:')
print_snake('abcdefghijk', 4)
print('\n')
    
print('Test 5')
print('Expected:')
print('a   ')
print('b   ')
print('cdef')
print('-' * 20)
print('Actual:')
print_snake('abcdef', 4)
print('\n')

print('Test 6')
print('Expected:')
print('a   ')
print('bcde')
print('-' * 20)
print('Actual:')
print_snake('abcdefghijklmnopqrstuvwxyz', 4)