# Name:
# Email ID:

def transform(str1, str2):
    '''
    This function tries to transform str1 into str2 by swapping two *adjacent* characters every time. The function returns a list of strings that represents a sequence of transformations that can turn str1 into str2.

    Parameters:
        - str1, the initial string
        - str2, the string to be transformed into
    '''

    # write your answer between #start and #end
    # start

    def compare(str1, str2):
        return all(True if str1[n] == str2[n] else False for n in range(len(str1)))

    def swap(str1, str2):
        for i in range(len(str1)):
            if str1[i] != str2[i] and str1[i + 1] != str2[i + 1]:
                str1[i] = str1[i + 1]

    # if not compare(str1, str2):

    str1 = list(str1)
    str2 = list(str2)

    return []
        
    