# Name:
# Email ID:

def add_even_numbers(str_list):
    number_list = []
    for str in str_list:
        new1 = str.split('|')
        for num in new1:
            number_list.append(int(num))
    sum_even= 0
    for num in number_list:
        if num % 2 == 0:
            sum_even += num
    return sum_even