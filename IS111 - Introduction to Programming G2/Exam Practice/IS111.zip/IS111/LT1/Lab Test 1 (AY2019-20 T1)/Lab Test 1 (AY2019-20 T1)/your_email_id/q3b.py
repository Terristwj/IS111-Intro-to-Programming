# Name:
# Email ID:

import q3a

def calculate_entrance_fees_2(m, n):
     # These variables are defined for you to use.
    ADULT_TICKET = 75
    CHILD_TICKET = 50
    
    PACKAGE_A = 140 # 2 adults
    PACKAGE_B = 110 #1a1c
    PACKAGE_C = 200 #2a2c
    sum = 0
    if m >= n:
        sum += q3a.calculate_entrance_fees_1(n)
        difference = m - n
        if difference % 2 == 0:
            sum += (difference/2 * 140)
        elif difference == 1:
            sum += 75
        else:
            sum += 75 + ((difference-1)/2 * 140)
    else:
        sum += q3a.calculate_entrance_fees_1(m)
        difference = n - m
        sum += difference*50

    return int(sum)




# Modify the code below.
    return None
 