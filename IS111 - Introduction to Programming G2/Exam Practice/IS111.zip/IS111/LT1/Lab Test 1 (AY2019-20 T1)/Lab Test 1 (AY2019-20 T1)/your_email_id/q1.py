# Name:
# Email ID:

def check_sum(n1, n2, n3):
    con1 = n1 + n2 == n3
    con2 = n2+ n3 == n1
    con3 = n1 + n3 == n2
    if con1 or con2 or con3:
        return True
    else: 
        return False
    