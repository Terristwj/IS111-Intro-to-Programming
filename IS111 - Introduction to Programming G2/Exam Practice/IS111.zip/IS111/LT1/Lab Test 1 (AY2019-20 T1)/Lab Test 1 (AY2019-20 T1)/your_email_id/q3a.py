# Name:
# Email ID:

def calculate_entrance_fees_1(n):
    if n % 2 == 0:
        return (n / 2) * 200
    elif n == 1:
        return n * 110
    else:
        return int(110 + (n-1)/2*200)

        