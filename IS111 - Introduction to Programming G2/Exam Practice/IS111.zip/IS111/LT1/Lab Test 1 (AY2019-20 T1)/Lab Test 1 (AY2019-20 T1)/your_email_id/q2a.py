# Name:
# Email ID:

def get_number_of_long_strings(str_list, n):
    count = 0
    for str in str_list:
        if len(str) > n:
            count += 1

    return count