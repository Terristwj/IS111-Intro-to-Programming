# Name:
# Email ID:

import itertools
import q4a

def get_seating_arrangement(female_list, male_list, must_list, cannot_list):
    # Modify the code below.
    res_list = []
    everyone_list = [female_list + male_list]
    my_permutations = list(itertools.permutations(everyone_list))
    perms = []
    for perm in my_permutations:
        perms.append(list(perm))

    for perm in perms:
        if q4a.check_seating_arrangement(perm, must_list,cannot_list) == True:
            return perm
