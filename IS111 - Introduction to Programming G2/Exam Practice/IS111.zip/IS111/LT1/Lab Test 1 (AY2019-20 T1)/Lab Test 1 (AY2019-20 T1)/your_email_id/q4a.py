# Name:
# Email ID:

def check_seating_arrangement(arrangement, must_list, cannot_list):
    arrangement_str = ''
    arrangement_list2 = []
    arrangement_str2 = ''

    for arrange in arrangement:
        arrangement_str += arrange

    new_arrangement = arrangement[1:]
    new_arrangement.append(arrangement[0])

    for i in range(len(new_arrangement)-1,-1,-1):
        arrangement_str2 += new_arrangement[i]

    for must in must_list:
        tuple_str = ''.join(must)
        if tuple_str not in arrangement_str and tuple_str not in arrangement_str2:
            return False

    for cannot in cannot_list:
        cannot_str = ''.join(cannot)
        if cannot_str in arrangement_str or cannot_str in arrangement_str2:
            return False

    return True
 