# Name: Nicole Seah
# Email ID:nicoleseah.2020

def trace_contacts(patient, history):
    res = []
    for pair in history:
       if patient in pair and -5<= pair[2] <= -1:
           if pair[0] == patient:
               if pair[1] not in res:
                   res.append((pair[1],pair[2]))
           else:
               if pair[0] not in res:
                   res.append((pair[0],pair[2]))
    res3 = res[:]
    res4 = []
    for item in res3:
        res4.append(item[0])
    res2 = []
    for name in res:
        new_hist = []
        for hist in history:
            name1 = hist[0]
            name2 = hist[1]
            day_infected = name[1]
            days_to_add = -7-(day_infected)
            dates = hist[2] + days_to_add
            new_hist.append((name1,name2,dates))
        res2 = trace_contacts(name[0],new_hist)
        res4 += res2

    res5 = []
    for item in res4:
        if item not in res5:
            res5.append(item)
    return res5

