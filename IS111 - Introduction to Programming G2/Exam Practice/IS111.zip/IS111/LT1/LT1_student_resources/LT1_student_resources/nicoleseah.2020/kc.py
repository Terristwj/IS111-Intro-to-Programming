from datetime import date

#def trace_contact(patient, history, day0):

def trace_one_contact(patient, history):
    contacted = []
    for record in history:
        if patient in record:
            if -5 <= record[2] <= -1:
                if record[0] == patient:
                    contacted.append(record[1])
                else:
                    contacted.append(record[0])

    print(contacted)
    return contacted


def trace_contacts(patient, history):
    final_lvl_results = []

    day0 = date.today()
    records = []
    for record in history:
        record_list = list(record)
        contacted_date = day0 + record_list[2]
        record_list[2] = contacted_date
        records.append(record)



    print(records)

    return
    #return trace_contact(patient, records, day0)
