# Name: Nicole Seah
# Email ID: nicoleseah.2020

def is_compatible(patient_group, donor_group):
    # Replace the code below with your implementation.
    is_compatible = False
    if patient_group == 'A':
        if donor_group == 'A' or donor_group == 'AB':
            is_compatible = True
    elif patient_group == 'B':
        if donor_group == 'B' or donor_group == 'AB':
            is_compatible = True
    elif patient_group == 'AB':
        if donor_group == 'AB':
            is_compatible = True
    elif patient_group == 'O':
        if donor_group == 'O'or donor_group == 'AB' or donor_group == 'A' or donor_group == 'B':
            is_compatible = True

    return is_compatible