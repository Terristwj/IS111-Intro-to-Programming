# Name: Nicole Seah
# Email ID: nicoleseah.2020

def get_sum_of_digits(my_str):
    # Replace the code below with your implementation.
    num_list = []
    sum = 0
    for ch in my_str:
        if ch in '123456789':
            num_list.append(ch)

    for num in num_list:
        sum += int(num)
    return sum