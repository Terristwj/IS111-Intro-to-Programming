# Name: Nicole Seah
# Email ID: nicoleseah.2020

def get_max_of_min(list_of_num_tuples):
    # Replace the code below with your implementation.
    if len(list_of_num_tuples) == 0:
        return None
    list_min = []

    for tup in list_of_num_tuples:
        min = tup[0]
        for num in tup:
            if num < min:
                min = num
        list_min.append((min))

    max = list_min[0]

    for num in list_min:
        if num > max:
            max = num

    # Note: You’re NOT allowed to use either min()or max()to solve this problem.
    
    return max