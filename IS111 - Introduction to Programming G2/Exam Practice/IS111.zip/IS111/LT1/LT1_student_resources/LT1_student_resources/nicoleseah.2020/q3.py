# Name: Nicole Seah
# Email ID: nicoleseah2020

def check_math(list_of_equations):
    # Replace the code below with your implementation.
    if len(list_of_equations) == 0:
        return True

    is_correct = False
    for eqn in list_of_equations:
        if '+' in eqn:
            eqn_num = eqn.split('+')
            second_eqn_num = eqn_num[1].split('=')
            final_eqn_num = []
            final_eqn_num.append(eqn_num[0])

            for num in second_eqn_num:
                final_eqn_num.append(num)

            num1 = int(final_eqn_num[0])
            num2 = int(final_eqn_num[1])
            num3 = int(final_eqn_num[2])

            if num1 + num2 == num3:
                is_correct = True
            else:
                return False

        elif '-' in eqn:
            eqn_num = eqn.split('-')
            second_eqn_num = eqn_num[1].split('=')
            final_eqn_num = []
            final_eqn_num.append(eqn_num[0])

            for num in second_eqn_num:
                final_eqn_num.append(num)

            num1 = int(final_eqn_num[0])
            num2 = int(final_eqn_num[1])
            num3 = int(final_eqn_num[2])

            if num1 - num2 == num3:
                is_correct = True
            else:
                return False

        elif '*' in eqn:
            eqn_num = eqn.split('*')
            second_eqn_num = eqn_num[1].split('=')
            final_eqn_num = []
            final_eqn_num.append(eqn_num[0])

            for num in second_eqn_num:
                final_eqn_num.append(num)

            num1 = int(final_eqn_num[0])
            num2 = int(final_eqn_num[1])
            num3 = int(final_eqn_num[2])

            if num1 * num2 == num3:
                is_correct = True
            else:
                return False

        elif '//' in eqn:
            eqn_num = eqn.split('//')
            second_eqn_num = eqn_num[1].split('=')
            final_eqn_num = []
            final_eqn_num.append(eqn_num[0])

            for num in second_eqn_num:
                final_eqn_num.append(num)

            num1 = int(final_eqn_num[0])
            num2 = int(final_eqn_num[1])
            num3 = int(final_eqn_num[2])

            if num1 // num2 == num3:
                is_correct = True
            else:
                return False

        elif '%' in eqn:
            eqn_num = eqn.split('%')
            second_eqn_num = eqn_num[1].split('=')
            final_eqn_num = []
            final_eqn_num.append(eqn_num[0])

            for num in second_eqn_num:
                final_eqn_num.append(num)

            num1 = int(final_eqn_num[0])
            num2 = int(final_eqn_num[1])
            num3 = int(final_eqn_num[2])

            if num1 % num2 == num3:
                is_correct = True
            else:
                return False

    return is_correct