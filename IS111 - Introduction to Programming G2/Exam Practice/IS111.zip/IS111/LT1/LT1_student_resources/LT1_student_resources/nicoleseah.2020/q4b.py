# Name: Nicole Seah
# Email ID: nicoleseah.2020

def trace_contacts_2(patient, history, m, n):
