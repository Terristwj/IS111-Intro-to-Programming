def trace_all(patient, infec_day, history, result_list):

    for record in history:
        if patient in record:
            start_infec_day = infec_day + 2
            met_day = record[2]

            next_patient = ""
            if record[2] >= start_infec_day:
                if record[0] == patient:
                    next_patient = record[1]
                else:
                    next_patient = record[0]
                result_list.append(next_patient)
                trace_all(next_patient, met_day, history, result_list)

def trace_contacts(patient, history):
    result_list = []
    
    trace_all(patient, -7, history, result_list)
 
    return list(dict.fromkeys(result_list))

    

    
