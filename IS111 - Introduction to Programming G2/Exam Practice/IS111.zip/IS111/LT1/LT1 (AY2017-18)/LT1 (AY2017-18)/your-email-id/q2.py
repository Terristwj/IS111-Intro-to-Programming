# Name    :
# Email ID:


# start of answer
def generate_digits(sentence):
    list = []
    str = ''
    for ch in sentence:
        list.append(ch)

    for ch in list:
        if ch in 'ABC':
            str += '2'
        elif ch in 'DEF':
            str += '3'
        elif ch in 'GHI':
            str += '4'
        elif ch in 'JKL':
            str += '5'
        elif ch in 'MNO':
            str += '6'
        elif ch in 'PQRS':
            str += '7'
        elif ch in 'TUV':
            str += '8'
        else:
            str+= '9'
    return str




print('Test 1: Check if the return value is a str object')
print('Expected:True')
print('Actual  :' + str(isinstance(generate_digits('A'), str)))
print()


print('Test 2')
print('Expected:2')
print('Actual  :' + generate_digits('A'))
print()

print('Test 3')
print('Expected:79846642')
print('Actual  :' + generate_digits('PYTHONIC'))
print()



print('Test 4')
print('Expected:53354448')
print('Actual  :' + generate_digits('LEDLIGHT'))
print()
