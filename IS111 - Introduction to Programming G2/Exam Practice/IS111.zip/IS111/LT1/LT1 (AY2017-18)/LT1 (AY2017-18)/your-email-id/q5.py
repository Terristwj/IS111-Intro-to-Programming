# Name    :
# Email ID:

# start of answer

def print_triangle(sentence):
    if (len(sentence)-4)%4 != 0 or len(sentence) <= 3:
        return False

    slanted = int((len(sentence)-4)/4)

    if slanted == 0:
        print(' ' + sentence[0])
        print(sentence[1:])
    else:
        rows = []
        spacing = 1
        front = slanted
        rows.append((front+1)*' ' + sentence[0])
        for i in range(1,slanted+1):
            str1 = front*' ' + sentence[i] + spacing*' ' + sentence[-i]
            rows.append(str1)
            spacing += 2
            front -= 1

        bottom = sentence[slanted+1: -slanted]
        rows.append(bottom)

        res_str = ''
        for row in rows:
            print(row)

    return True


 # added so that this script will run. feel free to modify it


# end of answer


print('Test 1')
print('Expected output:')
print('   a')
print('  b l')
print(' c   k')
print('defghij')
print('Expected return value:True')
print('Actual output:')
result = print_triangle('abcdefghijkl')
print('Actual return value  :' + str(result))
print()

print('Test 2')
print('Expected output:')
print('         A')
print('        B 9')
print('       C   8')
print('      D     7')
print('     E       6')
print('    F         5')
print('   G           4')
print('  H             3')
print(' I               2')
print('JKLMNOPQRSTUVWXYZ01')
print('Expected return value:True')
print('Actual output:')
result = print_triangle('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')
print('Actual return value  :' + str(result))
print()

print('Test 3')
print('Expected output:')
print('Expected return value:False')
print('Actual output:')
result = print_triangle('abcdefghij')
print('Actual return value  :' + str(result))
print()

print('Test 4')
print('Expected output:')
print('Expected return value:False')
print('Actual output:')
result = print_triangle('abc')
print('Actual return value  :' + str(result))
print()

print('Test 5')
print('Expected output:')
print(' a')
print('bcd')
print('Expected return value:True')
print('Actual output:')
result = print_triangle('abcd')
print('Actual return value  :' + str(result))
print()