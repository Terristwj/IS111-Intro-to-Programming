def compute_sum(m, n):
    sum_of_numbers = 0
    for i in range(m, n+1):
        sum_of_numbers += i
    return sum_of_numbers


my_sum = compute_sum(4, 10)
print("The sum is " + str(my_sum))
