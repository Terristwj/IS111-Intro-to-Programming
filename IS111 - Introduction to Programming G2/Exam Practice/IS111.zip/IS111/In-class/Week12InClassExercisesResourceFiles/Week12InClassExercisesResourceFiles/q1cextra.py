import datetime
date_of_today = str(datetime.date.today())
today_date_list = date_of_today.split('-')
print(today_date_list)
