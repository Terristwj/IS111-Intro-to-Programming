import datetime
date_of_today = str(datetime.date.today())
today_date_list = date_of_today.split('-')
print(date_of_today)

def valid_date(date,month):
    if date.isdigit() == False:
        return False

    date = int(date)
    month = int(month)
    if month == int(today_date_list[1]):
        if 1 <= date <= int(today_date_list[2]): #need change
            return True
    elif month in [1,3,5,7,8,10,12]:
        if 1 <= date <= 31:
            return True
    elif month == 2:
        if 1 <= date <= 28:
            return True
    else:
        if 1 <= date <= 30:
            return True

    return False

tasks_list = []
enter_task = input('Do you want to enter a task? [Y|N]:')

while enter_task == 'Y':
    task_description = input('Enter task description:')
    month = input('\nEnter the month it is due:')
    while month.isdigit() == False or int(month) < int(today_date_list[1]) or int(month) > 12:
        print('Sorry, invalid month!')
        month = input('\nEnter the month it is due:')

    date = input('\nEnter the date it is due:')
    while valid_date(date,month) == False:
        print('Sorry, invalid date!')
        date = input('\nEnter the date it is due:')

    print(f'\n{task_description} due on {date}/{month} has been recorded')
    tasks_list.append((task_description, date + '/' + month))

    enter_task = input('\nDo you want to continue? [Y|N]:')

task_dict = {}

for item in tasks_list:
    if item[1] not in task_dict:
        task_dict[item[1]] = [item[0]]
    else:
        task_dict[item[1]].append(item[0])
print('\nHere are the tasks you have entered')
for date in task_dict:
    print(f'\nDue on {date}')
    for task in task_dict[date]:
        print(f'\t{task}')
