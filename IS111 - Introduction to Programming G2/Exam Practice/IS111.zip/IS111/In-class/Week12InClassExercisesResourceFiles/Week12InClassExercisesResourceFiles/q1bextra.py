def sort_date(list_of_dates):
    altered_list = []
    sorted_dates = []
    for item in list_of_dates:
        day_month = item.split('/')
        day = int(day_month[0])
        month = int(day_month[1])
        day_month = (day,month)
        altered_list.append(day_month)
    count = 0
    while count != len(list_of_dates):
        smallest_month = 12
        smallest_day = 31
        earliest = ''
        for date in altered_list:
            if date[1] < smallest_month:
                smallest_month = date[1]
                smallest_day = date[0]
                earliest = date
            elif date[1] == smallest_month and date[0] < smallest_day:
                smallest_day = date[0]
                earliest = date
        sorted_dates.append(earliest)
        altered_list.remove(earliest)
        count += 1

    res_sorted = []
    for item in sorted_dates:
        res_sorted.append(str(item[0]) + '/' + str(item[1]))

    return res_sorted


print(sort_date(['11/11','10/10','12/11']))

def valid_date(date,month):
    if date.isdigit() == False:
        return False

    date = int(date)
    month = int(month)
    if month in [1,3,5,7,8,10,12]:
        if 1 <= date <= 31:
            return True
    elif month == 2:
        if 1 <= date <= 28:
            return True
    else:
        if 1 <= date <= 30:
            return True

    return False

tasks_list = []
enter_task = input('Do you want to enter a task? [Y|N]:')

while enter_task == 'Y':
    task_description = input('Enter task description:')
    month = input('\nEnter the month it is due:')
    while month.isdigit() == False or int(month) < 1 or int(month) > 12:
        print('Sorry, invalid month!')
        month = input('\nEnter the month it is due:')

    date = input('\nEnter the date it is due:')
    while valid_date(date,month) == False:
        print('Sorry, invalid date!')
        date = input('\nEnter the date it is due:')

    print(f'\n{task_description} due on {date}/{month} has been recorded')
    tasks_list.append((task_description, date + '/' + month))

    enter_task = input('\nDo you want to continue? [Y|N]:')

task_dict = {}

for item in tasks_list:
    if item[1] not in task_dict:
        task_dict[item[1]] = [item[0]]
    else:
        task_dict[item[1]].append(item[0])

date_list = list(task_dict)
sorted_dates = sort_date(date_list)

res_dict = {}
for date in sorted_dates:
    res_dict[date] = task_dict[date]

for date in res_dict:
    print(date)
    for task in res_dict[date]:
        print(task)