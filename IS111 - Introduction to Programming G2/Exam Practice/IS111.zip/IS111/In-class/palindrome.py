word = input("Enter a word :")

# Solution 1
is_palindrome = True
for i in range(0, len(word) // 2):
    if word[i] != word[len(word) - 1 - i]:
        is_palindrome = False

# Solution 2
# if word[::-1] == word:
    # is_palindrome = True
# else:
    # is_palindrome = False
        
if is_palindrome:
    print(word + " is a palindrome.")
else:
    print(word + " is NOT a palindrome.")