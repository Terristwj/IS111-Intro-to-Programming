row_dict = {}

with open('seating_plan.txt','r') as file:
    for line in file:
        line = line.rstrip('\n')
        info_list = line.split(',')

        row = info_list[0]
        seat_no = info_list[1]
        name = info_list[2]

        if row not in row_dict:
            row_dict[row] = [[seat_no, name]]
        else:
            row_dict[row].append([seat_no, name])

print(row_dict)

row_letter = input('Enter a letter (from A to E) :')
seat_num = input('Enter a seat number (from 1 to 25) :')
name = ''
for seat in row_dict[row_letter]:
    if seat[0] == seat_num:
        name += seat[1]

if len(name) == 0:
    print('\nSeat not taken')
else:
    print(f'\nThe person seated at the seat {row_letter}{seat_num} is {name}')