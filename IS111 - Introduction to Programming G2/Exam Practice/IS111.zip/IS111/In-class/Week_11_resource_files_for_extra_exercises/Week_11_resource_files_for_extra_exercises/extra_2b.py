friends_dict = {}

with open('friends.txt','r') as file:
    for line in file:
        line = line.rstrip('\n')
        pair = line.split('\t')
        friend1 = pair[0]
        friend2 = pair[1]
        if friend1 not in friends_dict:
            friends_dict[friend1] = [friend2]
        else:
            friends_dict[friend1].append(friend2)

        if friend2 not in friends_dict:
            friends_dict[friend2] = [friend1]
        else:
            friends_dict[friend2].append(friend1)

main_person = input('Enter person name: ')
friends = friends_dict['E']
degree = int(input('Enter degree of separation: '))

def get_friend_list(degree, friends, friends_dict):
    count = 1
    while count < degree:
        new_friend = friends
        for friend in new_friend:
            friends = friends + friends_dict[friend]
        count += 1

    res_list = []
    for person in friends:
        if person not in res_list and person != main_person:
            res_list.append(person)

    return res_list

n_degree = get_friend_list(degree, friends, friends_dict)
n_less_degree = get_friend_list(degree-1, friends,friends_dict)
nth_deg_friends = []
for name in n_degree:
    if name not in n_less_degree:
        nth_deg_friends.append(name)

print(nth_deg_friends)

