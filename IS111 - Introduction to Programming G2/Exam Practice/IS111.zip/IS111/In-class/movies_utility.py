def get_average_duration(list_tuples):
    length = len(list_tuples)
    if length == 0:
        return 0.0
    
    sum = 0
    for tuples in list_tuples:
        sum += tuples[2]
    return sum/length

def get_num_movies_of_genre(list_tuples, genre):
    length = len(list_tuples)
    if length == 0:
        return 0
    
    sum = 0
    for tuples in list_tuples:
        if tuples[1] == genre:
            sum += 1
    return sum

def get_title_of_longest_movie(list_tuples):
    length = len(list_tuples)
    if length == 0:
        return ''
    
    longest = 0
    for tuples in list_tuples:
        if tuples[2] > longest:
            longest = tuples[2]

    for tuples in list_tuples:
        if tuples[2] == longest:
            return tuples[0]

def get_movies_with_keyword(list_tuples, keyword):
    length = len(list_tuples)
    if length == 0:
        return []
    
    new_list = []
    for tuples in list_tuples:
        if keyword in tuples[0]:
            new_list.append(tuples)
            
    return new_list
        