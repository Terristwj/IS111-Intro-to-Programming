def say_hello(name):
    print('Hello',name,'!')
    
def say_bye(name):
    print('Bye',name,'!')
    
    