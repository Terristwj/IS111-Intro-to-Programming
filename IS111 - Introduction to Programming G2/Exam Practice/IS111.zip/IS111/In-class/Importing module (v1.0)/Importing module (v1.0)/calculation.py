import math

# prompt the user for a number
num = float(input('Enter a number :'))
# Calculate the square root of num
result = math.sqrt(num) 
# display the result
print('Square root of', num, 'is :', result)

