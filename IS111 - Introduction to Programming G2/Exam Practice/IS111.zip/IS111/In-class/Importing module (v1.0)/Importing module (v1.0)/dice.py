import random

dice_1 = random.randrange(1, 7)
dice_2 = random.randrange(1, 7)

print('Dice values: ', end='')
print(dice_1, 'and', dice_2)