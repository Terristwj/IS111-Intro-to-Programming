def binary_to_decimal(binary):
    power = len(binary) - 1
    pos = 0
    decimal = 0
    while power >= 0:
        num = int(binary[pos])
        decimal += num * (2**power)
        power -= 1
        pos += 1

    return decimal

print(binary_to_decimal('1001100'))