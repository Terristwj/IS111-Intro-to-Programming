def count_perfect_square(a,b):
    num = 0
    for i in range(a,b+1):
        sqrt = i**(1/2) # this will give a float num
        remainder = sqrt % 1
        if remainder == 0:
            num += 1
    return num

print(count_perfect_square(4,30))