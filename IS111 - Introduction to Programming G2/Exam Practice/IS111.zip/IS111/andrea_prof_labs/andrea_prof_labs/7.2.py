def multiplication_table(n):
    count = 1
    while count <= 10:
        res = n * count
        print(f'{str(count)} x {str(n)} = {str(res)}')
        count += 1


multiplication_table(7)