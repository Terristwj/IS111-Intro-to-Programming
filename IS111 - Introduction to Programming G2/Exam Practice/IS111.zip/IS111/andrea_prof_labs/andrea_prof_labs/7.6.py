def factorial(num):
    product = 1
    for i in range(1,num+1):
        product *= i
    return product

def sin(x,n):
    power = 1
    fraction = factorial(1)
    pos_neg = 1
    total = 0
    while power != n:
        total += (x ** power) / fraction
        power += 2
        fraction = factorial(power)
        pos_neg *= (-1)
        fraction = fraction * pos_neg

    total += (x ** power) / fraction

    return round(total,5)

print(sin(5,29))
print(sin(-0.2,19))