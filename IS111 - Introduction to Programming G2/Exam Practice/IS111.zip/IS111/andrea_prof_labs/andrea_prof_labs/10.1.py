def compute_statistics(grades):
    list_grades = list(grades)
    max = 0
    min = grades[list_grades[0]]
    sum_scores = 0
    for key in grades:
        sum_scores += grades[key]
        if grades[key] > max:
            max = grades[key]
        elif grades[key] < min:
            min = grades[key]
    mean = sum_scores / len(grades)
    mean = round(mean,2)

    new_dict = {}
    new_dict['min'] = min
    new_dict['max'] = max
    new_dict['mean'] = mean

    print(new_dict)

# compute_statistics({'A':9, 'B':8.5, 'C':7, 'D':3.5, 'E':1.5, 'F':7})
# # returns {'min': 1.5, 'max': 9, 'mean': 6.08}
# compute_statistics({'A':22, 'B':33, 'C':44, 'D':55, 'E':66})
# # returns {'min': 22, 'max': 66, 'mean': 44.0}

def combine_demographics(weight_dict, height_dict, age_dict):
    list_names = list(weight_dict)
    res_dict = {}
    for name in list_names:
        weight = weight_dict[name]
        height = height_dict[name]
        age = age_dict[name]
        tuple = (weight,height,age)
        res_dict[name] = tuple
    return res_dict

# weight_dict = {'Anne':53, 'Bob':37, 'Carol':83, 'Dave':44}
# height_dict = {'Anne':1.56, 'Bob':1.34, 'Carol':1.8, 'Dave':1.7}
# age_dict = {'Anne':15, 'Bob':17, 'Carol':21, 'Dave':14}
# print(combine_demographics(weight_dict, height_dict, age_dict))

def compute_scrabble_score(word):
    word = word.lower()
    score_dict = {'aeioulnrst':1,'bcmp':3,'dg':2,'fhvwy':4,'k':5,'x':8,'qz':10}
    score = 0
    for ch in word:
        for key in score_dict:
            if ch in key:
                score += score_dict[key]

    print(score)

compute_scrabble_score('apple') # returns 9
compute_scrabble_score('Programming') # returns 19