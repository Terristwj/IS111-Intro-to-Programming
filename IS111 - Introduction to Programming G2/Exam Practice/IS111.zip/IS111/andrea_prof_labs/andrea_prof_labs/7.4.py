def decimal_to_binary(d):
    quotient = d//2
    remainder = d % 2
    binary = ''
    print(d,quotient,remainder)

    while quotient != 0:
        binary += str(remainder)
        new_num = quotient
        quotient = new_num//2
        remainder = new_num%2
        print(new_num,quotient,remainder)

    binary += str(remainder)
    res = ''
    for i in range(len(binary)-1,-1,-1):
        res += binary[i]
    return res

print(decimal_to_binary(76))
print(bin(76))