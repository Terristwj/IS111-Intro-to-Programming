import random as r
def random_generator(num1, num2, num3):
    sum_num = 0
    integer = r.randint(num1,num2)
    sum_num += integer
    print(f'Adding {str(integer)}, total is {str(sum_num)}')

    while sum_num <= num3:
        integer = r.randint(num1, num2)
        sum_num += integer
        print(f'Adding {str(integer)}, total is {str(sum_num)}')

    return sum_num

print(random_generator(3,10,15))