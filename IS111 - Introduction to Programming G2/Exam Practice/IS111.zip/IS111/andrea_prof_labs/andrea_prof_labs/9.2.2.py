def compute_diagonal_diff(matrix):
    left_pos = 0
    right_pos = (len(matrix)-1)
    left_sum = 0
    right_sum = 0

    for i in range(len(matrix)):
        left_sum += matrix[i][left_pos]
        right_sum += matrix[i][right_pos]

        left_pos += 1
        right_pos -= 1

    difference = left_sum - right_sum
    if difference < 0:
        difference *= (-1)

    print(difference)

compute_diagonal_diff([[1,2,3], [4,5,6], [8,8,9]]) # returns 1
compute_diagonal_diff([[11,2,4,4],[10,4,-4,3],[1,1,5,5],[3,3,-8,4]])


