with open('lab-11-mobile.csv','r') as file:
    year_dict ={}
    for line in file:
        line = line.rstrip('\n')
        info = line.split(',')
        if '-' in info[0]:
            year = info[0].split('-')[0]
            info[1] = float(info[1])

            if year not in year_dict:
                year_dict[year] = info[1]
            else:
                year_dict[year] += info[1]
with open('lab-11-mobile-output.csv','w') as file:
    file.write('year,volume_of_mobile_data')
    for year in year_dict:
        data = round(year_dict[year],5)
        file.write(f'\n{year},{data}')
