with open('lab-11-internet.csv','r') as file:
    for line in file:
        line = line.rstrip('\n')
        print(line)

