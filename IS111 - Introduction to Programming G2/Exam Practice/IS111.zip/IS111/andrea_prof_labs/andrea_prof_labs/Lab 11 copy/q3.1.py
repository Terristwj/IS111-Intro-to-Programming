with open('lab-11-secondary.csv','r') as file:
    year_dict = {}
    for line in file:
        line = line.rstrip('\n')
        info = line.split(',')
        year = info[0]
        gender = info[3]
        if info[0].isdigit():
            num = int(info[4])
            if gender == 'MF':
                if year not in year_dict:
                    year_dict[year] = num
                else:
                    year_dict[year] += num
            if gender == 'F':
                if year not in year_dict:
                    year_dict[year] = -num
                else:
                    year_dict[year] -= num

print(year_dict)