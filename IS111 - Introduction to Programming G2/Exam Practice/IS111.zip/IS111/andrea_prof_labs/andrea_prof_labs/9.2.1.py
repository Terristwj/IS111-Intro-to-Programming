def play_music(playlist, commute_duration):
    songs_played = 0
    song_time = 0

    song_index = 0
    song_time += playlist[song_index][1]

    while song_time <= commute_duration and song_index < (len(playlist)-1):
        songs_played += 1
        song_index += 1
        song_time += playlist[song_index][1]


    if song_index == (len(playlist)-1):
        song_time += playlist[song_index][1]
        if song_time <= commute_duration:
            songs_played += 1


    print(songs_played)

play_music([('a',360),('b',300),('c',220),('d',400)],0) # returns 0
play_music([('a',360),('b',300),('c',220),('d',400)],40) # returns 0
play_music([('a',360),('b',300),('c',220),('d',400)],290) # returns 0
play_music([('a',360),('b',300),('c',220),('d',400)],660) # returns 2
play_music([('a',360),('b',300),('c',220),('d',400)],900) # returns 3
play_music([('a',360),('b',300),('c',220),('d',400)],2000) # returns 4



