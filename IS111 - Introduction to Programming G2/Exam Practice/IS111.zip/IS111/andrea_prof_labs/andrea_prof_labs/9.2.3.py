def compute_diagonal(matrix):
    left_pos = 0
    right_pos = (len(matrix)-1)
    left_sum = 0
    right_sum = 0

    for i in range(len(matrix)):
        left_sum += matrix[i][left_pos]
        right_sum += matrix[i][right_pos]

        left_pos += 1
        right_pos -= 1
    if left_sum == right_sum:
        return left_sum
    else:
        return False

def compute_vertical(matrix):
    vertical_sum = []
    for i in range(len(matrix)):
        sum = 0
        for row in matrix:
            sum += row[i]

        vertical_sum.append(sum)
    print(vertical_sum)
    first = vertical_sum[0]
    for num in vertical_sum:
        if num != first:
            return False

    return first

def compute_horizontal(matrix):
    horizontal_sum = []
    for item in matrix:
        sum = 0
        for num in item:
            sum += num
        horizontal_sum.append(sum)
    print(horizontal_sum)
    first = horizontal_sum[0]
    for num in horizontal_sum:
        if num != first:
            return False

    return first

def check_magic_square(matrix):
    diagonal = compute_diagonal(matrix)
    vertical = compute_vertical(matrix)
    horizontal = compute_horizontal(matrix)

    if diagonal == False or vertical == False or horizontal == False:
        return False
    elif diagonal == vertical and diagonal == horizontal:
        return True
    else:
        return False

print(check_magic_square([[2,7,6], [9,5,1], [4,3,8]])) # returns True
print(check_magic_square([[1,2,3], [4,5,6], [7,8,9]])) # returns False
print(check_magic_square([[16,3,2,13], [5,10,11,8], [9,6,7,12],[4,15,14,1]])) # returns True
