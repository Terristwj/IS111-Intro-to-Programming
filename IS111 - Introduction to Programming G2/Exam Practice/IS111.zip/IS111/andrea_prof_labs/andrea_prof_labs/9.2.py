def robot_dest(directions):
    x_pos = 0
    y_pos = 0

    for ch in directions:
        if ch == 'U':
            y_pos += 1
        elif ch == 'L':
            x_pos -= 1
        elif ch == 'R':
            x_pos += 1
        elif ch == 'D':
            y_pos -= 1
    return (x_pos,y_pos)

print(robot_dest('UULRDRDDDD'))