import random as r

def snake_and_ladders(snakeladder_list):
    board_num = 0
    roll_dice = input("Enter 'r' to roll the dice, or type 'No' to quit: ")

    while roll_dice == 'r':
        steps = r.randint(1,6)
        board_num += steps
        pos_snakeladder = ''
        for item in snakeladder_list:
            if board_num == item[0]:
                board_num += item[1]
                pos_snakeladder = str(item[0])
                step_snakeladder = str(item[1])

        if pos_snakeladder != '':
            print(f'The dice number is {str(steps)} and you land on a space with ({pos_snakeladder},{step_snakeladder}).Your new board number is {board_num}.')
        else:
            print(f'The dice number is {str(steps)}.Your new board number is {board_num}.')

        if board_num >= 20:
            print('You win the game!')
            break

        roll_dice = input("Enter 'r' to roll the dice, or type 'No' to quit: ")


    if roll_dice == 'No':
        print('Thank you for playing.')

snake_and_ladders([(6,-3), (10,5), (13,-2),(14,5), (18,-6)])