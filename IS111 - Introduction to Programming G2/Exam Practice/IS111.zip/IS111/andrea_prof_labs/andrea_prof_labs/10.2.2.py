def validate_isbn10(string):
    last = string[-1]
    middle = string.replace('-','')
    middle = middle[0:-1]
    print(middle)
    if len(middle) != 9:
        print(False)
        return False
    total = 0
    multiplication_weight = {0:10,1:9,2:8,3:7,4:6,5:5,6:4,7:3,8:2}
    for i in range(len(middle)):
        product = int(middle[i]) * multiplication_weight[i]
        total += product

    remainder = total % 11
    temp2 = 11 - remainder
    if temp2 == int(last):
        print(True)
    else:
        print(False)

validate_isbn10('0-3064-0615-2') # returns True
validate_isbn10('03064-06152') # returns True
validate_isbn10('0-545-01022-5') # returns True
validate_isbn10('0-3064-0615-20') # returns False (has 11 digits)
validate_isbn10('0-545-01022-4') # returns False (incorrect checksum)