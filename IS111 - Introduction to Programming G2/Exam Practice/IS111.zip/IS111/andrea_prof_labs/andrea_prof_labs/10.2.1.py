def compute_checksum(partial_nric):
    num_in_nric = partial_nric[1:]
    starting_letter = partial_nric[0]
    total = 0
    multiplication_weight = {0:2,1:7,2:6,3:5,4:4,5:3,6:2}
    for i in range(len(num_in_nric)):
        product = int(num_in_nric[i]) * multiplication_weight[i]
        total += product

    if starting_letter in 'TG':
        total += 4

    remainder = total % 11

    st_dict = {10:'A',9:'B',8:'C', 7:'D',6:'E',5:'F',4:'G',3:'H',2:'I',1:'Z',0:'J'}
    fg_dict = {10:'K',9:'L',8:'M', 7:'N',6:'P',5:'Q',4:'R',3:'T',2:'U',1:'W',0:'X'}

    if starting_letter in 'ST':
        res = st_dict[remainder]
    else:
        res = fg_dict[remainder]

    print(res)

compute_checksum('S1234567') # returns 'D'
compute_checksum('G1234567') # returns 'X'
compute_checksum('T7654321') # returns 'B'
compute_checksum('F7654321') # returns 'Q'
