#
# Name    :
# Email ID:
#
def str_reverse(message):
    res = ''
    for i in range(len(message)-1,-1,-1):
        res += message[i]
    return res

print(str_reverse('hello'))

def encode(message, num_rows):
    new_str = ''
    for ch in message:
        if ch.isalnum():
            new_str += ch.upper()

    split_str = []

    for i in range(0,len(new_str),num_rows):
        string_to_add = new_str[i:i+num_rows]
        split_str.append(string_to_add)

    split_columns = []
    for i in range(len(split_str)):
        if i % 2 == 0:
            to_edit = str_reverse(split_str[i])
            split_columns.append(to_edit)
        else:
            split_columns.append(split_str[i])

    if len(split_columns) % 2 != 0:
        if len(split_columns[-1]) != num_rows:
            num_hex = num_rows - len(split_columns[-1])
            split_columns[-1] = '#'*num_hex + split_columns[-1]
    elif len(split_columns) % 2 == 0:
        if len(split_columns[-1]) != num_rows:
            num_hex = num_rows - len(split_columns[-1])
            split_columns[-1] = split_columns[-1] + '#'*num_hex
    print(split_columns)

    res_str = ''
    pos1 = num_rows-1
    pos2 = 0
    for i in range(num_rows//2):
        res_str += split_columns[pos1][pos2:pos1+1]
        second = ''
        for column in split_columns:
            second += column[pos1]
        second = str_reverse(second)
        res_str += second[pos2+1:pos1+1]

        third = str_reverse(split_columns[pos2])
        res_str += third[pos2+1:pos1+1]


        fourth = ''
        for column in split_columns:
            fourth += column[pos2]
        res_str += fourth[pos2+1:pos1]
        print(res_str)
        pos1 -= 1
        pos2 += 1

    return res_str

if __name__ == "__main__":
    num = 0

    num += 1
    print(f'Test {num}')
    print('Expected:#ODYEHTNENJETHESTARSSYTTERTHAWIEBTSUMUOEBYAHALOUS')
    result = encode(
        "The stars must be jealous. You shine way better than they do!", 7)
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    print('Expected:DOEHAHETBYENSUSUAEBTMSTSTHEARUSEJLOYOHIWAETRTNTY')
    result = encode(
        "The stars must be jealous. You shine way better than they do!", 2)
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    print('Expected:#######ODYEHOYTHESTARSMUSTBETTERTHANTUSUOLAEJEBYAWENIHS')
    result = encode(
        "The stars must be jealous. You shine way better than they do!", 11)
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    print('Expected:EENDTNHSIS111LGHTOOAEWLO')
    result = encode("IS111. We shall go on to the end.", 4)
    print(f'Actual  :{result}')
    print()
