#
# Name    :
# Email ID:
#


def expand(compressed):
    res = ''
    current_pos = 0
    current_char = compressed[current_pos]
    while current_char != ']':



        if current_char.isdigit():
            rest_of_string = compressed[current_pos+1:]
            manipulated_string = rest_of_string[1:-1]
            if manipulated_string.isalpha():
                res = manipulated_string * int(current_char)
                return res
            else:
                add = expand(manipulated_string)
                res+= add
                length_manipulated = len(manipulated_string)
                current_pos += length_manipulated + 2
        elif current_char.isalpha():
            res += current_char

        current_pos += 1
        current_char = compressed[current_pos]

    return res








if __name__ == "__main__":
    num = 0

    num += 1
    print(f'Test {num}')
    result = expand('2[abc]')
    print('Expected:abcabc')
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = expand('2[abc]')
    print('Expected:abcabc')
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = expand('AA20[SIS]AA')
    print('Expected:AASISSISSISSISSISSISSISSISSISSISSISSISSISSISSISSISSISSISSISSISAA')
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = expand('2[ab]3[cd]')
    print('Expected:ababcdcdcd')
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = expand('3[2[ab]3[cd]]')
    print('Expected:ababcdcdcdababcdcdcdababcdcdcd')
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = expand('4[2[a]3[cd]def]')
    print('Expected:aacdcdcddefaacdcdcddefaacdcdcddefaacdcdcddef')
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = expand('2[3[ab2[c]]Z]')
    print('Expected:abccabccabccZabccabccabccZ')
    print(f'Actual  :{result}')
    print()
