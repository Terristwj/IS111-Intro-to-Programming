#
# Name    :
# Email ID:
#


def get_pairs_with_total(num_pairs, total):
    res = []
    for pair in num_pairs:
        if pair[0] + pair[1] == total:
            res.append(pair)

    return res

if __name__ == "__main__":
    num_pairs = [(3, 4), (5, 4), (3, 3), (2, 0), (5, 2), (-1, 8)]
    print('Test 1')
    result = get_pairs_with_total(num_pairs, 7)
    print('Expected:[(3, 4), (5, 2), (-1, 8)]')
    print(f'Actual  :{result}')
    print()

    num_pairs = [(3, 4), (5, 4), (3, 3), (2, 0), (5, 2), (-1, 8)]
    print('Test 2:Check data type')
    result = get_pairs_with_total(num_pairs, 7)
    print("Expected:<class 'list'> <class 'tuple'> <class 'int'> <class 'int'>")
    print(
        f'Actual  :{type(result)} {type(result[0])} {type(result[0][0])} {type(result[0][1])}')
    print()

    num_pairs = [(4, 4), (5, 4), (3, 3), (2, 0), (54, 2), (-3, 8)]
    print('Test 3')
    result = get_pairs_with_total(num_pairs, 79)
    print("Expected:[]")
    print(f'Actual  :{result}')
    print()

    num_pairs = []
    print('Test 4')
    result = get_pairs_with_total(num_pairs, 79)
    print("Expected:[]")
    print(f'Actual  :{result}')
    print()
