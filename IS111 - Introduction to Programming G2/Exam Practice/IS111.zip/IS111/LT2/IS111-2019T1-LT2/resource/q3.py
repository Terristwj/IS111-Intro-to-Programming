#
# Name    :
# Email ID:
#


def rotate(matrix):
    num_of_row = len(matrix)
    num_column = len(matrix[0])
    res = []

    if num_of_row == num_column:
        pos = -1
        for i in range(num_of_row):
            res_row = []
            for row in matrix:
                res_row.append(row[pos])
            pos -= 1
            res.append(res_row)
    else:
        pos = -1
        for i in range(num_column):
            res_row = []
            for row in matrix:
                res_row.append(row[pos])
            res.append(res_row)
            pos -=1

    return res


if __name__ == "__main__":
    num = 0

    matrix = [[1, 2, 3, 4],
              [5, 6, 7, 8],
              [9, 10, 11, 12],
              [13, 14, 15, 16]]

    result = rotate(matrix)
    num += 1
    print(f'Test {num}')
    print(
        'Expected:[[4, 8, 12, 16], [3, 7, 11, 15], [2, 6, 10, 14], [1, 5, 9, 13]]')
    print(f'Actual  :{result}')
    print()

    matrix = [[1, 2, 3, 4],
              [5, 6, 7, 8],
              [9, 10, 11, 12],
              [13, 14, 15, 16]]
    result = rotate(matrix)
    num += 1
    print(f'Test {num}')
    print("Expected:<class 'list'> <class 'list'> <class 'int'>")
    print(f'Actual  :{type(result)} {type(result[0])} {type(result[0][0])}')
    print()

    matrix = [[1, 2],
              [5, 6],
              [9, 10],
              [13, 14]]
    result = rotate(matrix)
    num += 1
    print(f'Test {num}')
    print("Expected:[[2, 6, 10, 14], [1, 5, 9, 13]]")
    print(f'Actual  :{result}')
    print()

    matrix = [[1, 2, 3, 4],
              [5, 6, 7, 8]]
    result = rotate(matrix)
    num += 1
    print(f'Test {num}')
    print("Expected:[[4, 8], [3, 7], [2, 6], [1, 5]]")
    print(f'Actual  :{result}')
    print()

    matrix = [[1, 2, 3]]
    result = rotate(matrix)
    num += 1
    print(f'Test {num}')
    print("Expected:[[3], [2], [1]]")
    print(f'Actual  :{result}')
    print()

    matrix = [[4], [3], [2], [1]]
    result = rotate(matrix)
    num += 1
    print(f'Test {num}')
    print("Expected:[[4, 3, 2, 1]]")
    print(f'Actual  :{result}')
    print()
