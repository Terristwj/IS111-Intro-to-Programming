#
# Name    :
# Email ID:
#


def expand(compressed):
    res = ''
    current_pos = 0
    current_char = compressed[current_pos]
    num = 1


    while current_char != ']':
        if current_char.isdigit():
            num = int(current_char)
        elif current_char == '[':
            pass
        elif current_char.isalpha():
            add = ''
            while current_char.isalpha():
                add += current_char
                current_pos += 1
                current_char = compressed[current_pos]
                print(current_pos)
            current_pos -= 1
            res += (num*add)


        current_pos += 1
        current_char = compressed[current_pos]
    if current_pos < len(compressed)-1:
        rest = compressed[current_pos+1:]
        if '[' in rest:
            res += expand(rest)
        elif res.isalpha():
            res += rest

    return res








if __name__ == "__main__":
    num = 0

    num += 1
    print(f'Test {num}')
    result = expand('2[abc]')
    print('Expected:abcabc')
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = expand('2[abc]')
    print('Expected:abcabc')
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = expand('AA2[SIS]AA')
    print('Expected:AASISSISAA')
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = expand('2[ab]3[cd]')
    print('Expected:ababcdcdcd')
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = expand('3[2[ab]3[cd]]')
    print('Expected:ababcdcdcdababcdcdcdababcdcdcd')
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = expand('4[2[a]3[cd]def]')
    print('Expected:aacdcdcddefaacdcdcddefaacdcdcddefaacdcdcddef')
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = expand('2[3[ab2[c]]Z]')
    print('Expected:abccabccabccZabccabccabccZ')
    print(f'Actual  :{result}')
    print()
