#
# Name    :
# Email ID:
#


def get_free_timings(filename, target_building, target_facility, target_date):
    room_dict = {}
    with open(filename, 'r') as file:
        for line in file:
            line = line.rstrip('\n')
            info_list = line.split(' ')
            info_list_final = []
            for item in info_list:
                if item == '':
                    pass
                elif '\t' in item:
                    to_add = item.split('\t')
                    for element in to_add:
                        info_list_final.append(element)
                else:
                    info_list_final.append(item)

            school = info_list_final[0]
            room = info_list_final[1]
            date = info_list_final[2]

            if len(info_list_final) > 3:
                time = info_list_final[3].split(',')
                time = free_timing_from_list(time)
            else:
                time = ('08:00','22:00')
            sch_room_key = (school, room)
            room_dict[sch_room_key] = {date: time}


        key_concerned = (target_building,target_facility)
        return room_dict[key_concerned][target_date]


def free_timing_from_list(list_time):
    free_timing = []
    timeslot1 = list_time[0].split('-')
    start = timeslot1[0]
    if start != '08:00':
        first_timing = ('08:00', start)
        free_timing.append(first_timing)

    for i in range(len(list_time)-1):
        timeslot1 = list_time[i].split('-')
        end = timeslot1[1]

        timeslot2 = list_time[i+1].split('-')
        start = timeslot2[0]

        if end != start:
            free_time = (end,start)
            free_timing.append(free_time)

    timeslot2 = list_time[-1].split('-')
    end = timeslot2[1]
    if end != '22:00':
        end_timing = (end, '22:00')
        free_timing.append(end_timing)

    return free_timing

if __name__ == "__main__":
    num = 0

    num += 1
    print(f'Test {num}')  # 1
    timings = get_free_timings('bookings.txt', 'SIS', 'SR2.2', '12/12/2019')
    print("Expected:<class 'list'> <class 'tuple'>")
    print(f'Actual  :{type(timings)} {type(timings[0])}')
    print()

    num += 1
    print(f'Test {num}')  # 2
    timings = get_free_timings('bookings.txt', 'SIS', 'SR2.2', '12/12/2019')
    print("Expected:[('08:00', '11:30'), ('11:45', '22:00')]")
    print(f'Actual  :{timings}')
    print()

    num += 1
    print(f'Test {num}')  # 3
    timings = get_free_timings('bookings.txt', 'SIS', 'SR2.1', '12/12/2019')
    print(
        "Expected:[('08:00', '11:30'), ('11:45', '12:30'), ('13:30', '14:20'), ('15:00', '22:00')]")
    print(f'Actual  :{timings}')
    print()

    timings = get_free_timings('bookings.txt', 'SIS', 'SR3.4', '12/12/2019')
    num += 1
    print(f'Test {num}')  # 4
    print("Expected:[('08:00', '22:00')]")
    print(f'Actual  :{timings}')
    print()

    timings = get_free_timings('bookings.txt', 'SIS', 'SR2.3', '12/12/2019')
    num += 1
    print(f'Test {num}')  # 5
    print("Expected:[]")
    print(f'Actual  :{timings}')
    print()


    timings = get_free_timings('bookings.txt', 'SIS', 'SR3.1', '12/12/2019')
    num += 1
    print(f'Test {num}')  # 6
    print("Expected:[('08:00', '08:01')]")
    print(f'Actual  :{timings}')
    print()


    # Note: this is reading from a different file
    timings = get_free_timings('bookings2.txt', 'SOA', 'SR2.4', '12/12/2019')
    num += 1
    print(f'Test {num}')
    print("Expected:[('12:45', '22:00')]")
    print(f'Actual  :{timings}')
    print()
