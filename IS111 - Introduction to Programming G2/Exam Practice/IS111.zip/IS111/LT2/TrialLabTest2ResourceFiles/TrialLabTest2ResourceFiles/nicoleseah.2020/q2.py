# Name: Nicole Seah
# Email ID: nicoleseah.2020
def check_valid_email(email):
    if ' ' in email:
        return False

    num_symbol = 0
    for ch in email:
        if ch == '@':
            num_symbol += 1

    if num_symbol != 1:
        return False

    ch_index = 0
    ch_before_symbol = 0
    while email[ch_index] != '@':
        ch_before_symbol += 1
        ch_index += 1

    if ch_before_symbol < 1:
        return False

    name_domain = email.split('@')
    if '.' not in name_domain[1]:
        return False

    return True



def create_email_dict(orig_dict):
    new_dict = {}

    for name in orig_dict:
        for email in orig_dict[name]:
            if check_valid_email(email) == True:
                new_dict[email] = name

    return new_dict

if __name__ == "__main__":

    print('Test Case 1:')
    result = create_email_dict(
    { 'Eric Lim' : ['ericlim@gmail.com',
                'eric.lim.2020@sis.smu.edu.sg'],
      'George Tan' : ['gtan@microsoft@com',
                  'george_tan@apple.com',
                  'george.tan.2019@smu.edu.sg'],
      'Wendy Liew' : ['wendy.liew@com']})

    print("Expected: {'ericlim@gmail.com': 'Eric Lim', 'eric.lim.2020@sis.smu.edu.sg': 'Eric Lim', 'george_tan@apple.com': 'George Tan', 'george.tan.2019@smu.edu.sg': 'George Tan'}")
    print('Actual  : ' + str(result))

    print("Expected type of returned value: <class 'dict'>")
    print('Actual type of returned value  : ' + str(type(result)))


    print('\nTest Case 2:')
    result = create_email_dict(
    { 'Eric Lim' : ['ericlim@gmail.com',
                '@sis.smu.edu.sg'],
      'George Tan' : ['gtan@ com',
                  'george_tan@apple.com',
                  'george.tan.2019.smu.edu.sg']
    })
    print("Expected: {'ericlim@gmail.com': 'Eric Lim', 'george_tan@apple.com': 'George Tan'}")
    print('Actual  : ' + str(result))

    print('\nTest Case 3:')
    result = create_email_dict({})
    print("Expected: {}")
    print('Actual  : ' + str(result))