# Name: Nicole Seah
# Email ID: nicoleseah.2020
def process_numbers(input_filename, output_filename):
    with open(output_filename, 'w') as out_file:
        out_file.write('')

    total_group = 0
    avg_list_total = []
    with open(input_filename,'r') as in_file:
        for line in in_file:
            avg_list_separated = []
            line = line.rstrip('\n')
            item_list = line.split('#')
            num_item = len(item_list)
            total_group += num_item

            for item in item_list:
                num_list = item.split(' ')
                sum = 0
                for num in num_list:
                    sum += float(num)
                avg = sum/(len(num_list))
                avg_list_separated.append(avg)
                avg_list_total.append(avg)

            str_avg_list = []
            for num in avg_list_separated:
                str_avg_list.append(str(num))

            with open(output_filename,'a') as out_file:
                out_file.write(str(num_item) + ': ' + '#'.join(str_avg_list) + '\n')

    max = float(avg_list_total[0])
    for num in avg_list_total:
        if float(num) > max:
            max = float(num)

    with open(output_filename,'a') as out_file:
        out_file.write(f'\nTotal number of groups: {total_group}\nMaximum average: {max}')

    

if __name__ == "__main__":
    print("Test Case 1:")
    print()

    process_numbers("numbers-1.txt", "output-1.txt")
    print("Please check whether the file 'output-1.txt' generated is the same as the file 'expected-output-1.txt' that we've provided.")

    print()
    print("Test Case 2:")
    print()

    process_numbers("numbers-2.txt", "output-2.txt")
    print("Please check whether the file 'output-2.txt' generated is the same as the file 'expected-output-2.txt' that we've provided.")