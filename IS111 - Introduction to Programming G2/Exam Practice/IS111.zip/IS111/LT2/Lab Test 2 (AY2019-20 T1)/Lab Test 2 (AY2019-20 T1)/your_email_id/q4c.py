# Name:
# Email ID:
def get_relation_through_link(family_dict, link):
    relation_map_dict = {}
    with open('relation_mapping.txt', 'r') as relations:
        for line in relations:
            line = line.rstrip('\n')
            relation_status = line.split(':')
            relation = relation_status[0]
            status = relation_status[1]
            relation_map_dict[relation] = status

    pairs = []
    for i in range(len(link) - 1):
        name1 = link[i]
        name2 = link[i + 1]
        pairs.append((name1, name2))
    print(pairs)

    if len(pairs) == 2:
        relation1 = family_dict[pairs[0]]
        relation2 = family_dict[pairs[1]]
        # print(relation1 + '---' + relation2)
        relationship = '(' + relation1 + ',' + relation2 + ')'
        res = relation_map_dict[relationship]

    elif len(pairs) == 1:
        res = family_dict[pairs[0]]

    else:
        relation2 = family_dict[pairs[1]]
        relation1 = family_dict[pairs[0]]
        relation3 = family_dict[pairs[2]]

        intermediate_rs = '(' + relation1 + ',' + relation2 + ')'
        relation4 = relation_map_dict[intermediate_rs]
        relationship = '(' + relation4 + ',' + relation3 + ')'
        res = relation_map_dict[relationship]

        # res = (relation1,relation2,relation3)
    return res


def get_relation(family_dict, p1, p2):
    relation_map_dict = {}
    with open('relation_mapping.txt', 'r') as relations:
        for line in relations:
            line = line.rstrip('\n')
            relation_status = line.split(':')
            relation = relation_status[0]
            status = relation_status[1]
            relation_map_dict[relation] = status

    list_fam = list(family_dict)
    link = form_link(list_fam,p1,p2)
    res = get_relation_through_link(family_dict,link)
    return res

def form_link(list_fam,p1,p2):
    pair_list =[]
    for item in list_fam:
        if p1 == item[0]:
            print(item[0])
            pair_list.append(item)
        elif p2 == item[1]:
            print(item[1])
            pair_list.append(item)
    print(pair_list)


    if pair_list[0][1] != pair_list[1][0]:
        for item in list_fam:
            if item[0] == pair_list[0][1] and item[1] == pair_list[1][0]:
                pair_list.insert(1,item)
    print(pair_list)

    link_list = []
    for pair in pair_list:
        if pair[0] not in link_list:
            link_list.append(pair[0])
            link_list.append(pair[1])
        elif pair[0] in link_list:
            link_list.append(pair[1])
    print(link_list)
    return link_list

    