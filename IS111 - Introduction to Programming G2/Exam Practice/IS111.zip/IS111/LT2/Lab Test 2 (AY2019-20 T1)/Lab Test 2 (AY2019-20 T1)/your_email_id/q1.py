# Name:
# Email ID:

def compute_product(num_list):
    odd_list = []
    for num in num_list:
        if num % 2 != 0:
            odd_list.append(num)

    res = 1
    for num in odd_list:
        res *= num

    return res
    