# Name:
# Email ID:

def store_family_relations(family_file):
    relationship_dict = {}
    with open(family_file,'r') as file:
        for line in file:
            line = line.rstrip('\n')
            name_list = line.split("(")
            name_list = name_list[1:]

            parents_names = name_list[0].split(',')
            father = parents_names[0]
            mother = parents_names[1].replace(')','')
            mother = mother.replace(':','')

            children = name_list[1:]
            for name in children:
                name = name.replace(')','')
                name = name.replace(';','')
                name_gender = name.split(',')
                name_of_child = name_gender[0]
                gender = name_gender[1]

                key_dict_father = (father, name_of_child)
                key_dict_mother = (mother, name_of_child)

                relationship_dict[key_dict_father] = 'father'
                relationship_dict[key_dict_mother] = 'mother'

                if gender == 'M':
                    key_dict_f = (name_of_child, father)
                    key_dict_m = (name_of_child, mother)

                    relationship_dict[key_dict_f] = 'son'
                    relationship_dict[key_dict_m] = 'son'
                else:
                    key_dict_f = (name_of_child, father)
                    key_dict_m = (name_of_child, mother)

                    relationship_dict[key_dict_f] = 'daughter'
                    relationship_dict[key_dict_m] = 'daughter'

    return relationship_dict
    