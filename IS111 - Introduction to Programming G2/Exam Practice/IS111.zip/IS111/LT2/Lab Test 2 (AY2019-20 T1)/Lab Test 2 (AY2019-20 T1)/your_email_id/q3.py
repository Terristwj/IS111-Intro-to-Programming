# Name:
# Email ID:

def compute_total_price(price_dict, item_list):
    total_price = 0.0
    for item in item_list:
        item_name = item[0]

        if item_name in price_dict:
            item_quantity = item[1]
            item_price = price_dict[item_name]
            price = item_price * item_quantity
            total_price += price
    return total_price