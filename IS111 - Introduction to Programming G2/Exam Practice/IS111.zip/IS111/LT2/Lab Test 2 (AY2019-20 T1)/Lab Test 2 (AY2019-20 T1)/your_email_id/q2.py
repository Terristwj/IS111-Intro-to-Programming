# Name:
# Email ID:

def get_longer_words(file_name):
    longer_word = []
    with open(file_name,'r') as file:
        for line in file:
            line = line.rstrip('\n')
            split_line = line.split('&')
            if len(split_line[0]) >= len(split_line[1]):
                longer_word.append(split_line[0])
            else:
                longer_word.append(split_line[1])
    return longer_word