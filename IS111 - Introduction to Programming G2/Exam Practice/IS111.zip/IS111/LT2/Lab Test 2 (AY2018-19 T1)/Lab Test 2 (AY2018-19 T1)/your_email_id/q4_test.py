import q4

mrt_map = [ ['Botanic Gardens', 'Stevens', 'Newton', 'Little India', 'Rochor'], ['Newton', 'Novena', 'Toa Payoh', 'Braddell', 'Bishan'], ['Dhoby Ghaut', 'Little India', 'Farrer Park', 'Boon Keng'] ]

print('Test 1')
print("Expected value:['Newton', 'Stevens']")
# We sort the returned list such that we do not care about
# the order the stations appear in the list.
result = sorted(q4.find_stations_within_distance(mrt_map, 'Botanic Gardens', 2))
print('Actual value  :' + str(result))
print("Expected type:<class 'list'>")
print('Actual type  :' + str(type(result)))
print()

print('Test 2')
print("Expected value:['Dhoby Ghaut', 'Farrer Park', 'Newton', 'Rochor']")
# We sort the returned list such that we do not care about
# the order the stations appear in the list.
result = sorted(q4.find_stations_within_distance(mrt_map, 'Little India', 1))
print('Actual value  :' + str(result))
print("Expected type:<class 'list'>")
print('Actual type  :' + str(type(result)))
print()

print('Test 3')
print("Expected value:['Boon Keng', 'Farrer Park', 'Little India', 'Newton', 'Novena', 'Rochor', 'Stevens']")
# We sort the returned list such that we do not care about
# the order the stations appear in the list.
result = sorted(q4.find_stations_within_distance(mrt_map, 'Dhoby Ghaut', 3))
print('Actual value  :' + str(result))
print("Expected type:<class 'list'>")
print('Actual type  :' + str(type(result)))
print()



def get_routes(mrtline_1, mrtline_2):
    combined_lines = mrtline_1 + mrtline_2
    reverse_mrtline_1 = mrtline_1[:]
    reverse_mrtline_1.reverse()
    reverse_mrtline_2 = mrtline_2[:]
    reverse_mrtline_2.reverse()
    interchange = ''
    for station in combined_lines:
        if combined_lines.count(station) == 2:
            interchange = station
    if interchange == '':
        return []

    station_num_line1 = mrtline_1.index(interchange)
    station_num_line2 = mrtline_2.index(interchange)
    station_num_line1_rev = reverse_mrtline_1.index(interchange)
    station_num_line2_rev = reverse_mrtline_2.index(interchange)

    new_route_1 = mrtline_1[0:station_num_line1] + mrtline_2[station_num_line2:]
    new_route_2 = mrtline_1[0:station_num_line1] + reverse_mrtline_2[station_num_line2_rev:]
    new_route_3 = reverse_mrtline_1[0:station_num_line1_rev] + mrtline_2[station_num_line2:]
    new_route_4 = reverse_mrtline_1[0:station_num_line1_rev] + reverse_mrtline_2[station_num_line2_rev: ]

    return [new_route_1,new_route_2,new_route_3,new_route_4]

to_add1 = get_routes(mrt_map[0],mrt_map[1])
to_add2 = get_routes(mrt_map[0],mrt_map[2])
to_add3 = get_routes(mrt_map[1],mrt_map[2])
routes = mrt_map + to_add1 + to_add2 + to_add3
print(len(routes))
