def find_stations_next(mrt_map):
    station_dict = {}
    for line in mrt_map:
        for i in range(len(line)):
            if i == 0:
                if line[i] not in station_dict:
                    station_dict[line[i]] = [line[i+1]]
                else:
                    station_dict[line[i]].append(line[i+1])
            elif i == (len(line)-1):
                if line[i] not in station_dict:
                    station_dict[line[i]] = [line[i-1]]
                else:
                    station_dict[line[i]].append(line[i-1])
            else:
                if line[i] not in station_dict:
                    station_dict[line[i]] = [line[i-1], line[i+1]]
                else:
                    station_dict[line[i]].append(line[i-1])
                    station_dict[line[i]].append(line[i+1])

    return station_dict

mrt_map = [ ['Botanic Gardens', 'Stevens', 'Newton', 'Little India', 'Rochor'], ['Newton', 'Novena', 'Toa Payoh', 'Braddell', 'Bishan'], ['Dhoby Ghaut', 'Little India', 'Farrer Park', 'Boon Keng'] ]

print(find_stations_next(mrt_map))

def find_stations_within_distance(mrt_map, orig, dist):
    station_dict = find_stations_next(mrt_map)

    if dist <= 0:
        return []

    res_list = []
    next_station = station_dict[orig]

    for station in next_station:
        if station not in res_list:
            res_list.append(station)
    print(res_list)
    count = 1

    while count != dist:
        to_add = []
        for station in res_list:
            next_station_list = station_dict[station]
            for next_station in next_station_list:
                if next_station not in res_list and next_station != orig:
                    to_add.append(next_station)
        res_list += to_add
        count += 1

    return res_list

#     print("-------")
#     print(orig)
#     print(prev)
#     print("-------")
#
#     for station in res_list:
#         if station != prev:
#             res_list += find_stations_within_distance1(mrt_map,station,orig,dist-1)
#
#     return res_list
#
# def find_stations_within_distance(mrt_map, orig, dist):
#     res = find_stations_within_distance1(mrt_map,orig, orig, dist)
#     return res