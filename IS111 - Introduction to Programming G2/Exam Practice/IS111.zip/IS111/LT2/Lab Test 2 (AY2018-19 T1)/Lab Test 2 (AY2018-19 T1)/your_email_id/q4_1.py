#
# Name: 
# Email ID: 
#

# If needed, you can define your own additional functions here.
# Start of your additional functions.
def get_routes(mrtline_1, mrtline_2):
    combined_lines = mrtline_1 + mrtline_2
    reverse_mrtline_1 = mrtline_1[:]
    reverse_mrtline_1.reverse()
    reverse_mrtline_2 = mrtline_2[:]
    reverse_mrtline_2.reverse()
    interchange = ''
    for station in combined_lines:
        if combined_lines.count(station) == 2:
            interchange = station
    if interchange == '':
        return []

    station_num_line1 = mrtline_1.index(interchange)
    station_num_line2 = mrtline_2.index(interchange)
    station_num_line1_rev = reverse_mrtline_1.index(interchange)
    station_num_line2_rev = reverse_mrtline_2.index(interchange)

    new_route_1 = mrtline_1[0:station_num_line1] + mrtline_2[station_num_line2:]
    new_route_2 = mrtline_1[0:station_num_line1] + reverse_mrtline_2[station_num_line2_rev:]
    new_route_3 = reverse_mrtline_1[0:station_num_line1_rev] + mrtline_2[station_num_line2:]
    new_route_4 = reverse_mrtline_1[0:station_num_line1_rev] + reverse_mrtline_2[station_num_line2_rev: ]

    return [new_route_1,new_route_2,new_route_3,new_route_4]

# End of your additional functions.

def find_stations_within_distance(mrt_map, orig, dist):
    routes = mrt_map[:] #this is to make a copy of the list since it is mutable
    line_pairs = []
    for line1 in mrt_map:
        for line2 in mrt_map:
            if line1 != line2:
                line_pair = [line1,line2]
                line_pair_rev = [line2,line1]
                if line_pair and line_pair_rev not in line_pairs:
                    line_pairs.append(line_pair)

    for pair in line_pairs:
        line1 = pair[0]
        line2 = pair[1]
        routes += get_routes(line1,line2)

    res_list = []
    for line in routes:
        if orig in line:
            index = line.index(orig)
            if len(line) > dist:
                res_list += (line[index - dist:index])
                res_list += (line[index+1: index + dist +1])
            else:
                res_list += (line)
                res_list.remove(orig)



    final_res_list = []
    for item in res_list:
        if item not in final_res_list:
            final_res_list.append(item)


    return final_res_list

