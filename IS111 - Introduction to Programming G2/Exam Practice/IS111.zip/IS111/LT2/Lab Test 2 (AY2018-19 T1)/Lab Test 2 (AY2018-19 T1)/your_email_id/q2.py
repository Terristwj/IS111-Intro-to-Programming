#
# Name: 
# Email ID: 
#
def get_prices_in_range(price_list, low, high):
    res_list = []
    for price in price_list:
        if low <= price <= high:
            res_list.append(price)
    return res_list