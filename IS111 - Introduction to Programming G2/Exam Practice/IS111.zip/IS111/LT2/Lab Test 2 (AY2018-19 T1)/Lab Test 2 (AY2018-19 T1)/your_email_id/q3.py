#
# Name: 
# Email ID: 
#

# If needed, you can define your own additional functions here.
# Start of your additional functions.


# End of your additional functions.

def get_total_transactions_in_month(trans_file, month):
    date_info = month.split('/')
    mo = int(date_info[0])
    yr = int(date_info[1])
    total = 0.0

    with open(trans_file,'r') as file:
        for line in file:
            line = line.rstrip('\n')
            info_list = line.split('\t')
            dates = info_list[0].split('/')
            month = int(dates[0])
            year = int(dates[2])
            price = float(info_list[1][1:])
            if year == yr and month == mo:
                total += price


    return total
    
