#
# Name: 
# Email ID: 
#

# If needed, you can define your own additional functions here.
# Start of your additional functions.


# End of your additional functions.

def convert_to_list(num_list_str):
    res = converting(num_list_str)[0]

    return res

def converting(num_list_str):
    pos = 1
    ch = num_list_str[pos]
    res_list = []

    while ch != ']':
        if ch.isdigit():
            to_append = ''
            while ch.isdigit():
                to_append += ch
                pos += 1
                ch = num_list_str[pos]

            res_list.append(int(to_append))
        elif ch == ',':
            pos += 1
        elif ch == '[':
            rest_of_string = num_list_str[pos:]
            intermediate_res = converting(rest_of_string)
            res_list.append(intermediate_res[0])
            print('helo1' + str(intermediate_res[1]))
            pos += intermediate_res[1] + 1
        print(pos)


        ch = num_list_str[pos]

    return (res_list, pos)




    
