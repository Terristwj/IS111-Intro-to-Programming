def get_postal_codes(file_name):
    info_list= []
    with open(file_name, 'r') as file:
        for line in file:
            line = line.rstrip('\n')
            index_comma = line.find(',')
            name = line[0:index_comma]
            postal = line[-6:]
            info_list.append((name,postal))
    return info_list
