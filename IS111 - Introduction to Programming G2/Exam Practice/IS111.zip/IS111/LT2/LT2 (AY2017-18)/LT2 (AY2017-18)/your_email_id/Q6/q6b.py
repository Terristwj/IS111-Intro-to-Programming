
# def perm(string1, string2):
#     if len(string1) == 0:
#         return 'nth'
#     res = ''
#     for i in range(len(string1)-1):
#         ch = string1[i]
#         print(ch)
#         ros = string1[0:i] + string1[i+1]
#         print(ros)
#         res = perm(ros, string2 + ch)
#
#     return res

def get_all_permutations(letters):
    if len(letters) == 1:
        return [letters]
    res_list = []
    for ch in letters:
        for ch2 in letters:
            combi = ch
            if ch2 != ch:
                combi += ch2
                res_list.append(combi)
    print(res_list)

    count = 1
    while count != len(letters) -1:
        to_change_to = []
        for combinations in res_list:
            word = letters
            for ch in combinations:
                word = word.replace(ch,'',1)

            for ch in word:
                combi2 = ch + combinations
                combi3 = combinations + ch
                to_change_to.append(combi2)
                to_change_to.append(combi3)

        res_list = to_change_to
        count += 1
        print(res_list)

    final_list = []
    for item in res_list:
        if item not in final_list:
            final_list.append(item)
    return final_list

print(len(get_all_permutations('abcd')))