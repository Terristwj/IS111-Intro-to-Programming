def evaluate(expression):
    index = 0
    num_list = []
    operator_list = []
    while index != len(expression):
        print(expression[index])
        if expression[index].isdigit():
            num = ''
            while expression[index].isdigit() or expression[index] == '.':
                num += expression[index]
                index += 1
                if index >= len(expression):
                    break
                print(num,index)
            num_list.append(num)
        elif expression[index] in '+-*/':
            operator_list.append(expression[index])
            index += 1
    sum_eqn = float(num_list[0])
    for i in range(len(num_list)-1):
        num1 = sum_eqn
        num2 = float(num_list[i+1])
        if operator_list[i] == '+':
            sum_eqn = num1 + num2
        elif operator_list[i] == '-':
            sum_eqn = num1 - num2
        elif operator_list[i] == '/':
            sum_eqn = num1 / num2
        elif operator_list == '*':
            sum_eqn = num1 * num2
    print(num_list,operator_list, sum_eqn)
    return sum_eqn
