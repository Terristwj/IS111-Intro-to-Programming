def count_long_strings(str_list):
    count = 0
    for item in str_list:
        if len(item) >= 5:
            count += 1
    return count
