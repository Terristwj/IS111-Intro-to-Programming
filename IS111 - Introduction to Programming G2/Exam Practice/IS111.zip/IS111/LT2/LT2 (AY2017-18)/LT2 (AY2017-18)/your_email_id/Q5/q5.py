def create_fam_dict(head, dict):
    for i in range(len(head)):
        name = head[i]
        if type(name) == str:
            dict[name] = []
            list_children = head[i+1]
            for children in list_children:
                children_name = children[0]
                dict[name].append(children_name)
                create_fam_dict(children, dict)



def get_family_members(head):
    dict = {}
    create_fam_dict(head,dict)
    print(dict)
    first_name = head[0]
    res =[]
    res.append(first_name)

    while len(res) < len(dict):
        to_add = res
        for name in to_add:
            to_add += dict[name]
        res = to_add

    return res


