def scramble(word, file_name):
    res_list = []
    with open(file_name,'r') as words:
        for line in words:
            line = line.rstrip('\n')

            string = ''
            word_compare = word
            count = 0

            if len(line) == len(word):
                while count != len(word):
                    if line[count] in word_compare:
                        string += line[count]
                        word_compare = word_compare.replace(line[count],'',1)
                    count += 1
            if len(string) == len(word):
                res_list.append(string)
    return res_list
    