def get_document_pair(filename):
    doc_dict = {}
    with open(filename,'r') as file:
        for line in file:
            line = line.rstrip('\n')
            column = line.split('\t')
            doc_id = column[0]
            words = column[1]
            words = words.split(' ')
            word_list = []
            for word in words:
                if word not in word_list:
                    word_list.append(word)

            doc_dict[doc_id] = word_list
    common_count = []
    for doc in doc_dict:
        for document in doc_dict:
            if doc != document:
                common = 0
                for word in doc_dict[document]:
                    if word in doc_dict[doc]:
                        common += 1
                common_count.append((doc, document, common))

    max = common_count[0][2]
    most_common = common_count[0]
    for item in common_count:
        if item[2] > max:
            max = item[2]
            most_common = item

    return most_common
    
print(get_document_pair('documents.txt'))