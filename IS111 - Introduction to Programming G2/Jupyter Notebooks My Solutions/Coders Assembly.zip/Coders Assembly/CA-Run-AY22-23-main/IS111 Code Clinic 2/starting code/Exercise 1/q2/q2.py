##
# This question was adapted from SPM Programming Exercise, Roman Numerals
# Author : Stephen Pang Qing Yang
# Created : August 30, 2021
# Last Updated : August 30, 2021
#
# Copyright (C) 2021 Stephen Pang Qing Yang
##

# DO NOT MODIFY THIS variable
age_list = [('Molly',25), ('Jett',13), ('Sage', 21), ('Ashley', 40), ('Sean', 31), ('Michelle',21)]


# YOUR CODE GOES HERE