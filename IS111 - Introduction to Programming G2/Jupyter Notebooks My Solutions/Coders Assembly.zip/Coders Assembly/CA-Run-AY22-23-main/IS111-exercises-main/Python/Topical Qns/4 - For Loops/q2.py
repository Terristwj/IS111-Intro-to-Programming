def seven_up(num):
    # YOUR CODE GOES HERE
    
    pass

# DO NOT MODIFY THESE TEST CASES
print('----Test Case 1----')
result = seven_up(12)
print()
print('----Test Case 2----')
result = seven_up(16)

print()
print('----Test Case 3----')
result = seven_up(30)

print()        
