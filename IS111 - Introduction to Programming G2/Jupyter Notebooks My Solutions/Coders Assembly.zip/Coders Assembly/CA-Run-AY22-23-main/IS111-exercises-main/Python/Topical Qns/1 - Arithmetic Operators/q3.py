def calculate_bmi(weight,height):
    # YOUR CODE GOES HERE

    return None


# YOUR CODE GOES HERE