def get_hypotenuse(length,height):
    # YOUR CODE GOES HERE

    return None


# YOUR CODE GOES HERE