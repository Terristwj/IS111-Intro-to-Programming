def calculate_rectangle_area(length, breadth):
    # YOUR CODE GOES HERE

    return None


def calculate_rectangle_perimeter(length, breadth):
    # YOUR CODE GOES HERE

    return None


# YOUR CODE GOES HERE
