PI = 3.14 # DO NOT MODIFY THIS GIVEN VALUE


def calculate_cone_area(diameter,height):
    # YOUR CODE GOES HERE

    return None

def calculate_cone_circumference(diameter,height):
    # YOUR CODE GOES HERE

    return None


# YOUR CODE GOES HERE