num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))
num3 = int(input("Enter the third number: "))
num4 = int(input("Enter the fourth number: "))
num5 = int(input("Enter the fifth number: "))

ans1 = num1 + num2
ans2 = num3 * num4 
ans3 = num5 // 2

ans = ans1 - ans2 - ans3

print("The answer to the equation is: " + str(ans))