def compute_steps(up,down,left,right):
    # YOUR CODE GOES HERE
    return None