def get_nested_list(list_str):
    # YOUR CODE GOES HERE
    return None