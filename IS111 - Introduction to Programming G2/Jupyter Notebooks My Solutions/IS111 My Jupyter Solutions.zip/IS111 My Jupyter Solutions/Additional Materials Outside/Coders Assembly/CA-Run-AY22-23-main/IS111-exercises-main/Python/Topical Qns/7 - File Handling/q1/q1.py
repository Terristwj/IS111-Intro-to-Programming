# If you are getting a "No such file or directory" error message, right click on the text file and select "Copy Path", and replace 'q1.txt' with that file path.
# In lab test, DO NOT use your copied path, just revert back to q1.txt

# YOUR CODE GOES HERE

