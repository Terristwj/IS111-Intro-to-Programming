# Concatenate and multiply

string = input("Enter a string: ")
num = input("Enter a whole number: ")

string = string * int(num)

print("The new string is " + string)