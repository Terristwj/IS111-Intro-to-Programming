# IS111 question repository

This is the code repository for IS111, as part of Coder's Assembly run 2021-2022.

All the questions and solutions are located within the `Python` folder.

The questions for each topic folder are located in the README file.

Code Clinic exercises will also be placed here in a separate folder. The question paper for these clinics will be posted on Google Docs (link will be provided on the day itself)

Happy coding!
