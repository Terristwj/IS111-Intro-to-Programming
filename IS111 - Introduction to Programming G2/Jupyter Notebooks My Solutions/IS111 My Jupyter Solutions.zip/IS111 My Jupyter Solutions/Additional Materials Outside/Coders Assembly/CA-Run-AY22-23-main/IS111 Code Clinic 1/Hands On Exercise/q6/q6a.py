##
# This question was adapted from SPM Programming Exercise, Roman Numerals
# Author : Stephen Pang
# Created : August 30, 2021
# Last Updated : August 30, 2021
#
# Copyright (C) 2021 Stephen Pang
##

def convert_to_roman(num):
    # YOUR CODE GOES HERE
    pass

# DO NOT MODIFY THE CODE BELOW:
print('----Test Case 1----')
result = convert_to_roman(5)
print("Expected: V" )
print("Actual:   " + str(result))
print()
print('----Test Case 2----')
result = convert_to_roman(46)
print("Expected: XLVI" )
print("Actual:   " + str(result))
print()
print('----Test Case 3----')
result = convert_to_roman(102)
print("Expected: CII" )
print("Actual:   " + str(result))
print()
print('----Test Case 4----')
result = convert_to_roman(2097)
print("Expected: MMXCVII" )
print("Actual:   " + str(result))
print()