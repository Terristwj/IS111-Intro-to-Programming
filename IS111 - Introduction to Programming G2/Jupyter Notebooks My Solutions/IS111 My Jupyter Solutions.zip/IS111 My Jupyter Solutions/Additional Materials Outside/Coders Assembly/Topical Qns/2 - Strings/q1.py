# YOUR CODE GOES HERE
str1 = input("Enter first string: ")
str2 = input("Enter second string: ")
str3 = input("Enter third string: ")
str4 = input("Enter fourth string: ")
str5 = input("Enter fifth string: ")

print("The final string is", str1+str2+str3+str4+str5)