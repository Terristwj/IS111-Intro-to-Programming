# YOUR CODE GOES HERE
string = input("Enter a string: ")
num = int(input("Enter a whole number: "))

print("The new string is", string*num)