def count_long_strings(str_list):
    # modify the code below
    return 0
