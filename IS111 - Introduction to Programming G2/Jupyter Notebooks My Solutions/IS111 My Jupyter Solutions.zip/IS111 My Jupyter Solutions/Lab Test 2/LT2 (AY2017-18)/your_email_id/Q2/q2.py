def get_sum_of_odd_numbers(num_list):
    # modify the code below
    return 0
    