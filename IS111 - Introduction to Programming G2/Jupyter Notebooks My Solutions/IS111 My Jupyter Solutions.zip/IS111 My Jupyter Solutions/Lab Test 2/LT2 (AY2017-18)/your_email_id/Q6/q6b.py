def get_all_permutations(letters):

    # modify the code below
    return []
