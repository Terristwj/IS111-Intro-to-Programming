#
# Name: 
# Email ID: 
#

# If needed, you can define your own additional functions here.
# Start of your additional functions.


# End of your additional functions.

def get_total_transactions_in_month(trans_file, month):
    # Modify the code below
    return None
    
