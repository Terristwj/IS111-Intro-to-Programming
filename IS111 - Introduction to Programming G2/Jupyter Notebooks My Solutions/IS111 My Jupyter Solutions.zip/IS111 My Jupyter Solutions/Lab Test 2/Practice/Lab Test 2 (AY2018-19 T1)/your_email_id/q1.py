#
# Name: 
# Email ID: 
#
def count_names_with_space(name_list):
    # Modify the code below
    return None
