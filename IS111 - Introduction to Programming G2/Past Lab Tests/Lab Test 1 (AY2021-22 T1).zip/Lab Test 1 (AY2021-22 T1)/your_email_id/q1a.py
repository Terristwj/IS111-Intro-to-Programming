# Name:
# Email ID:

def get_area_difference(width1, length1, width2, length2):
    # Replace the code below with your implementation.
    return None