# Name:
# Email ID:

def check_diversity(team):
    # Replace the code below with your implementation.
    return None