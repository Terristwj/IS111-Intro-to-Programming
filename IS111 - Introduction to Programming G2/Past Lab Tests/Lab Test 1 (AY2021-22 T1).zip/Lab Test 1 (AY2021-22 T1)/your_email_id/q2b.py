# Name:
# Email ID:

def get_all_third_digits(str_list):
    # Replace the code below with your implementation.
    return None