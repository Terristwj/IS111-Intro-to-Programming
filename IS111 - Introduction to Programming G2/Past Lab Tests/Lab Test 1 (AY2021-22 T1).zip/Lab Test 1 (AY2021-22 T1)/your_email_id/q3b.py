# Name:
# Email ID:

import q3a

def swap_members(team1, team2):
    # Replace the code below with your implementation.
    return ('', '')
            