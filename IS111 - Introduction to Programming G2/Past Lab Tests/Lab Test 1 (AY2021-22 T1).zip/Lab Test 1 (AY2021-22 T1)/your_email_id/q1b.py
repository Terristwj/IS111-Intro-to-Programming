# Name:
# Email ID:

def is_official_language(country, language):
    # Replace the code below with your implementation.
    return None