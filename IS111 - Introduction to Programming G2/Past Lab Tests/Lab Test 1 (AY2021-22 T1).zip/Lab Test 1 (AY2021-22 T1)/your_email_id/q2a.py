# Name:
# Email ID:

def get_right_most_even_digit(number):
    # Replace the code below with your implementation.
    return 'No idea!'
    