# Name:
# Email ID:

def check_sum(n1, n2, n3):
    # Modify the code below.
    return None
    