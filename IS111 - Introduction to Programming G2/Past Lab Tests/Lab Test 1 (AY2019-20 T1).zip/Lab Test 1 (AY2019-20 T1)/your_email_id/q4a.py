# Name:
# Email ID:

def check_seating_arrangement(arrangement, must_list, cannot_list):
    # Modify the code below.
    return None
 