# Name:
# Email ID:

def transform(str1, str2):
    # Modify the code below.
    return []
        
    