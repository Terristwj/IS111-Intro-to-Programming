# Name:
# Email ID:

def get_number_of_long_strings(str_list, n):
    # Modify the code below.
    return None