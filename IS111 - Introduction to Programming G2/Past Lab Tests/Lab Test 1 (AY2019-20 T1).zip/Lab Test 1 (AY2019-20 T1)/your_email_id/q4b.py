# Name:
# Email ID:

import itertools
import q4a

def get_seating_arrangement(female_list, male_list, must_list, cannot_list):
    # Modify the code below.
    return []