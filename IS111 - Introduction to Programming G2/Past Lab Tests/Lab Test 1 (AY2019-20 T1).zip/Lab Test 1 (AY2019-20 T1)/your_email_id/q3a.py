# Name:
# Email ID:

def calculate_entrance_fees_1(n):

    # These variables are defined for you to use.
    PACKAGE_B = 110
    PACKAGE_C = 200

    # Modify the code below.
    return None
        