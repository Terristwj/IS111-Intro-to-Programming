# Name:
# Email ID:

def add_even_numbers(str_list):
    # Modify the code below.
    return None