# Name:
# Email ID:


def find_overlapping_pairs(rect_list):

    # Replace the code below with your implementation.
    return None