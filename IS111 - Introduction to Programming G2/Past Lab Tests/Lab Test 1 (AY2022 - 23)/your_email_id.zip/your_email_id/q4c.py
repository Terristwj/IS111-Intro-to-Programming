# Name:
# Email ID:

def find_overlap_size(rect_1, rect_2):

    # Replace the code below with your implementation.
    return None