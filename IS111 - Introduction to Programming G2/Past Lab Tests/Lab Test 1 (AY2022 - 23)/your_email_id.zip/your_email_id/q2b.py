# Name:
# Email ID:

def trim_number_with_list(num, num_list):
    # Replace the code below with your implementation.
    return None