# Name:
# Email ID:

def construct_string(orig_str, len_list, cnct_list):
    # Replace the code below with your implementation.
    return None