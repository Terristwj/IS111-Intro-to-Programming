# Name:
# Email ID:

def get_promotion(food_category):
    # Replace the code below with your implementation.
    return ''