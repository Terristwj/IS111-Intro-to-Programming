# Name:
# Email ID:

def is_overlapping(rect_1, rect_2):
    # Replace the code below with your implementation.
    return None