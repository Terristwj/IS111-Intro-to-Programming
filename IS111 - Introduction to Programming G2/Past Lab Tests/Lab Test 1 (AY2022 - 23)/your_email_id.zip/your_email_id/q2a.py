# Name:
# Email ID:

def trim_number(num1, num2):
    # Replace the code below with your implementation.
    return None
    