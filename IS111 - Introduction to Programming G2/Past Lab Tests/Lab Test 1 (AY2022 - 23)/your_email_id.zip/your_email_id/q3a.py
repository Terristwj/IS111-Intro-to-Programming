# Name:
# Email ID:

def shift_string(orig_str):
    # Replace the code below with your implementation.
    return None