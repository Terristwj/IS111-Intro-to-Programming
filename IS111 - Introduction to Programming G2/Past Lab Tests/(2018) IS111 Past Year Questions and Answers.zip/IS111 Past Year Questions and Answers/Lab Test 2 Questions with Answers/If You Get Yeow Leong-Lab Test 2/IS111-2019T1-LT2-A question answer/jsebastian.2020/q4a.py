# Name:
# Email ID:

def store_family_relations(family_file):
    # Modify the code below.
    d={}
    with open(family_file) as file:
        for line in file:
            ls=line.rstrip('\n').replace('(','').replace(')','').split(':')
            parents=ls[0].split(',')
            father=parents[0]
            mother=parents[1]
            children=ls[1].split(';')
            for child in children:
                name=child[:-2]
                gender=child[-1]
                d[(father,name)]='father'
                d[(mother,name)]='mother'
                if gender=="M":
                    d[(name,father)]='son'
                    d[(name,mother)]='son'
                else:
                    d[(name,father)]='daughter'
                    d[(name,mother)]='daughter'
                
            
    return d
    