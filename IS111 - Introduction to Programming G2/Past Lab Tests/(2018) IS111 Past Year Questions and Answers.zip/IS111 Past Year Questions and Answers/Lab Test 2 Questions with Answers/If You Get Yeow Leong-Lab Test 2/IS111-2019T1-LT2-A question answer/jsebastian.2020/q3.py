# Name:
# Email ID:

def compute_total_price(price_dict, item_list):
    # Modify the code below.
    total=0.0
    for item_num in item_list:
        name=item_num[0]
        num=item_num[1]
        if name in price_dict:
            total+=price_dict[name]*num
    return total