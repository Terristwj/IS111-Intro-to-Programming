# Name:
# Email ID:

def compute_product(num_list):
    # Modify the code below.
    total=1
    for num in num_list:
        if num %2==1:
            total=total*num
    return total
    