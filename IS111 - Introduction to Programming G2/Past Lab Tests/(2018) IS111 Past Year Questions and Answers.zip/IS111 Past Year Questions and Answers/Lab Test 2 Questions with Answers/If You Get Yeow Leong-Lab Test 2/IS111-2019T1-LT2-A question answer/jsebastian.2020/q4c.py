# Name:
# Email ID:

def get_relation(family_dict, p1, p2):
    # Modify the code below.
    from q4b import get_relation_through_link
    
    
    for key,value in family_dict.items():
        if p1 == key[0] and p2 == key[1]:
            return value

    for key,value in family_dict.items():
        if p1==key[0]:
            x1=key[1]
            
            for ke,valu in family_dict.items():
                if x1 == ke[0] and p2 == ke[1]:
                    ls=[p1,x1,p2]
                    return get_relation_through_link(family_dict,ls)
    
    for key,value in family_dict.items():
        if p1==key[0]:
            x1=key[1]
            for ke,valu in family_dict.items():
                if x1 == ke[0]:
                    x2=ke[1]
                    for k,val in family_dict.items():
                        if x2 == k[0] and p2 == k[1]:
                            ls=[p1,x1,x2,p2]
                            return get_relation_through_link(family_dict,ls)
    
    