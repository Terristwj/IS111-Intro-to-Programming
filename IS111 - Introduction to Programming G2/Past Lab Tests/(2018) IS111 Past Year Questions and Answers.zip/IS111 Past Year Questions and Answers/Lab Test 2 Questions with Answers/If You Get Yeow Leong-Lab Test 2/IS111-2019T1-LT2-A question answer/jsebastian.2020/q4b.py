# Name:
# Email ID:

def get_relation_through_link(family_dict, link):
    # Modify the code below.
    relation={}
    with open('relation_mapping.txt') as file:
        for line in file:
            ls=line.rstrip('\n').replace('(','').replace(')','').split(':')
            re=ls[0].split(',')
            re1=re[0]
            re2=re[1]
            relation[(re1,re2)]=ls[1]
            
    if len(link)==2:
        return family_dict[(link[0],link[1])]
    elif len(link)==3:
        rel1=family_dict[(link[0],link[1])]
        rel2=family_dict[(link[1],link[2])]
        return relation[(rel1,rel2)]

    else:
        rel1=family_dict[(link[0],link[1])]
        rel2=family_dict[(link[1],link[2])]
        rel3=family_dict[(link[2],link[3])]
        relrel1=relation[(rel1,rel2)]
    return relation[(relrel1,rel3)]
    