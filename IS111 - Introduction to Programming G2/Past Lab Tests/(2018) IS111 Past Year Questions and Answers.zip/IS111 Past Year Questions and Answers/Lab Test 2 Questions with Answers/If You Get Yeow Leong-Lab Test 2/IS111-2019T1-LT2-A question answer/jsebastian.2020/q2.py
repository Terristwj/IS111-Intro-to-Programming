# Name:
# Email ID:

def get_longer_words(file_name):
    # Modify the code below.
    l=[]
    with open(file_name) as file:
        for line in file:
            lis=line.rstrip('\n').split('&')

            if len(lis[0])>=len(lis[1]):
                l.append(lis[0])
            else:
                l.append(lis[1])
    return l