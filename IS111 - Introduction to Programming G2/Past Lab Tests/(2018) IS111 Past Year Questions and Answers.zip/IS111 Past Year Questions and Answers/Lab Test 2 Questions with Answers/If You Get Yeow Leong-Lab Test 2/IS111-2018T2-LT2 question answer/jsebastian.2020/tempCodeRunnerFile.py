   # if prime(number):
    #     return [number]