# Name:Juan Sebastian
# Email ID:jsebastian.2020

def to_mins(t):
    if 'AM' in t:
        hour=int(t.split(':')[0])
        if hour==12:
            hour=0
        minute=int(t.split(':')[1][:3])+hour*60
    else:
        hour=int(t.split(':')[0])
        if hour != 12 :
            hour+=12
        minute=int(t.split(':')[1][:3])+hour*60
    return minute

def get_total_time(name, date, timing_file):
    dictionary={}
    with open(timing_file) as file:
        for line in file:
            ls=line.rstrip('\n').split(',')
            day=[]
            s=''
            for num in ls[1].split('/'):
                day+=[int(num)]
            for d in day:
                s+=str(d)+'/'
            s=s[:-1]
            identifier=(ls[0],s)
            data=ls[2:]
            
            dictionary[identifier]=data
    
    day=[]
    s=''
    for num in date.split('/'):
        day+=[int(num)]
    for d in day:
        s+=str(d)+'/'
    s=s[:-1]
    
    if (name,s) in dictionary:
        timing=dictionary[(name,s)]
    else:
        return 0
    minute=0
    for t in timing:
        if '(O)' in t:
            minute=to_mins(t)
            timing.remove(t)
            break
  
    for i in range(0,len(timing),2):
        go_in=timing[i]
        minute-=to_mins(go_in)
        
        if i+1<len(timing):
            out=timing[i+1]
            minute+=to_mins(out)
        else:
            out=24*60
            minute+=out
    return minute



if __name__ == '__main__':
    print('Test 1')
    print('Expected:True')
    result = get_total_time('apple', '01/03/2019', 'timings.txt')
    print('Actual  :' + str(isinstance(result, int)))
    print()

    print('Test 2')
    print('Expected:30')
    result = get_total_time('apple', '01/03/2019', 'timings.txt')
    print('Actual  :' + str(result))
    print()

    print('Test 3')
    print('Expected:90')
    result = get_total_time('apple', '24/3/2019', 'timings.txt')
    print('Actual  :' + str(result))
    print()

    print('Test 4')
    print('Expected:3')
    result = get_total_time('orange', '24/03/2019', 'timings.txt')
    print('Actual  :' + str(result))
    print()

    print('Test 5')
    print('Expected:480')
    result = get_total_time('orange', '25/3/2019', 'timings.txt')
    print('Actual  :' + str(result))
    print()

    print('Test 6')
    print('Expected:577')
    result = get_total_time('pear', '24/03/2019', 'timings.txt')
    print('Actual  :' + str(result))
    print()

    print('Test 7')
    print('Expected:0')
    result = get_total_time('durian', '25/3/2019', 'timings.txt')
    print('Actual  :' + str(result))
    print()

    print('Test 8')
    print('Expected:0')
    result = get_total_time('orange', '27/3/2019', 'timings.txt')
    print('Actual  :' + str(result))
    print()
