# Name: Juan Sebastian
# Email ID: jsebastian.2020

def expand_braces(value):
    is_bracket_open=False
    count_open_bracket=0
    count_close_bracket=0
    
    ls=[]
    txt=''
    s=''
    for ch in value:
        if is_bracket_open==False:
            if ch not in "{,}":
                s+=ch
            elif ch=='{':
                is_bracket_open=True

        elif is_bracket_open==True:
            if ch not in "}{":
                txt+=ch
            elif ch=='}':
                is_bracket_open=False
                if ls==[]:
                    for c in txt.split(','):
                        ls+=[s+c]
                    txt=''
                    s=''
                else:
                    l=[]
                    for z in ls:
                        for c in txt.split(','):
                            l+=[z+s+c]
                    ls=l
    l=[]

    if value[-1]!='}':
        for z in ls:
            l+=[z+s]
        ls=l   

    return ls


if __name__ == '__main__':
    result = expand_braces('a{d,c,b}e')
    print('Test 1') 
    print("Expected:True")
    print('Actual  :' + str(isinstance(result, list)))
    print()

    result = expand_braces('a{d,c,b}e')
    print('Test 2') 
    print("Expected:True")
    print('Actual  :' + str(isinstance(result != None and result[0], str)))
    print()

    result = expand_braces('a{d,c,b}e')
    print('Test 3') 
    print("Expected:['ade', 'ace', 'abe']")
    print('Actual  :' + str(result))
    print()


    result = expand_braces('a{b,c}e{f,g}')
    print('Test 4')
    print("Expected:['abef', 'abeg', 'acef', 'aceg']")
    print('Actual  :' + str(result))
    print()

    result = expand_braces('abc{1,2,3}{sad,happy}')
    print('Test 5')
    print("Expected:['abc1sad', 'abc1happy', 'abc2sad', 'abc2happy', 'abc3sad', 'abc3happy']")
    print('Actual  :' + str(result))
    print()
    
    result = expand_braces('a{d,c,b}ef')
    print('Test 6') 
    print("Expected:['adef', 'acef', 'abef']")
    print('Actual  :' + str(result))
    print()

