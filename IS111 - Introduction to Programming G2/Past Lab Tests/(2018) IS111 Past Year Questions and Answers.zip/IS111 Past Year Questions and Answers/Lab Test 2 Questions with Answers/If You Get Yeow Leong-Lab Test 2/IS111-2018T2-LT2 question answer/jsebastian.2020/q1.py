# Name: Juan Sebastian
# Email ID: jsebastian.2020


def get_students_of_score(student_list, low, high):
    ls=[]
    for tup in student_list:
        if low<=tup[1]<=high:
            ls.append(tup[0])
    return ls

if __name__ == '__main__':
    print('Test 1')
    result = get_students_of_score(
        [('apple', 32), ('orange', 54), ('pear', 64)], 50, 100)
    print("Expected:True")
    print('Actual  :' + str(isinstance(result, list)))
    print()

    print('Test 2')
    result = get_students_of_score(
        [('apple', 32), ('orange', 54), ('pear', 64)], 50, 100)
    print("Expected:True")
    print('Actual  :' + str(isinstance(result != None and result[0], str)))
    print()

    print('Test 3')
    result = get_students_of_score(
        [('apple', 32), ('orange', 54), ('pear', 64)], 50, 100)
    print("Expected:['orange', 'pear']")
    print('Actual  :' + str(result))
    print()

    print('Test 4')
    result = get_students_of_score([('apple', 32), ('orange', 54)], 60, 100)
    print("Expected:[]")
    print('Actual  :' + str(result))
    print()

    print('Test 5')
    result = get_students_of_score([('apple', 32), ('orange', 54),('pear', 64)], 32, 54)
    print("Expected:['apple', 'orange']")
    print('Actual  :' + str(result))
    print()

    print('Test 6')
    result = get_students_of_score([], 50, 100)
    print("Expected:[]")
    print('Actual  :' + str(result))
    print()
