import math
import sys

# Test Cases
dict1 = {'A+':4.3, 'A':4.0, 'A-':3.7, 'B+':3.3, 'B':3.0, 'B-':2.7, 'C+':2.3, 'C':2.0, 'C-':1.7, 'D+':1.3, 'D':1.0, 'F':0}
dict2 = {'A*':4, 'A':3.5, 'B*':3, 'B':2.5, 'C':2, 'F':0}
dict3 = {'A1':4, 'A2':3.5, 'B3':3, 'B4':2.5, 'C5':2, 'C6':1.5, 'D7':1, 'E8':0.5, 'F9':0}
dict4 = {'X$':10, 'X':8, 'Y#':6, 'Y':4, 'Z@':2, 'Z':0}

test_cases = [ ( 'ABCD', dict1,  2.5), # TC1 - TC2: single-letter grades without repeated grades
               ( 'XYZ', dict4, 4.0),
               ( 'ACFACB', dict2, 2.25), # TC3 - TC4: single-letter grades with repeated grades
               ( 'YXXZYXZ', dict4, 4.571),
               ( 'A1B3D7A2B4', dict3, 2.8), # TC5 - TC6: double-character grades
               ( 'Z@Y#X$Y#', dict4, 6.0), 
               ( 'A+AA-B-B-C', dict1, 3.233), # TC7 - TC10: mixture
               ( 'A*BAB*BC', dict2, 2.917),
               ( 'XX$XY', dict4, 7.5),
               ( 'X$Y#ZZ@Z', dict4, 3.6)
]

# Mapping from counter value to marks
table = [(0, 0, 0),
         (1, 1, 0.5),
         (2, 3, 1),
         (4, 5, 1.5),
         (6, 7, 2),
         (8, 9, 2.5),
         (10, 10, 3)]

# Counter is to record how many test cases are passed.
counter = 0

try:
    from q3 import calculate_term_gpa

    for (string, dictionary, result) in test_cases:
        try:
            if math.isclose(calculate_term_gpa(string, dictionary), result, rel_tol=0.001):
                counter += 1

        except:
            print('Exception:', sys.exc_info()[0])
            

    # If none of the test cases is passed, check if the returned type is correct.
    if counter == 0:
        # If the function returns a float for the first test case, give some partial marks.
        try:
            (string, dictionary, result) = test_cases[0]
            my_result = calculate_term_gpa(string, dictionary)
            if isinstance(my_result, float):
                counter += 1

        except:
            print('Exception:', sys.exc_info()[0])
            
except:
    print('Exception:', sys.exc_info()[0])

n = counter

my_marks = 0
for (lower, upper, marks) in table:
    if n >= lower and n <= upper:
        my_marks = marks

print(str(my_marks) + ' marks awarded')