import sys

def reduce(poly):
    if not isinstance(poly, list):
        return False
    while len(poly) > 1 and poly[0] == 0:
        poly = poly[1:]

# Test Cases

test_cases = [ ( '3x^2-3x+1', [3, -3, 1] ), # TC1 - TC2: no missing terms
               ( '6x^3+5x^2-4x-9', [6, 5, -4, -9] ),
               ( '  3x + 4x^4 -   3  ', [4, 0, 0, 3, -3] ), # TC3 - TC4: have missing terms but no need to combine terms
               ( '9x^4 +3x^2 -3x^3 +1', [9, -3, 3, 0, 1] ),
               ( ' 5x + 3x^2 - 4x +2x^3 -9x^2 - 1 + 2x', [2, -6, 3, -1] ), # TC5 - TC8: need to combine terms
               ( '2x-3x^2+7-6x^5+2x^2+90-100x', [-6, 0, 0, -1, -98, 97] ),
               ( '90x^10', [90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] ),
               ( '1+2x+3x^2+4x^4-3x^2-2x', [4, 0, 0, 0, 1] ),
               ( '2x + 5x^100 - 2x^100 +4x^2 - 3x^100 -4', [4, 2, -4] ), # TC9 - TC10: need to remove heading 0s.
               ( '3x+5x^2-2x^2-3x-3x^2+9', [9] ),
               ( '-8x + 5x^2', [5, -8, 0] ), # TC11: starting with -
               ( '3x-5x+2x', [0] ) # TC12: zero polynomial
]

# Mapping from counter value to marks
table = [(0, 0, 0),
         (1, 2, 1),
         (3, 7, 1.5),
         (8, 11, 2),
         (12, 12, 3)]


# Counter is to record how many test cases are passed.
counter = 0

try:
    from q5b import get_polynomial

    for (poly_string, result) in test_cases:
        try:
            my_result = get_polynomial(poly_string)
            
            # print(poly_string)
            # print('Expected:', result)
            # print('Returned:', my_result)
            
            if my_result == result:
                counter += 1
            elif reduce(my_result) == result:
                counter += 0.5
        
        except:
            print('Exception:', sys.exc_info()[0])

            
except:
    print('Exception:', sys.exc_info()[0])

n = int(counter)

my_marks = 0
for (lower, upper, marks) in table:
    if n >= lower and n <= upper:
        my_marks = marks

print(str(my_marks) + ' marks awarded')