# Name: Juan Sebastian
# Email ID: jsebastian.2020
def multiply(polynomials):

    # Write your code here.
    ls=[]
    if len(polynomials)==1:
        return polynomials[0]
    for poly in polynomials:
        tup=[]
        largest_power=len(poly)-1
        for num in poly:
            tup.append((num,largest_power))           
            largest_power-=1
        ls.append(tup)

    while len(ls)!=1:
        temp=[]
        lsx=[]
        for num1 in ls[0]:
            n1=num1[0]
            p1=num1[1]
            for num2 in ls[1]:
                n2=num2[0]
                p2=num2[1]
                temp.append((n1*n2,p1+p2))
        lsx.append(temp)
        lsx+=ls[2:]
        ls=lsx
        
    ls=ls[0]
    max_power=max(ls, key= lambda x:x[1])[1]
    ret=[]
    for power in range(max_power,-1,-1):
        tot=0
        for t in ls:
            pow=t[1]
            num=t[0]
            if power==pow:
                tot+=num
        ret.append(tot)
    unique=list(set(ret))
    if unique==[0]:
        return [0]
    return ret

# DO NOT MODIFY THE CODE BELOW!
if __name__ == "__main__":
    tc_num = 0
    
    tc_num += 1
    print('-' * 40)
    
    polynomials = [(1, 2, 3), (5, 6, 7)]
    print(f"Test Case {tc_num} : multiply({polynomials})")
    print("Expected : [5, 16, 34, 32, 21]")
    result = multiply(polynomials)
    print(f"Actual   : {result}")
    print() 

    print("Expected return type : <class 'list'>")
    print(f"Actual return type   : {type(result)}")    
    
    print()
    
    print("Expected return type of the first element of the list : <class 'int'>")
    print("Actual return type of the first element of the list   : ", end="")
    if (isinstance(result, list)):
        print(type(result[0]))
    else:
        print("N/A")    

    tc_num += 1
    print('-' * 40)
    
    polynomials = [[1, 2], [3, 4, 5], [6, 7, 8]]
    print(f"Test Case {tc_num} : multiply({polynomials})")
    print('Expected : [18, 81, 172, 231, 174, 80]')
    print(f"Actual   : {multiply(polynomials)}")
    print() 
    
    tc_num += 1
    print('-' * 40)
    
    polynomials = [[1, 2], [0], [3, 4, 5], [6, 7, 8]]
    print(f"Test Case {tc_num} : multiply({polynomials})")
    print('Expected : [0]')
    print(f"Actual   : {multiply(polynomials)}")
    print()     

    tc_num += 1
    print('-' * 40)
    
    polynomials = [[1, 2, 3], [5, 6, 7], [8, 9, 0]]
    print(f'Test Case {tc_num} : multiply({polynomials})')
    print('Expected : [40, 173, 416, 562, 456, 189, 0]')
    print(f'Actual   : {multiply(polynomials)}')
    print()    

    tc_num += 1
    print('-' * 40)
    
    polynomials = [[1, 1, -1, 1], [2, 0], [8, 9, 0]]
    print(f'Test Case {tc_num} : multiply({polynomials})')
    print('Expected : [16, 34, 2, -2, 18, 0, 0]')
    print(f'Actual   : {multiply(polynomials)}')
    print()    

    tc_num += 1
    print('-' * 40)
    
    polynomials = [[1], [0]]
    print(f'Test Case {tc_num} : multiply({polynomials})')
    print('Expected : [0]')
    print(f'Actual   : {multiply(polynomials)}')
    print()    

    tc_num += 1
    print('-' * 40)
    
    polynomials = [[1, 5, 0, 4]]
    print(f'Test Case {tc_num} : multiply({polynomials})')
    print(f'multiply({polynomials})')
    print('Expected : [1, 5, 0, 4]')
    print(f'Actual   : {multiply(polynomials)}')
    print()    