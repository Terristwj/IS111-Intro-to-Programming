import sys

def same_values(r1, r2):
    if len(r1) == 2:
        if r1[0] == r2[0] and r1[1] == r2[1]:
            return True
    return False

# Test Cases
test_cases = [ ( [('A', 20), ('B', 30)], ('B', 'A') ),  # TC1: 2 products in increasing order
               ( [('A', 20), ('B', 10)], ('A', 'B') ),  # TC2: 2 products in decreasing order
               ( [('A', 1), ('B', 2), ('C', 3)], ('C', 'A') ),  # TC3: 3 products in increasing order
               ( [('A', 10), ('B', 9), ('C', 8)], ('A', 'C') ),  # TC4: 3 products in decreasing order
               ( [('3', 300), ('5', 500), ('1', 100), ('4', 400), ('2', 200)], ('5', '1') ),  # TC5: random order
               ( [('X', 50), ('Y', 35), ('Z', 20), ('U', 12), ('V', 70), ('W', 42)], ('V', 'U') ),  # TC6: random order
               ( [('ABC', 10)], ('ABC', 'ABC') ),  # TC7: single element 
               ( [], (None, None) ) # TC8: empty list
]

# Mapping from counter value to marks
table = [(0, 0, 0), 
         (1, 1, 1),
         (2, 2, 2),
         (3, 3, 3),
         (4, 5, 4),
         (6, 7, 5),
         (8, 8, 6)]

# Counter is to record how many test cases are passed.
counter = 0

try:
    from q2 import get_hi_lo

    for (parameter, result) in test_cases:
        try:
            my_result = get_hi_lo(parameter)
            if  my_result == result:
                counter += 1
            elif same_values(my_result, result):
                counter += 0.5          
        except:
            print('Exception:', sys.exc_info()[0])

    # If none of the test cases is passed, check if the returned type is correct.
    if counter == 0:
        # If the function returns a tuple for the first test case, give some partial marks.
        try:
            my_result = get_hi_lo(test_cases[0][0])
            if isinstance(my_result, tuple):
                counter += 1

        except:
            print('Exception:', sys.exc_info()[0])
            
except:
    print('Exception:', sys.exc_info()[0])

n = int(counter)

my_marks = 0
for (lower, upper, marks) in table:
    if n >= lower and n <= upper:
        my_marks = marks

print(str(my_marks) + ' marks awarded')