import sys

def all_zero(my_result):
    if not isinstance(my_result, list):
        return False
    for n in my_result:
        if n != 0:
            return False
    return True

# Test Cases

test_cases = [ ( [[3, -4, 2], [5, -1]], [15, -23, 14, -2] ), # TC1 - TC2: two polynomials
               ( [[5, 0, 0, 3, 2], [-2, 0, 4, 0]], [-10, 0, 20, -6, -4, 12, 8, 0] ),
               ( [[1, -4, 3], [2], [-9, 0, 4], [-8, 2, 3, 7]], [144, -612, 458, 254, 110, -370, -152, 168] ), # TC3 - TC4: multiple polynomials
               ( [ [1, 0, 0, 1], [1, 0, 1], [1, 1] ], [1, 1, 1, 2, 1, 1, 1] ),
               ( [ [1, -1], [1, 1, 1] ], [1, 0, 0, -1] ), # TC5: 0 coefficient in the result
               ( [[5, 9, -30, 2], [0], [34, -98, 24, -90]], [0] ) # TC6: zero polynomial. counted as 2.
]

# Mapping from counter value to marks
table = [(0, 0, 0),
         (1, 1, 0.5),
         (2, 3, 1),
         (4, 5, 2),
         (6, 6, 2.5),
         (7, 7, 3)]

# Counter is to record how many test cases are passed.
counter = 0

try:
    from q5a import multiply

    for (poly_list, result) in test_cases:
        try:
            my_result = multiply(poly_list)
            
            if result == [0]:
                if my_result == result:
                    counter += 2
                elif all_zero(my_result):
                    counter += 1
        
            else:
                if my_result == result:
                    counter += 1

        except:
            print('Exception:', sys.exc_info()[0])
            
            
except:
    print('Exception:', sys.exc_info()[0])

n = counter

my_marks = 0
for (lower, upper, marks) in table:
    if n >= lower and n <= upper:
        my_marks = marks
        
print(str(my_marks) + ' marks awarded')