import sys

# Test Cases

test_cases = [ ('trans_file.txt', 5, 5, 10, 2020, [10]), # TC1 - TC2: single day, single transaction, single-digit representation
               ('file-2.txt', 9, 9, 7, 2020, [90]),
               ('trans_file.txt', 10, 10, 9, 2020, [95]), # TC3 - TC4: single day, multiple transactions, single-digit representation
               ('file-2.txt', 10, 10, 1, 2018, [40]), 
               ('trans_file.txt', 7, 9, 10, 2020, [1, 300, 50]), # TC5 - TC6: multiple days, single transactions each, single-digit representation
               ('file-2.txt', 11, 14, 1, 2018, [15, 500, 40, 9]), 
               ('spending_file.txt', 3, 5, 9, 2020, [60, 57, 45]), # TC7 - TC10: multiple days, zero to multiple transactions on each day, mixed representation  
               ('spending_file.txt', 11, 14, 5, 2019, [0, 103, 0, 4]),
               ('file-4.txt', 1, 15, 1, 1998, [1, 0, 5, 40, 0, 0, 0, 0, 0, 43, 0, 0, 0, 0, 0]), 
               ('file-4.txt', 5, 8, 2, 1998, [3000, 0, 5400, 0]), 
               ('empty.txt', 6, 10, 3, 2020, [0, 0, 0, 0, 0]), # TC11: empty file
               ('trans_file.txt', 10, 11, 7, 2019, [0, 0]), # TC12: no transaction
]

# Mapping from counter value to marks
table = [(0, 0, 0),
         (1, 2, 0.5),
         (3, 5, 1),
         (6, 7, 1.5),
         (8, 9, 2),
         (10, 11, 2.5),
         (12, 12, 3)]

# Counter is to record how many test cases are passed.
counter = 0

try:
    from q4 import get_daily_spending

    for (file, start, end, month, year, result) in test_cases:
        try:
            if get_daily_spending(file, start, end, month, year) == result:
                counter += 1
        except:
            print('Exception:', sys.exc_info()[0])

    # If none of the test cases is passed, check if the returned type is correct.
    if counter == 0:
        # If the function returns a list for the first test case, give some partial marks.
        try:
            (file, start, end, month, year, result) = test_cases[0]
            my_result = get_daily_spending(file, start, end, month, year)
            if isinstance(my_result, list):
                counter += 1

        except:
            print('Exception:', sys.exc_info()[0])
            
except:
    print('Exception:', sys.exc_info()[0])

n = counter

my_marks = 0
for (lower, upper, marks) in table:
    if n >= lower and n <= upper:
        my_marks = marks


print(str(my_marks) + ' marks awarded')