import sys

# Test Cases
test_cases = [ ( [(20, 10, 15)], ['S'] ),  # TC1 to TC3: single tank
               ( [(30, 15, 25)], ['M'] ),
               ( [(40, 20, 30)], ['L'] ),
               ( [(30, 15, 25), (20, 10, 15), (40, 20, 30)], ['M', 'S', 'L'] ), # TC4 to TC6: multiple tanks
               ( [(10, 10, 10), (99, 98, 97), (25, 15, 10), (35, 20, 10)], ['S', 'L', 'S', 'M'] ), 
               ( [(1000, 2000, 5000), (231, 4, 5)], ['L', 'M'] ),
               ( [], [] ) # TC7: empty list
]

# Mapping from counter value to marks
table = [(0, 0, 0), 
         (1, 1, 1),
         (2, 2, 2),
         (3, 3, 3),
         (4, 4, 4),
         (5, 5, 5),
         (6, 6, 6),
         (7, 7, 7)]

# Counter is to record how many test cases are passed.
counter = 0

try:
    from q1 import get_all_tank_sizes

    for (parameter, result) in test_cases:
        try:
            if get_all_tank_sizes(parameter) == result:
                counter += 1
        except:
            print('Exception:', sys.exc_info()[0])

    # If none of the test cases is passed, check if the returned type is correct.
    if counter == 0:
        # If the function returns a list for the first test case, give some partial marks.
        try:
            my_result = get_all_tank_sizes(test_cases[0][0])
            if isinstance(my_result, list):
                counter += 1
        except:
            print('Exception:', sys.exc_info()[0])
            
except:
    print('Exception:', sys.exc_info()[0])

n = counter

my_marks = 0
for (lower, upper, marks) in table:
    if n >= lower and n <= upper:
        my_marks = marks

print(str(my_marks) + ' marks awarded')