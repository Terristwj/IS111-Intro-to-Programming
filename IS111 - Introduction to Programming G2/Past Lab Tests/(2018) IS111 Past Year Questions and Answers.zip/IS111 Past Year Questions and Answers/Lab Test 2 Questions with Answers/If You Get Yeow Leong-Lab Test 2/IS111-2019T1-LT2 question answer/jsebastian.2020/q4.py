#
# Name    :Juan Sebastian
# Email ID:jsebastian.2020
#


def get_free_timings(filename, target_building, target_facility, target_date):
    d={}
    with open(filename) as file:
        for line in file:
            ls=line.rstrip('\n').split()
            
            identifier=(ls[0],ls[1],ls[2])
            
            if len(ls)==4:
                booked=ls[-1].split('-')
            else:
                booked=[]
            
            free=[]
            for i in range(len(booked)):
                time=booked[i]
                if i==0 and time!='08:00':
                    free.append(('08:00',time))
                elif i==len(booked)-1 and time!='22:00':
                    free.append((time,'22:00'))
                tup=tuple(time.split(','))
                
                if ',' in time and tup[0]!=tup[1]:
                    free.append(tup)
            
            if booked==[]:
                free.append(('08:00','22:00'))
            
            d[identifier]=free
    
    identity=(target_building,target_facility,target_date)
    if identity in d:
        return d[identity]
    else:
        return [('08:00','22:00')]


if __name__ == "__main__":
    num = 0

    num += 1
    print(f'Test {num}')  # 1
    timings = get_free_timings('bookings.txt', 'SIS', 'SR2.2', '12/12/2019')
    print("Expected:<class 'list'> <class 'tuple'>")
    print(f'Actual  :{type(timings)} {type(timings[0])}')
    print()

    num += 1
    print(f'Test {num}')  # 2
    timings = get_free_timings('bookings.txt', 'SIS', 'SR2.2', '12/12/2019')
    print("Expected:[('08:00', '11:30'), ('11:45', '22:00')]")
    print(f'Actual  :{timings}')
    print()

    num += 1
    print(f'Test {num}')  # 3
    timings = get_free_timings('bookings.txt', 'SIS', 'SR2.1', '12/12/2019')
    print(
        "Expected:[('08:00', '11:30'), ('11:45', '12:30'), ('13:30', '14:20'), ('15:00', '22:00')]")
    print(f'Actual  :{timings}')
    print()

    timings = get_free_timings('bookings.txt', 'SIS', 'SR3.4', '12/12/2019')
    num += 1
    print(f'Test {num}')  # 4
    print("Expected:[('08:00', '22:00')]")
    print(f'Actual  :{timings}')
    print()

    timings = get_free_timings('bookings.txt', 'SIS', 'SR2.3', '12/12/2019')
    num += 1
    print(f'Test {num}')  # 5
    print("Expected:[]")
    print(f'Actual  :{timings}')
    print()

    timings = get_free_timings('bookings.txt', 'SIS', 'SR2.4', '12/12/2019')
    num += 1
    print(f'Test {num}')  # 6
    print("Expected:[('08:00', '22:00')]")
    print(f'Actual  :{timings}')
    print()

    timings = get_free_timings('bookings.txt', 'SIS', 'SR3.1', '12/12/2019')
    num += 1
    print(f'Test {num}')  # 6
    print("Expected:[('08:00', '08:01')]")
    print(f'Actual  :{timings}')
    print()

    timings = get_free_timings('bookings.txt', 'SOA', 'SR2.4', '12/12/2019')
    num += 1
    print(f'Test {num}')  # 7
    print("Expected:[('08:00', '22:00')]")
    print(f'Actual  :{timings}')
    print()

    # Note: this is reading from a different file
    timings = get_free_timings('bookings2.txt', 'SOA', 'SR2.4', '12/12/2019')
    num += 1
    print(f'Test {num}')
    print("Expected:[('12:45', '22:00')]")
    print(f'Actual  :{timings}')
    print()
