#
# Name    :Juan Sebastian
# Email ID:jsebastian.2020
#

def encode(message, num_rows):
    m=''
    for ch in message:
        if ch.isalnum():
            m+=ch.upper()
    length=len(m)
    num_col=length//num_rows
    if num_rows*num_col!=length:
        num_col+=1
        m+='#'*(num_col*num_rows-length)
    length=len(m)

    i=0
    map={}
    for c in range(num_col):
        if c%2==0:
            for r in range(num_rows-1,-1,-1):
                map[(c,r)]=m[i]
                i+=1
        else:
            for r in range(num_rows):
                map[(c,r)]=m[i]
                i+=1

    out=''
    
    for r in range(0,num_rows):
        out+=map[(num_col-1,r)]
    for c in range(num_col-2,-1,-1):
        out+=map[(c,num_rows-1)]
    path='up'
    v_start=num_rows-1
    v_len=num_rows
    h_start=0
    h_len=num_col-1
  
    while len(out)!=len(m):
        if path=='down':
            path='left'
            for r in range(v_start+1,v_start+v_len):
                out+=map[(h_start,r)]
            v_len-=1
            v_start+=v_len
        elif path=='left':
            path='up'
            for c in range(h_start-1,h_start-h_len,-1):
                out+=map[(c,v_start)]
            h_len-=1
            h_start-=h_len
        
        elif path=='right':
            path='down'
            for c in range(h_start+1,h_start+h_len):
                out+=map[(c,v_start)]
            h_len-=1
            h_start+=h_len
        
        elif path=='up':
            path='right'
            for r in range(v_start-1,v_start-v_len,-1):
                out+=map[(h_start,r)]
            v_len-=1
            v_start-=v_len
    
    return out


if __name__ == "__main__":
    num = 0

    num += 1
    print(f'Test {num}')
    print('Expected:#ODYEHTNENJETHESTARSSYTTERTHAWIEBTSUMUOEBYAHALOUS')
    result = encode(
        "The stars must be jealous. You shine way better than they do!", 7)
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    print('Expected:DOEHAHETBYENSUSUAEBTMSTSTHEARUSEJLOYOHIWAETRTNTY')
    result = encode(
        "The stars must be jealous. You shine way better than they do!", 2)
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    print('Expected:#######ODYEHOYTHESTARSMUSTBETTERTHANTUSUOLAEJEBYAWENIHS')
    result = encode(
        "The stars must be jealous. You shine way better than they do!", 11)
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    print('Expected:EENDTNHSIS111LGHTOOAEWLO')
    result = encode("IS111. We shall go on to the end.", 4)
    print(f'Actual  :{result}')
    print()
