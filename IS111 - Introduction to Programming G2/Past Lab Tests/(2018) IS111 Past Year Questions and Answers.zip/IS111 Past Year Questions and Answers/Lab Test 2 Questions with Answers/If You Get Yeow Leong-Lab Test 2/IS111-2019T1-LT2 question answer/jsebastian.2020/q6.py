#
# Name    :Juan Sebastian
# Email ID:jsebastian.2020
#

def expand(compressed):
    bracket=''
    final_txt=''
    num_of_open_bracket=0
    num_of_closed_bracket=0
    txt=''
    num=''

    for ch in compressed:
        
        if ch.isalpha() and bracket=='':
            final_txt+=ch
        if ch.isdigit() and bracket=='':
            num+=ch
        if ch.isdigit() and bracket=='[':
            txt+=ch
        if ch=='[':
            if num_of_open_bracket==0:
                bracket='['
                num_of_open_bracket+=1
                num=int(num)
                
            else:
                num_of_open_bracket+=1
                txt+=ch
            
        if ch==']':
            num_of_closed_bracket+=1
            if num_of_closed_bracket==num_of_open_bracket:
           
                final_txt+=num*expand(txt)
                num_of_open_bracket=0
                num_of_closed_bracket=0
                txt=''
                num=''
                bracket=''
                
            else:
                txt+=ch

        if ch.isalpha() and bracket=='[':
            txt+=ch

    return final_txt


if __name__ == "__main__":
    num = 0

    num += 1
    print(f'Test {num}')
    result = expand('2[abc]')
    print('Expected:abcabc')
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = expand('AA20[SIS]AA')
    print('Expected:AASISSISSISSISSISSISSISSISSISSISSISSISSISSISSISSISSISSISSISSISAA')
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = expand('2[ab]3[cd]')
    print('Expected:ababcdcdcd')
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = expand('3[2[ab]3[cd]]')
    print('Expected:ababcdcdcdababcdcdcdababcdcdcd')
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = expand('4[2[a]3[cd]def]')
    print('Expected:aacdcdcddefaacdcdcddefaacdcdcddefaacdcdcddef')
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = expand('2[3[ab2[c]]Z]')
    print('Expected:abccabccabccZabccabccabccZ')
    print(f'Actual  :{result}')
    print()
