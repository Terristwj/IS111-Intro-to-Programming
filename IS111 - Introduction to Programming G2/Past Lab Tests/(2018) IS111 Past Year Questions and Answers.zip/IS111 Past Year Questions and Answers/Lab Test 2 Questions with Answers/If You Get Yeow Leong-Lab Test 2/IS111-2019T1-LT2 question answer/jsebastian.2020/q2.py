#
# Name    :Juan Sebastian
# Email ID:jsebastian.2020
#
def check_valid(ls):
    if len(ls)!=4:
        return False
    for num in ls:
        if not(num.isdigit()):
            return False
        if not(0<=int(num)<=255):
            return False
    return True

def get_valid_ip_addresses(addr_list):
    ls_return=[]
    for address in addr_list:
        ls=address.split('.')
        if check_valid(ls):
            ls_return.append(address)
    return ls_return


if __name__ == "__main__":
    num = 0

    num += 1
    print(f'Test {num}')
    result = get_valid_ip_addresses(['10.10.10.10'])
    print("Expected:['10.10.10.10']")
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = get_valid_ip_addresses(['10.10.10.10'])
    print("Expected:<class 'list'> <class 'str'>")
    print(f'Actual  :{type(result)} {type(result[0])}')
    print()

    num += 1
    print(f'Test {num}')
    result = get_valid_ip_addresses(['10.10.10.999'])
    print("Expected:[]")
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = get_valid_ip_addresses(['apple'])
    print("Expected:[]")
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    result = get_valid_ip_addresses(
        ['0.255.255.255', '10.2.25.255', 'a.b.c.d', '10'])
    print("Expected:['0.255.255.255', '10.2.25.255']")
    print(f'Actual  :{result}')
    print()
