num += 1
    # print(f'Test {num}')
    # result = expand('3[2[ab]3[cd]]')
    # print('Expected:ababcdcdcdababcdcdcdababcdcdcd')
    # print(f'Actual  :{result}')
    # print()