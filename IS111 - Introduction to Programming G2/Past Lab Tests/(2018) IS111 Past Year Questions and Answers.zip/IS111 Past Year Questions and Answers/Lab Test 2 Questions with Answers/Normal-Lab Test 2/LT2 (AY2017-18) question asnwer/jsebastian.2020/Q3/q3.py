def get_postal_codes(file_name):
    # modify the code below
    ls2=[]
    with open(file_name) as file:
        for line in file:
            ls=line.rstrip('\n').split(',')
            tup=(ls[0],ls[-1].split()[-1])
       
            ls2.append(tup)
    return ls2
