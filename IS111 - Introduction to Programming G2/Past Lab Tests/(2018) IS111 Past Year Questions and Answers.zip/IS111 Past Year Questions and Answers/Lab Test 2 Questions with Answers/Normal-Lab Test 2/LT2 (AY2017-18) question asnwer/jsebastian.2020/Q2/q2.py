from typing import NamedTuple


def get_sum_of_odd_numbers(num_list):
    # modify the code below
    s=0
    for num in num_list:
        if num %2 ==1:
            s+=num

    return s
    