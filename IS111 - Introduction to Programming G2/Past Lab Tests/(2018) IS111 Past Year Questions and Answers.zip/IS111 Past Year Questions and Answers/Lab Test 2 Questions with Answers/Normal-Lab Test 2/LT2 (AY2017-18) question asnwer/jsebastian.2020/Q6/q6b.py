
def get_all_permutations(letters):
    # modify the code below
    import math
    from random import randrange
    minimum_time=math.factorial(len(letters))
    ls=[]
    while len(ls)!=minimum_time:
        x=[]
        for i in range(len(letters)):
            r=randrange(len(letters))
            while r in x:
                 r=randrange(len(letters))
            x.append(r)
        while x in ls:
            x=[]
            for i in range(len(letters)):
                r=randrange(len(letters))
                while r in x:
                    r=randrange(len(letters))
                x.append(r)
        ls.append(x)
    ret=[]
    for index in ls:
        txt=''
        for i in index:
            txt+=letters[i]
        ret+=[txt]
    ret=list(set(ret))
    ret.sort()
    return ret
