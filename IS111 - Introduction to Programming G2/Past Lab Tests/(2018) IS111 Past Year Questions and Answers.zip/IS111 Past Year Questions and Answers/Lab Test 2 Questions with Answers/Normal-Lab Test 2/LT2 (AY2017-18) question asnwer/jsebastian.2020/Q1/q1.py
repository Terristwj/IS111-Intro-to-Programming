def count_long_strings(str_list):
    # modify the code below
    ls=0
    for s in str_list:
        if len(s)>=5:
            ls+=1
    return ls
