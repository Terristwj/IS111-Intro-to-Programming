def evaluate(expression):
    # modify the code below
    num=''
    ls=[]
    for exp in expression:
        if exp.isdigit() or exp=='.':
            num+=exp
        else:
            ls.append(float(num))
            num=''
            ls.append(exp)
    ls.append(float(num))

    while "*"in ls or "/"in ls:
        second=[]
        prev=''
        for i in range(1,len(ls),2):
            ch=ls[i]
            if ch in '*/' and prev=='':
                prev='*'
                if ch =='*':
                    eva=ls[i-1]*ls[i+1]
                else:
                    eva=ls[i-1]/ls[i+1]
                second.append(eva)
            elif ch in '+-' and prev=='':
                second.append(ls[i-1])
                second.append(ch)
            elif ch in '*/+-' and prev!='':
                second.append(ch)
                prev=''
        if prev=='':
            second.append(ls[-1])
        ls=second
      
    num=None
    sym=''
    out=[]
    val=None
    if len(ls)>1:
        for ch in ls:
            if str(ch) not in '+-' and num==None:
                num=ch
            elif str(ch) not in "+-" and num!=None and val==None:
                num2=ch
                if sym=='+':
                    val=num + num2
                else:
                    val=num - num2
            elif str(ch) not in "+-" and val!=None:
                if sym=='+':
                    val=val + ch
                else:
                    val=val - ch
            elif ch =='+':
                sym='+'
            elif ch=='-':
                sym='-'
        return val
    else:

        return ls[0]
