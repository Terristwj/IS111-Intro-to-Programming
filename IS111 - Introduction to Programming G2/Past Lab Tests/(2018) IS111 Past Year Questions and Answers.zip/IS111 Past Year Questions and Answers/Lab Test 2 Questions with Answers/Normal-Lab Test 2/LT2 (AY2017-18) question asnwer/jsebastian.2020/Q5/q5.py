from typing import List


def get_family_members(head):
    # modify the code below
    if type(head)!=list:
        head=[head]
    ls=[]    
    for tup in head:
        ls.append(tup[0])
    child=[]
    for tup in head:
        if tup[1]!=[]:
            child+=tup[1]
    if child !=[]:
        ls+=get_family_members(child)
    return ls
    
    
