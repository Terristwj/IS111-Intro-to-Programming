def scramble(word, file_name):
    # modify the code below

    d={}
    with open(file_name) as file:
        for line in file:
            line=line.rstrip('\n')
            ls=list(line)
            unique=set(ls)
            identity=[]
            for ch in unique:
                total=ls.count(ch)
                identity.append((ch,total))
            identity.sort()
            identity=tuple(identity)
            d[identity]= d.get(identity,[])+[line]

    ls2=list(word)
    u=set(ls2)
    ident=[]
    for ch in u:
        t=ls2.count(ch)
        ident.append((ch,t))
    ident.sort()

  
    ident=tuple(ident)
    if ident in d:
        return d[ident]
    
    return []
    