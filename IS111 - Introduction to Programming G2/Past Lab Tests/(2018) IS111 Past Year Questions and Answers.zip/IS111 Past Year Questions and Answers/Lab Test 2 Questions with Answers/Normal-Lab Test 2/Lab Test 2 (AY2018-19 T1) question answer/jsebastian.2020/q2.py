#
# Name: Juan Sebastian
# Email ID: jsebastian.2020
#
def get_prices_in_range(price_list, low, high):
    # Modify the code below   
    ls=[]
    for price in price_list:
        if low<= price<=high:
            ls.append(price)
    return ls