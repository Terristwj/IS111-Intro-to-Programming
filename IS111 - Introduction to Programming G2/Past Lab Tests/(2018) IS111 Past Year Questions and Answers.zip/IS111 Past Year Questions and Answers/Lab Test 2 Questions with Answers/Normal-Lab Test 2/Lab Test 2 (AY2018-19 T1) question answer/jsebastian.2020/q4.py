#
# Name: Juan Sebastian
# Email ID: jsebastian.2020
#

# If needed, you can define your own additional functions here.
# Start of your additional functions.


# End of your additional functions.


def find_stations_within_distance(mrt_map, orig, dist):
    # Modify the code below
    all_station=[]
    for mrt_line in mrt_map:
        for station in mrt_line:
            all_station.append(station)
    all_station=list(set(all_station))

    link={}
    for station in all_station:
        for mrt_line in mrt_map:
            if station in mrt_line:
                i=mrt_line.index(station)
                last_i=len(mrt_line)-1
                if i==0 and last_i!=0:
                    link[station]=link.get(station,[])+[mrt_line[i+1]]
                elif i==last_i:
                    link[station]=link.get(station,[])+[mrt_line[i-1]]
                else:
                    link[station]=link.get(station,[])+[mrt_line[i-1]]+[mrt_line[i+1]]
    r=[orig]
    
    for _ in range(dist):
        ls=[]
        for station in r:
            ls+=link[station]
        r+=ls
        r=list(set(r))

    r.remove(orig)
    return r
