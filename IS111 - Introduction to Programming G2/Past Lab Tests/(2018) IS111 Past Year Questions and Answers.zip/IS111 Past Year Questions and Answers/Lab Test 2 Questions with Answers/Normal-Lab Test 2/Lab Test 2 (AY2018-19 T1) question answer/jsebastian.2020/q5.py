#
# Name: Juan Sebastian
# Email ID: jsebastian.2020
#

# If needed, you can define your own additional functions here.
# Start of your additional functions.


# End of your additional functions.

def convert_to_list(num_list_str):
    # Modify the code below
    num_list_str=num_list_str[1:-1]+','
    open_bracket=False
    open_bracket_count=0
    close_bracket_count=0
    ls=[]
    txt=''
    num=''

    for ch in num_list_str:

        if open_bracket==False:

            if ch.isdigit() :
                num+=ch

            elif ch=='[' :
                open_bracket=True
                open_bracket_count+=1
                txt+=ch

            elif ch==',' and num != '':
                
                ls+=[int(num)]
                num=''

        elif open_bracket==True:

            if ch==']':
                close_bracket_count+=1
                txt+=ch

                if open_bracket_count==close_bracket_count:
                    ls+=[convert_to_list(txt)]
                    txt=''
                    open_bracket=False

            elif ch=='[':
                open_bracket_count+=1
                txt+=ch

            else:
                txt+=ch

    return ls
    
