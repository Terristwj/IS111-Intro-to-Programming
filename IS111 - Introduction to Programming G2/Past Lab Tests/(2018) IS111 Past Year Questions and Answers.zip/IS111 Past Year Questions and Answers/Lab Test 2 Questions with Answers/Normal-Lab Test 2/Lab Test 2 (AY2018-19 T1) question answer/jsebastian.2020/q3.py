#
# Name: Juan Sebastian
# Email ID: jsebastian.2020
#

# If needed, you can define your own additional functions here.
# Start of your additional functions.


# End of your additional functions.

def get_total_transactions_in_month(trans_file, month):
    # Modify the code below
    data=month.split('/')
    month=int(data[0])
    year=int(data[1])
    total=0.0
    with open(trans_file) as file:
        for line in file:
            ls=line.rstrip('\n').split('\t')
            date=ls[0].split('/')

            mm=int(date[0])
            yyyy=int(date[2])
            price=float(ls[1][1:])
            if yyyy==year and mm==month:
                total+=price


        
    return total
