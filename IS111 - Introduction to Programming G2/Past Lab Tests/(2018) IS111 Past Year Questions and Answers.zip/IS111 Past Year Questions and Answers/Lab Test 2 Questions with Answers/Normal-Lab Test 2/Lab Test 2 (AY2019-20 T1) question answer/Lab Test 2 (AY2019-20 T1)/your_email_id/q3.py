# Name:
# Email ID:

def compute_total_price(price_dict, item_list):
    # Modify the code below.
    return None