# Name:
# Email ID:

def store_family_relations(family_file):
    # Modify the code below.
    return None
    