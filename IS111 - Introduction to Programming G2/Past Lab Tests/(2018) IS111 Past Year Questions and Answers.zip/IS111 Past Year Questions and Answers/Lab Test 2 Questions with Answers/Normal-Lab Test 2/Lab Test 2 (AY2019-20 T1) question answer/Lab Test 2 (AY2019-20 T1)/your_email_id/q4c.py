# Name:
# Email ID:

def get_relation(family_dict, p1, p2):
    # Modify the code below.
    return None
    