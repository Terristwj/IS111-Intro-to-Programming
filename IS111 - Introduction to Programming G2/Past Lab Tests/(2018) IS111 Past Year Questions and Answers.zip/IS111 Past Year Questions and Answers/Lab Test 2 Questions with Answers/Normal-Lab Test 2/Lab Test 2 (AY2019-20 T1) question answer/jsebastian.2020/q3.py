# Name: Juan Sebastian
# Email ID: jsebastian.2020

def compute_total_price(price_dict, item_list):
    # Modify the code below.
    total=0.0
    for item, num in item_list:
        if item in price_dict:
            total+= price_dict[item]*num
 

    return total