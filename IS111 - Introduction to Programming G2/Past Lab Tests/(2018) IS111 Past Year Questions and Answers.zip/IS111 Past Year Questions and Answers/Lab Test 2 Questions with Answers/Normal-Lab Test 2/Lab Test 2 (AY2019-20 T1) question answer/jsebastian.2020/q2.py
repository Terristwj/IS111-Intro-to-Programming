# Name: Juan Sebastian
# Email ID: jsebastian.2020

def get_longer_words(file_name):
    # Modify the code below.
    ls_return=[]
    with open(file_name) as file:
        for line in file:
            ls_line=line.rstrip('\n').split('&')
            word=max(ls_line, key=len)
            ls_return.append(word)
    return ls_return