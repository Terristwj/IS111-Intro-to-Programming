# Name: Juan Sebastian
# Email ID: jsebastian.2020

def get_relation_through_link(family_dict, link):
    # Modify the code below.
    relation={}
    with open ("relation_mapping.txt") as file:
        for line in file:
            line=line.rstrip('\n').split(":")
            relation[line[0]]=line[1]
  
    rel=[]
    for i in range(1,len(link)):
        pair=(link[i-1],link[i])
      
        rel.append(family_dict[pair])
  
    if len(rel)==2:
        for i in range(1,len(rel)):
            pair=str((rel[i-1],rel[i])).replace(" ",'').replace("'",'')
            rel=relation[pair]
        return rel
    if len(rel)==3:
        what=[]
        pair=str((rel[0],rel[1])).replace(" ",'').replace("'",'')
        what.append((relation[pair],rel[2]))
        what=str(what[0]).replace(" ",'').replace("'",'')
        return relation[what]
        
    #(a,b,c)-->(x,c)
    