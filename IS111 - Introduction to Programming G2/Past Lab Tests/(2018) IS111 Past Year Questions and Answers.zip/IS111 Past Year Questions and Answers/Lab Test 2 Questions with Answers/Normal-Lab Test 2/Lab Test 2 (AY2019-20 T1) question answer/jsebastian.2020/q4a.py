# Name: Juan Sebastian
# Email ID: jsebastian.2020

def store_family_relations(family_file):
    # Modify the code below.
    d={}
    with open(family_file) as file:
        for line in file:
            line=line.rstrip('\n')
            pc=line.split(":")
            parents=pc[0].replace("(","").replace(")","").split(',')
            child=pc[1].split(";")
            print(child)
            childs=[]
            for c in child:
                c=(c[1:-3],c[-2])
                childs.append(c)
            i=0
            for p in parents:
                for c in childs:
                    if i==0:
                        d[(p,c[0])]='father'
                    else:
                        d[(p,c[0])]='mother'
                    
                    if c[1]=="F":
                        d[(c[0],p)]='daughter'
                    else:
                        d[(c[0],p)]='son'
                i+=1
    return d

