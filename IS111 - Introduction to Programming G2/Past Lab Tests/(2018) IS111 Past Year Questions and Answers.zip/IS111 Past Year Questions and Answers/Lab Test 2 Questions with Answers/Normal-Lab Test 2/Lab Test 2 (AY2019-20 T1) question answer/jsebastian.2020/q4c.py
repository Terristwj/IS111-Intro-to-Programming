# Name: Juan Sebastian
# Email ID: jsebastian.2020

def get_relation(family_dict, p1, p2):
    # Modify the code below.
    from q4b import get_relation_through_link
    d={}
    for k,v in family_dict.keys():
        if k not in d:
            d[k]=v
        else:
            d[k]+=v
    for ch in d[p1]:
        if p2==ch:
            return get_relation_through_link(family_dict, [p1,p2])
    for ch in d[p1]:
        for ch2 in d[ch]:
            if p2==ch2:
                return get_relation_through_link(family_dict, [p1,ch,p2])
        for c in d[ch]:
            for ch3 in d[c]:
                if p2==ch3:
                    return get_relation_through_link(family_dict, [p1,ch,c,p2])