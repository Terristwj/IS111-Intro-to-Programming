# Name: Juan Sebastian
# Email ID: jsebastian.2020

def transform(source, destination):
    seq=[source]
    for char in destination[::-1]:
        idx2=destination.find(char)
        idx1=seq[-1].find(char)
        for swap in range(idx2-idx1):
            i=seq[-1].find(char)
            string=seq[-1]
            string=string[:i]+string[i+1]+string[i]+string[i+2:]
            seq.append(string)
    r=''
    for char in seq:
        r+=char+'-'
        
    return r[:-1]

if __name__ == "__main__":       
    print('Test 1')
    result = transform('ABC', 'CAB')
    print('Expected:ABC-ACB-CAB')
    print(f'Actual  :{result}')
    print()

    print('Test 2:Check data type')
    result = isinstance(transform('ABC', 'CAB'), str)
    print('Expected:True')
    print(f'Actual  :{result}')
    print()

    print('Test 3')
    result = transform('ABCD', 'DCAB')
    print('Expected:ABCD-ACBD-ACDB-CADB-CDAB-DCAB')
    print(f'Actual  :{result}')
    print()

    print('Test 4')
    result = transform('ABCDE', 'DBECA')
    print('Expected:ABCDE-BACDE-BCADE-BCDAE-BCDEA-BDCEA-BDECA-DBECA')
    print(f'Actual  :{result}')
    print()