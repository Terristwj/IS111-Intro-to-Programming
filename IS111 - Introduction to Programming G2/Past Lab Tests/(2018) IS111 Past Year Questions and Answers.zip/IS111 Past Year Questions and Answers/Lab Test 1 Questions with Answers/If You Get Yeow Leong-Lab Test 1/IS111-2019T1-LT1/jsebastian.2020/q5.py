# Name: Juan Sebastian
# Email ID: jsebastian.2020

def print_number_pattern(n, number):
    num_of_numbers= sum(range(1,n+1))
    ls_num=range(number,number+num_of_numbers)
    width_num=max(len(str(ls_num[-1])),len(str(ls_num[0])))
    str_num=[]
    for num in ls_num:
        if len(str(num))!=width_num:
            str_num.append('*'*(width_num-len(str(num)))+str(num))
        else:
            str_num.append(str(num))
    str_num=str_num[::-1]

    direction=n%2 # if odd(1), 2nd line move left, viceversa
    count=0

    for level in range(1,n+1):
        ls_line=[]
        line=''
        for num in str_num[count:count+level]:
            ls_line.append(str(num)+'|')
        if direction==0:
            ls_line=ls_line[::-1]
            direction=1
        else:
            direction=0
        for char in ls_line:
            line+=char
        line=line.strip('|')
        print(line)
        count+=level
        


if __name__ == "__main__":       
    print('Test 1')
    print('Expected:')
    print('13')
    print('11|12')
    print('10|*9|*8')
    print()
    print('Actual:')
    print_number_pattern(3, 8)
    print()
    print()

    print('Test 2')
    print('Expected:')
    print('6')
    print('4|5')
    print('3|2|1')
    print()
    print('Actual:')
    print_number_pattern(3, 1)
    print()
    print()

    print('Test 3')
    print('Expected:')
    print('44')
    print('42|43')
    print('41|40|39')
    print('35|36|37|38')
    print('34|33|32|31|30')
    print('24|25|26|27|28|29')
    print('23|22|21|20|19|18|17')
    print('*9|10|11|12|13|14|15|16')
    print('*8|*7|*6|*5|*4|*3|*2|*1|*0')
    print()
    print('Actual:')
    print_number_pattern(9, 0)
    print()
    print()

    print('Test 4')
    print('Expected:')
    print('*-95')
    print('*-97|*-96')
    print('*-98|*-99|-100')
    print()
    print('Actual:')
    print_number_pattern(3, -100)
    print()
    print()

    print('Test 5')
    print('Expected:')
    print('17')
    print('16|15')
    print('12|13|14')
    print('11|10|*9|*8')
    print()
    print('Actual:')
    print_number_pattern(4, 8)
    print()
    print()

    print('Test 6:check return')
    print('Expected:')
    print('3')
    print('2|1')
    print('None')
    print()
    print('Actual:')
    result = print_number_pattern(2, 1)
    print(f'{result}')
    print()
