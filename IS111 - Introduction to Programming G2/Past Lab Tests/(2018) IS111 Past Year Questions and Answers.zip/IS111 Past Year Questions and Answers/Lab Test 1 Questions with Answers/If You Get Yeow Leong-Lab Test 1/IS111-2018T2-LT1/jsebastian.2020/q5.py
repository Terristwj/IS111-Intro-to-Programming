# Name: Juan Sebastian
# Email ID: jsebastian.2020 

# Start your code here
def get_golden_level(hp_num):
    golden=0
    for i in range(len(hp_num)-2):
        if hp_num[i]==hp_num[i+1] and hp_num[i]==hp_num[i+2]:
            golden+=1
            break
    
    for i in range(len(hp_num)-2):
        if (int(hp_num[i])==int(hp_num[i+1])-1 and int(hp_num[i])==int(hp_num[i+2])-2) or (int(hp_num[i])==int(hp_num[i+1])+1 and int(hp_num[i])==int(hp_num[i+2])+2) :
            golden+=1
            break
    
    for i in range(len(hp_num)-1):
        ch=hp_num[i]+hp_num[i+1]
        if hp_num.count(ch)>=2 and hp_num[i]!=hp_num[i+1]:
            golden+=1
            break
    return golden


# End your code here 
# Do not modify the code below this line

if __name__ == '__main__':
    print('Test 1')
    print('Expected:0')
    result = get_golden_level('98133629')
    print('Actual  :' + str(result))
    print()

    print('Test 2')
    print('Expected:3')
    result = get_golden_level('91112123')
    print('Actual  :' + str(result))
    print()

    print('Test 3')
    print('Expected:1')
    result = get_golden_level('91853456')
    print('Actual  :' + str(result))
    print()

    print('Test 4')
    print('Expected:2')
    result = get_golden_level('93456345')
    print('Actual  :' + str(result))
    print()

    print('Test 5')
    print('Expected:1')
    result = get_golden_level('63411113')
    print('Actual  :' + str(result))
    print()



