# Name: Juan Sebastian
# Email ID: jsebastian.2020 

def repeat(word, n):
    r=''
    if word =='' or n<=0:
        return ''
    for i in range(n):
        r+= word+'-'
    return r[:-1]

if __name__ == '__main__':
    print('Test 1')
    result = repeat('apple', 5)
    print('Expected:apple-apple-apple-apple-apple')
    print('Actual  :' + result)
    print()


    print('Test 2')
    result = repeat('arrow', 3)
    print('Expected:arrow-arrow-arrow')
    print('Actual  :' + result)
    print()

    print('Test 3')
    result = repeat('B', 2)
    print('Expected:B-B')
    print('Actual  :' + result)
    print()

    print('Test 4')
    result = repeat('', 5)
    print('Expected:[]')
    print('Actual  :[' + result + ']')
    print()

    print('Test 5')
    result = repeat('busy', 0)
    print('Expected:[]')
    print('Actual  :[' + result + ']')
    print()

    print('Test 6')
    result = repeat('busy', -2)
    print('Expected:[]')
    print('Actual  :[' + result + ']')
    print()
