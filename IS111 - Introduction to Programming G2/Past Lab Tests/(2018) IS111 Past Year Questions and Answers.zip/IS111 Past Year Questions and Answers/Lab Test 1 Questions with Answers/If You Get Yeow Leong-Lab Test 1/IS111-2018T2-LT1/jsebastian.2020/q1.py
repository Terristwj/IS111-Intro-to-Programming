# Name: Juan Sebastian
# Email ID: jsebastian.2020

def get_name_with_honor(name, gpa):
    if gpa<3.4:
        return name
    elif gpa<3.6:
        return name+'(*)'
    elif gpa<3.8:
        return name+'(**)'
    else:
        return name+'(***)'
        
if __name__ == '__main__':
    print('Test 1')
    print('Expected:TAN Ah Beng')
    result = get_name_with_honor('TAN Ah Beng', 3.3)
    print('Actual  :' + result)
    print()

    print('Test 2')
    print('Expected:Mary TOH(*)')
    result = get_name_with_honor('Mary TOH', 3.5)
    print('Actual  :' + result)
    print()

    print('Test 3')
    print('Expected:Bill(**)')
    result = get_name_with_honor('Bill', 3.6)
    print('Actual  :' + result)
    print()

    print('Test 4')
    print('Expected:Smarty(***)')
    result = get_name_with_honor('Smarty', 3.92)
    print('Actual  :' + result)
    print()
