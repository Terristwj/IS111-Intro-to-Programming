# Name: Juan Sebastian
# Email ID: jsebastian.2020

# Start your code here
def print_rectangle(sentence, num_rows, num_cols):
    char_needed=4+(num_cols-2)*2 + (num_rows-2)*2
    if len(sentence)<char_needed :
        return False
    sentence=sentence[:char_needed]
    print(sentence[int(-num_cols/2):]+sentence[:round(num_cols/2+0.1)])
    start_left=int(-num_cols/2)-1
    start_right=round(num_cols/2+0.1)
    for i in range(num_rows-2):
        print(sentence[start_left-i]+' '*(num_cols-2)+sentence[start_right+i])
    print(sentence[start_left-num_rows+2:start_right+num_rows-3:-1])
    return True
# End your code here 
# Do not modify the code below this line

if __name__ == '__main__':
    print('Test 1')
    print('Expected:')
    print('klab')
    print('j  c')
    print('i  d')
    print('hgfe')
    print('True')
    print()
    print('Actual:')
    result = print_rectangle('abcdefghijkl', 4, 4)
    print (result)
    print('-' * 10)
    print()

    print('Test 2')
    print('Expected:')
    print('STABC')
    print('R   D')
    print('Q   E')
    print('P   F')
    print('O   G')
    print('N   H')
    print('MLKJI')
    print('True')
    print()
    print('Actual:')
    result = print_rectangle('ABCDEFGHIJKLMNOPQRST', 7, 5)
    print (result)
    print('-' * 10)
    print()

    print('Test 3')
    print('Expected:False')
    print()
    result = print_rectangle('abcdefghij', 4, 4)
    print ('Actual  :' + str(result))
    print('-' * 10)
    print()


    print('Test 4')
    print('Expected')
    print('69')
    print('78')
    print('True')
    print ('Actual  :')
    result = print_rectangle('987654321', 2, 2)
    print(str(result))
    print('-' * 10)
    print()


    print('Test 5')
    print('Expected')
    print('ianapp')
    print('r    l')
    print('u    e')
    print('d     ')
    print('*    k')
    print('r    i')
    print('aep iw')
    print('True')
    print ('Actual  :')
    result = print_rectangle('apple kiwi pear*durian', 7, 6)
    print(str(result))
    print()