#
# Name    : Juan Sebastian
# Email ID: jsebastian.2020
#

def add(num):
    s_num=str(num)
    to_return=''
    
    if num<0:
        to_return+=str(int(s_num[:2])+1)
        for i in range(2,len(s_num)):
            
            to_return+=str(1+int(s_num[i]))
    else:
        for i in range(len(s_num)):
            
            to_return+=str(1+int(s_num[i]))
    return int(to_return)

if __name__ == "__main__":
    n = 0

    n += 1
    print(f'Test {n}')
    result = add(123)
    print('Expected:234')
    print(f'Actual  :{result}')
    print()


    n += 1
    print(f'Test {n}')
    result = add(907)
    print('Expected:1018')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = add(-907)
    print('Expected:-818')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = add(-1007)
    print('Expected:118')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = add(-1)
    print('Expected:0')
    print(f'Actual  :{result}')
    print()
