#
# Name    : Juan Sebastian
# Email ID: jsebastian.2020
#

def repeat(word, n):
    if len(word)==0:
        return ''
    left_over=n%len(word)
    full_word=n//len(word)
    return word*full_word+word[:left_over]

if __name__ == "__main__":
    n = 0

    n += 1
    print(f'Test {n}')
    result = repeat('Hello!', 3)
    print('Expected:Hel')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = repeat('ace', 3)
    print('Expected:ace')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = repeat('ace', 10)
    print('Expected:aceaceacea')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = repeat('apple', 0) 
    print('Expected:><')
    print(f'Actual  :>{result}<')
    print()
    
    n += 1
    print(f'Test {n}')
    result = repeat('', 10) 
    print('Expected:><')
    print(f'Actual  :>{result}<')
    print()

