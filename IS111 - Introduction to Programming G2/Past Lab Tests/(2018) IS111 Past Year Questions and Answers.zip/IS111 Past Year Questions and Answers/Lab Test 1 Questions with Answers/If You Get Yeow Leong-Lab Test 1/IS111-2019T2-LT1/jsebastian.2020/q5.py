#
# Name: Juan Sebastian
# Email ID: jsebastian.2020
#
def print_diamond(n,ch):
    alphabet='abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ'
    width=n*2-1
    height=width
    
    to_use=alphabet[alphabet.find(ch):alphabet.find(ch)+n]
    
    to_use=to_use[::-1]
    for i in range(height):
        num_of_hash=abs((n-1-i))
        if i==0 or i==height-1:
            line='#'*num_of_hash+ to_use[0] +'#'*num_of_hash
            print(line)
        elif i<n:
            section=to_use[:i+1]
            section2=section[-2::-1]
            line='#'*num_of_hash+ section+ section2 +'#'*num_of_hash
            print(line)
        
        else:
            section=to_use[:n-(i-n+1)]
            section2=section[-2::-1]
            line='#'*num_of_hash+ section+ section2 +'#'*num_of_hash
            print(line)


if __name__ == "__main__":
    n = 0
    
    n += 1
    print(f'Test {n}')
    print('Expected:')
    print('a')
    print('Actual  :')
    print_diamond(1, 'a')
    print()

    n += 1
    print(f'Test {n}')
    print('Expected:')
    print('#b#')
    print('bab')
    print('#b#')
    print('Actual  :')
    print_diamond(2, 'a')
    print()

    n += 1
    print(f'Test {n}')
    print('Expected:')
    print('##c##')
    print('#cbc#')
    print('cbabc')
    print('#cbc#')
    print('##c##')
    print('Actual  :')
    print_diamond(3, 'a')
    print()

    n += 1
    print(f'Test {n}')
    print('Expected:')
    print('####C####')
    print('###CBC###')
    print('##CBABC##')
    print('#CBAZABC#')
    print('CBAZYZABC')
    print('#CBAZABC#')
    print('##CBABC##')
    print('###CBC###')
    print('####C####')
    print('Actual  :')
    print_diamond(5, 'Y')
    print()