#
# Name    : Juan Sebastian
# Email ID: jsebastian.2020
#
def get_longest(sentence):
    longest=''
    longest_num=0
    current=''
    count=0
    for char in sentence:

        if current != char:
            current=char
            count=1

        elif current==char:
            count+=1
        if count>longest_num:
            longest_num=count
            longest=current
        if count==longest_num and current not in longest:
            longest+=current
    return longest

if __name__ == "__main__":
    n = 0
    
    n += 1
    print(f'Test {n}')
    result = get_longest('aabccaaa')
    print('Expected:a')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = get_longest('ddaabccaa')
    print('Expected:dac')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = get_longest('cbbccccdddd')
    print('Expected:cd')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = get_longest('bbbbccddddbbbb')
    print('Expected:bd')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = get_longest('')
    print('Expected:><')
    print(f'Actual  :>{result}<')
    print()

    n += 1
    print(f'Test {n}')
    result = get_longest('a')
    print('Expected:a')
    print(f'Actual  :{result}')
    print()
