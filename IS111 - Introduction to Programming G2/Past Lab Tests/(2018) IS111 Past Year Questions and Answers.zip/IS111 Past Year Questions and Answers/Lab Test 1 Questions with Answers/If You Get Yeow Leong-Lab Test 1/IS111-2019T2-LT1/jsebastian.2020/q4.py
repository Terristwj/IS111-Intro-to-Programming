#
# Name    : Juan Sebastian
# Email ID: jsebastian.2020
#

def get_term(num):
    current_term='1'
    track_term=''
    next_term=''
    count_track=[]
    current=''
    count=0
    for i in range(num):
        track_term=''
        for i in range(len(next_term)):
            track_term+=str(count_track[i])+ next_term[i]
            current_term=track_term

        count_track=[]
        next_term=''
        current=''

        for char in current_term:
            if current!=char:
                current=char
                next_term+=char
                count=1
                count_track.append(count)
            elif current==char:
                count+=1
                count_track[-1]=count
        
    return int(current_term)

if __name__ == "__main__":
    n = 0

    # 1, 11, 21, 1211, 111221, 312211, 13112221, 1113213211, …
    n += 1
    print(f'Test {n}')
    result = get_term(1)
    print('Expected:1')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = isinstance(get_term(1), int)
    print('Expected:True')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = get_term(2)
    print('Expected:11')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = get_term(3)
    print('Expected:21')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = get_term(4)
    print('Expected:1211')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = get_term(5)
    print('Expected:111221')
    print(f'Actual  :{result}')
    print()