if first!=0:
        #     