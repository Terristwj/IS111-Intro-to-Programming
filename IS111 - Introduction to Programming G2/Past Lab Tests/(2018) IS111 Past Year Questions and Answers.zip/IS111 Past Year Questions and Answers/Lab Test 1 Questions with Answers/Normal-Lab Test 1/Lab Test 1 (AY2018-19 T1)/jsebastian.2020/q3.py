#
# Name: Juan Sebastian
# Email ID: jsebastian.2020
#
def mask_out(sentence, banned, substitutes):
    # write your answer between #start and #end
    #start

    for i in range(len(banned)):
        if i<len(substitutes):
            sentence=sentence.replace(banned[i],substitutes[i])
        else:
            sentence=sentence.replace(banned[i],substitutes[0])
    return sentence
    #end


print('Test 1')
print('Expected:abcd#')
print('Actual  :' + mask_out('abcde', 'e', '#'))
print()

print('Test 2')
print('Expected:#$solute')
print('Actual  :' + mask_out('absolute', 'ab', '#$'))
print()

print('Test 3')
print('Expected:121hon')
print('Actual  :' + mask_out('python', 'pyt', '12'))
print()





