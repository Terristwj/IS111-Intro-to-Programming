#
# Name: Juan Sebastian
# Email ID: jsebastian.2020
#
def print_snake(sequence, w):
    # write your answer between #start and #end
    #start
    section=len(sequence)//(w+1)
    left_over=len(sequence)%(w+1)

    

    tracker=(section+1)%2 # 0 is left 1 is right
    count=0
    seq=''
    if left_over!=0:
        seq=' '*(w-left_over)+sequence[:left_over]
    

    if tracker==0:
        seq=seq[::-1]
    
    for i in range(left_over,len(sequence[left_over:]),w+1):
        
        if tracker==1:
            seq+='\n'+' '*(w-1)+sequence[i]+'\n'+sequence[i+w:i:-1]
            tracker=0
        else:
            seq+='\n'+sequence[i]+" "*(w-1)+'\n'+sequence[i+1:i+w+1]
            tracker=1

    print(seq.strip('\n'))


    print()
    #end

print('Test 1')
print('Expected:')
print('abcd')
print('   e')
print('ihgf')
print('j   ')
print('klmn')
print('-' * 20)
print('Actual:')
print_snake('abcdefghijklmn', 4)
print('\n')

print('Test 2')
print('Expected:')
print('cba')
print('d  ')
print('efg')
print('  h')
print('kji')
print('l  ')
print('mno')
print('-' * 20)
print('Actual:')
print_snake('abcdefghijklmno', 3)
print('\n')

print('Test 3')
print('Expected:')
print('    a')
print('fedcb')
print('g    ')
print('hijkl')
print('-' * 20)
print('Actual:')
print_snake('abcdefghijkl', 5)
print('\n')

print('Test 4')
print('Expected:')
print('   a')
print('   b')
print('fedc')
print('g   ')
print('hijk')
print('-' * 20)
print('Actual:')
print_snake('abcdefghijk', 4)
print('\n')
    
print('Test 5')
print('Expected:')
print('a   ')
print('b   ')
print('cdef')
print('-' * 20)
print('Actual:')
print_snake('abcdef', 4)
print('\n')

print('Test 6')
print('Expected:')
print('a   ')
print('bcde')
print('-' * 20)
print('Actual:')
print_snake('abcde', 4)