#
# Name: Juan Sebastian
# Email ID: jsebastian.2020
#
def mask_out(sentence, banned, substitutes):
    # write your answer between #start and #end
    #start
    string=''
    for char in sentence:
        if char in banned:
            idx=banned.find(char)
            if idx<len(substitutes):
                string+=substitutes[idx]
            else:
                string+=substitutes[0]
        else:
            string+=char
    return string
    #end


print('Test 1')
print('Expected:abcd#')
print('Actual  :' + mask_out('abcde', 'e', '#'))
print()

print('Test 2')
print('Expected:#$solute')
print('Actual  :' + mask_out('absolute', 'ab', '#$'))
print()

print('Test 3')
print('Expected:121hon')
print('Actual  :' + mask_out('python', 'pyt', '12'))
print()





