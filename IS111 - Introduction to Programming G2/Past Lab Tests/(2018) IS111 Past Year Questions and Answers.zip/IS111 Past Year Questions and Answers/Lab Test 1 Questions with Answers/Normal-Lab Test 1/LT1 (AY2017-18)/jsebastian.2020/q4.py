# Name    : Juan Sebastian
# Email ID: jsebastian.2020

# start of answer

def find_tags(sentence):
    ref=[]
    for i in range(len(sentence)):
        if sentence[i]=='[' or sentence[i]==']':
            ref.append(i)
    to_return=''
    count=0
    for i in range(0,len(ref),2):
        start=ref[i]+1
        end=ref[i+1]
        count+=1
        to_return+=str(count)+'-'
        
        to_return+=sentence[start:end]
        to_return+=','
    to_return=to_return.strip(',')
    return to_return

     # added so that this script will run. feel free to modify it

# end of answer


print('Test 1')
actual = find_tags('Coding[Rocks]')
print('Expected:1-Rocks')
print('Actual  :' + actual )
print()

print('Test 2')
actual = find_tags('[apple]and[orange]and[apple]again!')
print('Expected:1-apple,2-orange,3-apple')
print('Actual  :' + actual)
print()

print('Test 3')
actual = find_tags('IAmTaking[mrt]To[SMU]ButThe[nel]IsDelayedAgain.')
print('Expected:1-mrt,2-SMU,3-nel')
print('Actual  :' + actual)
print()

print('Test 4')
actual = find_tags('')
print('Expected:><')
print('Actual  :>' +  actual + '<' )
print()

print('Test 5')
actual = find_tags('apple')
print('Expected:><')
print('Actual  :>' +  actual + '<' )
print()
