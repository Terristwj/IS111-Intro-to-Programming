# Name: Juan Sebastian
# Email ID: jsebastian.2020

def is_compatible(patient_group, donor_group):
    # Replace the code below with your implementation.
    if (patient_group in donor_group) or patient_group=='O':
        return True
    else:
        return False
        
