# Name: Juan Sebastian
# Email ID: jsebastian.2020

def direct_trace(infected,date, history,m,n):
    
    for i in range(len(infected)):
        patient=infected[i]
        d=date[i]
        for tup in history:
            if (tup[0] ==patient or tup[1]==patient) and (tup[2]-d>=-m+n) :
                if tup[0]==patient and tup[1] not in infected:
                    infected.append(tup[1])
                    date.append(tup[2])
                elif tup[1]==patient and tup[0] not in infected:
                    infected.append(tup[0])
                    date.append(tup[2])

def trace_contacts_2(patient, history, m, n):
    # Replace the code below with your implementation.

    infected=[]
    date=[]
    for tup in history:
        if (tup[0] ==patient or tup[1]==patient) and (tup[2]>=-m) :
            if tup[0]==patient and tup[1] not in infected:
                infected.append(tup[1])
                date.append(tup[2])
            elif tup[1]==patient and tup[0] not in infected:
                infected.append(tup[0])
                date.append(tup[2])
    for i in range(len(history)):
        direct_trace(infected,date,history,m,n)

    if patient in infected:
        infected.remove(patient)

    return infected