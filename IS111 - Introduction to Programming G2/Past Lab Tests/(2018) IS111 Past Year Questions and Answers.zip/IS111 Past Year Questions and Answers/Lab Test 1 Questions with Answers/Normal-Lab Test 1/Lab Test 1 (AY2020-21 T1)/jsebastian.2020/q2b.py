# Name: Juan Sebastian
# Email ID: jsebastian.2020

def get_max_of_min(list_of_num_tuples):
    # Replace the code below with your implementation.
    
    # Note: You’re NOT allowed to use either min()or max()to solve this problem.
    
    if len(list_of_num_tuples)==0:
        return None
    
    minimum=[]
    for tup in list_of_num_tuples:
        num=tup[0]
        for n in tup:
            if n<num:
                num=n
        minimum.append(num)
    
    maximum=minimum[0]
    for min_num in minimum:
        if min_num>maximum:
            maximum=min_num
    
    return maximum