# Name: Juan Sebastian
# Email ID: jsebastian.2020

def check_math(list_of_equations):
    # Replace the code below with your implementation.
    
    for equation in list_of_equations:
        first_digit=''
        operator=''
        second_digit=''
        equal=''
        answer=''

        for char in equation:
            if char.isdigit():
                if operator == '':
                    first_digit+=char
                elif operator != '' and equal=='':
                    second_digit+=char
                else:
                    answer+=char
            elif char in ['+','-','*','/','%']:
                operator+=char
            elif char=='=':
                equal='='

        first_digit=int(first_digit)
        second_digit=int(second_digit)
        answer=int(answer)
        
        

        if operator=='+':
            if not(first_digit + second_digit ==answer):
                return False
        elif operator=='-':
            if not (first_digit - second_digit ==answer):
                return False
        elif operator=='*':
            if not (first_digit * second_digit ==answer):
                return False
        elif operator=='//':
            if not (first_digit // second_digit ==answer):
                return False
        else:
            if not (first_digit % second_digit ==answer):
                return False
    return True