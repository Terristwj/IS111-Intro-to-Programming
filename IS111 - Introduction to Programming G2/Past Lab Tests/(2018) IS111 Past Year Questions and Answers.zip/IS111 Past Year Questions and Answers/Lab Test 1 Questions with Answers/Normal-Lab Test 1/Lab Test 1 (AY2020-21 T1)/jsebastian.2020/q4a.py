# Name: Juan Sebastian
# Email ID: jsebastian.2020


def direct_trace(infected,date, history):
    
    for i in range(len(infected)):
        patient=infected[i]
        d=date[i]
        for tup in history:
            if (tup[0] ==patient or tup[1]==patient) and (tup[2]-d>=2) :
                if tup[0]==patient and tup[1] not in infected:
                    infected.append(tup[1])
                    date.append(tup[2])
                elif tup[1]==patient and tup[0] not in infected:
                    infected.append(tup[0])
                    date.append(tup[2])


def trace_contacts(patient, history):
    # Replace the code below with your implementation.
    infected=[]
    date=[]
    for tup in history:
        if (tup[0] ==patient or tup[1]==patient) and (tup[2]>=-5) :
            if tup[0]==patient and tup[1] not in infected:
                infected.append(tup[1])
                date.append(tup[2])
            elif tup[1]==patient and tup[0] not in infected:
                infected.append(tup[0])
                date.append(tup[2])
    for i in range(len(history)):
        direct_trace(infected,date,history)

    if patient in infected:
        infected.remove(patient)

    return infected


