# Name: Juan Sebastian
# Email ID: jsebastian.2020

def get_sum_of_digits(my_str):
    # Replace the code below with your implementation.
    total=0
    for ch in my_str:
        if ch.isdigit():
            total+=int(ch)
    
    return total