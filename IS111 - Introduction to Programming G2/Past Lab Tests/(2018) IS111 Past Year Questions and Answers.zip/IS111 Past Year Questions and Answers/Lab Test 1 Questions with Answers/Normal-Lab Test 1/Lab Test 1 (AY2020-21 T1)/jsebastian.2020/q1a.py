# Name: Juan Sebastian
# Email ID: jsebastian.2020

def get_tank_volume(width, depth, height):
    # Replace the code below with your implementation.
    volume=width*depth*height/1000
    return int(volume)