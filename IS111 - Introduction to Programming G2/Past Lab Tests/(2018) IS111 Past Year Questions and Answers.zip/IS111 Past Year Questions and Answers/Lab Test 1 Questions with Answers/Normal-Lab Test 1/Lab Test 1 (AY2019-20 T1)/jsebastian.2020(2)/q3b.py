# Name: Juan Sebastian
# Email ID: jsebastian.2020

import q3a

def calculate_entrance_fees_2(m, n):
    
    # These variables are defined for you to use.
    ADULT_TICKET = 75
    CHILD_TICKET = 50
    
    PACKAGE_A = 140
    PACKAGE_B = 110
    PACKAGE_C = 200
    
    # Modify the code below.
    pak_num=min(m,n)
    total=q3a.calculate_entrance_fees_1(pak_num)
    left_over_adult=m-pak_num
    left_over_child=n-pak_num
    total+=left_over_adult//2*PACKAGE_A + left_over_adult%2*ADULT_TICKET + left_over_child*CHILD_TICKET
    
    return total
 