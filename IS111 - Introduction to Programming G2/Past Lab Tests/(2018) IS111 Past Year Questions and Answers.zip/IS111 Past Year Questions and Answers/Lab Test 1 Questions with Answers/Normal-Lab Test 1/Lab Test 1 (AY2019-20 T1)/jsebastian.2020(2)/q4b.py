# Name: Juan Sebastian
# Email ID: jsebastian.2020

import itertools
import q4a

def get_seating_arrangement(female_list, male_list, must_list, cannot_list):
    # Modify the code below.
    female_perm = list(itertools.permutations(female_list))
    male_perm = list(itertools.permutations(male_list))
    
    
    for perm_f in female_perm:
        for perm_m in male_perm:
            arrangement=[]
            
            for x in range(len(female_list)):
                arrangement+=[perm_f[x]]+[perm_m[x]]
            
            if q4a.check_seating_arrangement(arrangement, must_list, cannot_list):
                return arrangement



    return None