# Name: Juan Sebastian
# Email ID: jsebastian.2020

def add_even_numbers(str_list):
    # Modify the code below.
    total=0
    for string in str_list:
        for num in string.split('|'):
            if int(num)%2==0:
                total+=int(num)
    
    return total