# Name: Juan Sebastian
# Email ID: jsebastian.2020

def transform(str1, str2):
    # Modify the code below.
    seq=[str1]
    current=seq[-1]
    for i in range(len(str2)):
        
        idx_in_current=current.find(str2[i])
        num_to_swap=idx_in_current-i
    
        for swap in range(num_to_swap):
            idx_in_current=current.find(str2[i])
            current=current[:idx_in_current-1]+current[idx_in_current]+current[idx_in_current-1]+current[idx_in_current+1:]
            seq.append(current)
    return seq
        
    