# Name: Juan Sebastian
# Email ID: jsebastian.2020

def calculate_entrance_fees_1(n):

    # These variables are defined for you to use.
    PACKAGE_B = 110
    PACKAGE_C = 200

    # Modify the code below.
    pak_c=n//2
    pak_b=n%2

    return pak_c*PACKAGE_C +pak_b*PACKAGE_B
        