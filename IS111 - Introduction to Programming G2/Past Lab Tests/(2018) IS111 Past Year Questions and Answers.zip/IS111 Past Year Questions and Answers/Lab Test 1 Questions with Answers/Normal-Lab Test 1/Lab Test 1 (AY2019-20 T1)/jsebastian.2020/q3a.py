# Name: Juan Sebastian
# Email ID: jsebastian.2020

def calculate_entrance_fees_1(n):

    # These variables are defined for you to use.
    PACKAGE_B = 110
    PACKAGE_C = 200

    # Modify the code below.
    total=n//2*PACKAGE_C
    n-=2*(n//2)
    total+=n*PACKAGE_B

    return total
        