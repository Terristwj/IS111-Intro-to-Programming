# Name: Juan Sebastian
# Email ID: jsebastian.2020

def check_sum(n1, n2, n3):
    # Modify the code below.
    if n1+n2==n3 or n1+n3==n2 or n2+n3==n1:
        return True
    else:
        return False


    