# Name: Juan Sebastian
# Email ID: jsebastian.2020

import q3a

def calculate_entrance_fees_2(m, n):
    
    # These variables are defined for you to use.
    ADULT_TICKET = 75
    CHILD_TICKET = 50
    
    PACKAGE_A = 140
    PACKAGE_B = 110
    PACKAGE_C = 200
    
    # Modify the code below.
    grouped_num= min(m,n)
    total=q3a.calculate_entrance_fees_1(grouped_num)
    m-=grouped_num
    n-=grouped_num

    total+=m//2*PACKAGE_A
    m-=2*(m//2)
    total+=m*ADULT_TICKET + n*CHILD_TICKET
    
    return total
 