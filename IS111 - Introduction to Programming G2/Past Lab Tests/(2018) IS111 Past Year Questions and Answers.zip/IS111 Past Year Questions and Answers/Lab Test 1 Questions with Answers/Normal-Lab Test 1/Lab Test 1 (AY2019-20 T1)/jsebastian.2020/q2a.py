# Name: Juan Sebastian
# Email ID: jsebastian.2020

def get_number_of_long_strings(str_list, n):
    # Modify the code below.
    count=0
    for string in str_list:
        if len(string)>n:
            count+=1
    return count