# Name:
# Email ID:

def transform(str1, str2):
    # Modify the code below.
    to_return=[str1]
    current=str1
    for i in range(len(str2)):
        idx1=current.find(str2[i])
        idx2=i
        for x in range(idx1-idx2):
            idx1=current.find(str2[i])
            to_return+=[current[:idx1-1]+current[idx1]+current[idx1-1]+current[idx1+1:]]
            current=to_return[-1]


    return to_return
        
    