# Name: Juan Sebastian
# Email ID: jsebastian.2020

def add_even_numbers(str_list):
    # Modify the code below.
    new_list=[]
    total=0
    for string in str_list:
        new_list+=string.split('|')
    for num in new_list:
        if int(num)%2==0:
            total+=int(num)
    return total
            