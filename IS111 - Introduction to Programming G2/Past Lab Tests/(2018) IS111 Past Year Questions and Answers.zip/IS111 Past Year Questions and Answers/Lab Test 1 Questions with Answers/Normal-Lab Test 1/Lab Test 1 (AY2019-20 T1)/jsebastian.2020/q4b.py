# Name: Juan Sebastian
# Email ID: jsebastian.2020

import itertools
import q4a

def get_seating_arrangement(female_list, male_list, must_list, cannot_list):
    # Modify the code below.
    my_permutationsf = list(itertools.permutations(female_list))
    my_permutationsm = list(itertools.permutations(male_list))
    
    for fperm in my_permutationsf:
        fperm=list(fperm)
        for mperm in my_permutationsm:
            mperm=list(mperm)
            arrangement=[]
            for i in range(len(mperm)):
                arrangement+=[fperm[i]]+[mperm[i]]
            
            if q4a.check_seating_arrangement(arrangement, must_list, cannot_list):
                return list(arrangement)
                
    return None

    