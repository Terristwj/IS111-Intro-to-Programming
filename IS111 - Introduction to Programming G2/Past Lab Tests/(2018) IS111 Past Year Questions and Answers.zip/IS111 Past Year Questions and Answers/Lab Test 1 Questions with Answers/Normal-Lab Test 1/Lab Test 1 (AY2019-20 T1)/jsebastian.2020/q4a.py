# Name: Juan Sebastian
# Email ID: jsebastian.2020

def check_seating_arrangement(arrangement, must_list, cannot_list):
    # Modify the code below.
    for pair in must_list:
        idx=arrangement.index(pair[0])
        idx2=arrangement.index(pair[1])
        if not(arrangement[idx-1]==pair[1] or arrangement[idx2-1]==pair[0]):
            return False

    for pair in cannot_list:
        idx=arrangement.index(pair[0])
        idx2=arrangement.index(pair[1])
        if arrangement[idx-1]==pair[1] or arrangement[idx2-1]==pair[0]:
            return False
    return True
 