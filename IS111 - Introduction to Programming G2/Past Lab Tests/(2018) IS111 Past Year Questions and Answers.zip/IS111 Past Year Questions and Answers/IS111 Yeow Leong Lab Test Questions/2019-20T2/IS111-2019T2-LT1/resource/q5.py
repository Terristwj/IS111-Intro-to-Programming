#
# Name:
# Email ID:
#

if __name__ == "__main__":
    n = 0
    
    n += 1
    print(f'Test {n}')
    print('Expected:')
    print('a')
    print('Actual  :')
    print_diamond(1, 'a')
    print()

    n += 1
    print(f'Test {n}')
    print('Expected:')
    print('#b#')
    print('bab')
    print('#b#')
    print('Actual  :')
    print_diamond(2, 'a')
    print()

    n += 1
    print(f'Test {n}')
    print('Expected:')
    print('##c##')
    print('#cbc#')
    print('cbabc')
    print('#cbc#')
    print('##c##')
    print('Actual  :')
    print_diamond(3, 'a')
    print()

    n += 1
    print(f'Test {n}')
    print('Expected:')
    print('####C####')
    print('###CBC###')
    print('##CBABC##')
    print('#CBAZABC#')
    print('CBAZYZABC')
    print('#CBAZABC#')
    print('##CBABC##')
    print('###CBC###')
    print('####C####')
    print('Actual  :')
    print_diamond(5, 'Y')
    print()