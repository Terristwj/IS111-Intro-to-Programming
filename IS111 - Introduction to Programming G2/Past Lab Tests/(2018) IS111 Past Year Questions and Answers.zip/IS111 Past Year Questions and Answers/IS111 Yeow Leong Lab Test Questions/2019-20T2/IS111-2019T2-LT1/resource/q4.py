#
# Name    : 
# Email ID: 
#


if __name__ == "__main__":
    n = 0

    # 1, 11, 21, 1211, 111221, 312211, 13112221, 1113213211, …
    n += 1
    print(f'Test {n}')
    result = get_term(1)
    print('Expected:1')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = isinstance(get_term(1), int)
    print('Expected:True')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = get_term(2)
    print('Expected:11')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = get_term(3)
    print('Expected:21')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = get_term(4)
    print('Expected:1211')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = get_term(5)
    print('Expected:111221')
    print(f'Actual  :{result}')
    print()