#
# Name    : 
# Email ID: 
#

if __name__ == "__main__":
    n = 0
    
    n += 1
    print(f'Test {n}')
    result = get_longest('aabccaaa')
    print('Expected:a')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = get_longest('ddaabccaa')
    print('Expected:dac')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = get_longest('cbbccccdddd')
    print('Expected:cd')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = get_longest('bbbbccddddbbbb')
    print('Expected:bd')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = get_longest('')
    print('Expected:><')
    print(f'Actual  :>{result}<')
    print()

    n += 1
    print(f'Test {n}')
    result = get_longest('a')
    print('Expected:a')
    print(f'Actual  :{result}')
    print()
