#
# Name    : 
# Email ID: 
#

def add(num):
    pass


if __name__ == "__main__":
    n = 0

    n += 1
    print(f'Test {n}')
    result = add(123)
    print('Expected:234')
    print(f'Actual  :{result}')
    print()


    n += 1
    print(f'Test {n}')
    result = add(907)
    print('Expected:1018')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = add(-907)
    print('Expected:-818')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = add(-1007)
    print('Expected:118')
    print(f'Actual  :{result}')
    print()

    n += 1
    print(f'Test {n}')
    result = add(-1)
    print('Expected:0')
    print(f'Actual  :{result}')
    print()
