#
# Name    :
# Email ID:
#


def encode(message, num_rows):
    return None


if __name__ == "__main__":
    num = 0

    num += 1
    print(f'Test {num}')
    print('Expected:#ODYEHTNENJETHESTARSSYTTERTHAWIEBTSUMUOEBYAHALOUS')
    result = encode(
        "The stars must be jealous. You shine way better than they do!", 7)
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    print('Expected:DOEHAHETBYENSUSUAEBTMSTSTHEARUSEJLOYOHIWAETRTNTY')
    result = encode(
        "The stars must be jealous. You shine way better than they do!", 2)
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    print('Expected:#######ODYEHOYTHESTARSMUSTBETTERTHANTUSUOLAEJEBYAWENIHS')
    result = encode(
        "The stars must be jealous. You shine way better than they do!", 11)
    print(f'Actual  :{result}')
    print()

    num += 1
    print(f'Test {num}')
    print('Expected:EENDTNHSIS111LGHTOOAEWLO')
    result = encode("IS111. We shall go on to the end.", 4)
    print(f'Actual  :{result}')
    print()
