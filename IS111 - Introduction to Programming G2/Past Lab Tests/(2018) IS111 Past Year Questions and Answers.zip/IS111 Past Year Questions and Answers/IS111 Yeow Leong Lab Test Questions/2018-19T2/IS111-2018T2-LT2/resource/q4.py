# Name:
# Email ID:

def get_total_time(name, date, timing_file):
    return None



if __name__ == '__main__':
    print('Test 1')
    print('Expected:True')
    result = get_total_time('apple', '01/03/2019', 'timings.txt')
    print('Actual  :' + str(isinstance(result, int)))
    print()

    print('Test 2')
    print('Expected:30')
    result = get_total_time('apple', '01/03/2019', 'timings.txt')
    print('Actual  :' + str(result))
    print()

    print('Test 3')
    print('Expected:90')
    result = get_total_time('apple', '24/3/2019', 'timings.txt')
    print('Actual  :' + str(result))
    print()

    print('Test 4')
    print('Expected:3')
    result = get_total_time('orange', '24/03/2019', 'timings.txt')
    print('Actual  :' + str(result))
    print()

    print('Test 5')
    print('Expected:480')
    result = get_total_time('orange', '25/3/2019', 'timings.txt')
    print('Actual  :' + str(result))
    print()

    print('Test 6')
    print('Expected:577')
    result = get_total_time('pear', '24/03/2019', 'timings.txt')
    print('Actual  :' + str(result))
    print()

    print('Test 7')
    print('Expected:0')
    result = get_total_time('durian', '25/3/2019', 'timings.txt')
    print('Actual  :' + str(result))
    print()

    print('Test 8')
    print('Expected:0')
    result = get_total_time('orange', '27/3/2019', 'timings.txt')
    print('Actual  :' + str(result))
    print()
