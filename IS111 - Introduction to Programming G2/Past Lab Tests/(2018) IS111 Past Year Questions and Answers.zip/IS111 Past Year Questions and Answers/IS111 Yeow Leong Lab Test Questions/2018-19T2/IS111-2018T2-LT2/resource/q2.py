# Name:
# Email ID:


def get_titles(title_list, search_word):
    return None


if __name__ == '__main__':
    print('Test 1')
    result = get_titles(['Learning Python',
                         'Python Cookbook',
                         'Think Python',
                         'programming in Python 3'], 'Python')
    print("Expected:True")
    print('Actual  :' + str(isinstance(result, list)))
    print()

    print('Test 2')
    result = get_titles(['Learning Python',
                         'Python Cookbook',
                         'Think Python',
                         'programming in Python 3'], 'Python')
    print("Expected:True")
    print('Actual  :' + str(isinstance(result != None and result[0], str)))
    print()

    print('Test 3')
    result = get_titles(['Learning Python',
                         'Python Cookbook',
                         'Think Python',
                         'programming in Python 3'], 'Python')
    print(
        "Expected:['Learning Python', 'Python Cookbook', 'Think Python', 'programming in Python 3']")
    print('Actual  :' + str(result))
    print()

    print('Test 4')
    result = get_titles(['Head First Java', 'Effective Java'], 'JAVA')
    print("Expected:['Head First Java', 'Effective Java']")
    print('Actual  :' + str(result))
    print()

    print('Test 5')
    result = get_titles(['To Kill a Mockingbird',
                         'The Soul Bird',
                         'Spotting Birds',
                         'The Wind-Up Bird Chronicle'], 'bird')
    print("Expected:['The Soul Bird', 'The Wind-Up Bird Chronicle']")
    print('Actual  :' + str(result))
    print()

    print('Test 6')
    result = get_titles([], 'fluff')
    print("Expected:[]")
    print('Actual  :' + str(result))
