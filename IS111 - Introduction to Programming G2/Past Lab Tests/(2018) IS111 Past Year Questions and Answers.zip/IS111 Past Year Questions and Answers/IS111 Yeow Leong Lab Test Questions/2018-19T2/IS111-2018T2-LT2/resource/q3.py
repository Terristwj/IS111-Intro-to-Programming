# Name:
# Email ID:


def get_prime_factors(number):
    return None


if __name__ == '__main__':
    result = get_prime_factors(60)
    print('Test 1')
    print('Expected:True')
    print('Actual  :' + str(isinstance(result, list)))
    print()

    result = get_prime_factors(60)
    print('Test 2')
    print('Expected:True')
    print('Actual  :' + str(isinstance(result != None and result[0], int)))
    print()

    result = get_prime_factors(60)
    print('Test 3')
    print('Expected:[2, 2, 3, 5]')
    print('Actual  :' + str(result))
    print()

    result = get_prime_factors(7)
    print('Test 4')
    print('Expected:[7]')
    print('Actual  :' + str(result))
    print()

    result = get_prime_factors(123456)
    print('Test 5')
    print('Expected:[2, 2, 2, 2, 2, 2, 3, 643]')
    print('Actual  :' + str(result))
    print()
    
    result = get_prime_factors(50)
    print('Test 6')
    print('Expected:[2, 5, 5]')
    print('Actual  :' + str(result))
    print()
