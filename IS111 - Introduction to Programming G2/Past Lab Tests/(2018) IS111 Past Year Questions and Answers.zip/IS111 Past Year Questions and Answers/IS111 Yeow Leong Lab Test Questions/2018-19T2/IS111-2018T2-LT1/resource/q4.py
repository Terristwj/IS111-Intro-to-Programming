# Name: 
# Email ID: 

# Start your code here

# End your code here 
# Do not modify the code below this line

if __name__ == '__main__':
    print('Test 1')
    print('Expected:')
    print('klab')
    print('j  c')
    print('i  d')
    print('hgfe')
    print('True')
    print()
    print('Actual:')
    result = print_rectangle('abcdefghijkl', 4, 4)
    print (result)
    print('-' * 10)
    print()

    print('Test 2')
    print('Expected:')
    print('STABC')
    print('R   D')
    print('Q   E')
    print('P   F')
    print('O   G')
    print('N   H')
    print('MLKJI')
    print('True')
    print()
    print('Actual:')
    result = print_rectangle('ABCDEFGHIJKLMNOPQRST', 7, 5)
    print (result)
    print('-' * 10)
    print()

    print('Test 3')
    print('Expected:False')
    print()
    result = print_rectangle('abcdefghij', 4, 4)
    print ('Actual  :' + str(result))
    print('-' * 10)
    print()


    print('Test 4')
    print('Expected')
    print('69')
    print('78')
    print('True')
    print ('Actual  :')
    result = print_rectangle('987654321', 2, 2)
    print(str(result))
    print('-' * 10)
    print()


    print('Test 5')
    print('Expected')
    print('ianapp')
    print('r    l')
    print('u    e')
    print('d     ')
    print('*    k')
    print('r    i')
    print('aep iw')
    print('True')
    print ('Actual  :')
    result = print_rectangle('apple kiwi pear*durian', 7, 6)
    print(str(result))
    print()