# Name: 
# Email ID: 

# Start your code here

# End your code here 
# Do not modify the code below this line

if __name__ == '__main__':
    print('Test 1')
    print('Expected:0')
    result = get_golden_level('98133629')
    print('Actual  :' + str(result))
    print()

    print('Test 2')
    print('Expected:3')
    result = get_golden_level('91112123')
    print('Actual  :' + str(result))
    print()

    print('Test 3')
    print('Expected:1')
    result = get_golden_level('91853456')
    print('Actual  :' + str(result))
    print()

    print('Test 4')
    print('Expected:2')
    result = get_golden_level('93456345')
    print('Actual  :' + str(result))
    print()

    print('Test 5')
    print('Expected:1')
    result = get_golden_level('63411113')
    print('Actual  :' + str(result))
    print()



