# Name: 
# Email ID: 

def alternate_plus_minus(num):
    return 0

if __name__ == '__main__':
    print('Test 1')
    result = alternate_plus_minus(8193)
    print('Expected:13')
    print('Actual  :' + str(result))
    print()

    print('Test 2')
    result = alternate_plus_minus(315)
    print('Expected:7')
    print('Actual  :' + str(result))
    print()

    print('Test 3')
    result = alternate_plus_minus(-8193)
    print('Expected:-3')
    print('Actual  :' + str(result))
    print()

    print('Test 4')
    result = alternate_plus_minus(-315)
    print('Expected:1')
    print('Actual  :' + str(result))
    print()

    print('Test 5')
    result = alternate_plus_minus(0)
    print('Expected:0')
    print('Actual  :' + str(result))
    print()

