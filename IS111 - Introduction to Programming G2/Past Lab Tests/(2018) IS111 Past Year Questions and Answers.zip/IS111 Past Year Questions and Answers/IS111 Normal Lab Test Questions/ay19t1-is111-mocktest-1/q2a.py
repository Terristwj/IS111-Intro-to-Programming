def get_order_amount(order_string,price_list):
    total_price = 0
    for item in price_list:
        x = order_string.split(',')
        for order in x:
            if item[0] in order:
                amount = order[-1]
                total_price = float(amount) * item[1] + total_price
    return total_price

#print(get_order_amount("Lime Green Tea -2, Black Tea - 3", [("Lime Green Tea", 3.60), ("Black Tea", 3.10)]))

get_order_amount("Grapefruit Yakult -5, Black Tea - 3, Lime Green Tea-1", [("Lime Green Tea", 3.60), ("Black Tea", 3.10), ("Grapefruit Yakult", 7.40)])