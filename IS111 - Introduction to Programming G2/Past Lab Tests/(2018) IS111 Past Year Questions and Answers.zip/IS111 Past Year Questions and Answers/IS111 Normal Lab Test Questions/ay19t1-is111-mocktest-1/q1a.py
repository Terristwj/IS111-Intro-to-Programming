def get_hashtags(post_list):
    y = []
    for string in post_list:
        x = string.split(' ')
        for word in x:
            if word[0] == '#':
                y.append(word)
    print(y)
    return y


r = ["SMU #SIS congratulates the #Classof2019 graduates for their accomplishments", "#Computing at #SIS"]
t = ["A balanced diet means a cupcake in each hand.", "I'm never wrong. Just different levels of right."]
get_hashtags(t)

