from q2a import get_order_amount

def get_total_revenue(order_list, price_list):
    revenue = 0
    for order in order_list:
        rev_per_cus = get_order_amount(order,price_list)
        revenue = rev_per_cus + revenue
    print("{:.2f}".format(revenue))


get_total_revenue(["Grapefruit Yakult -5, Black Tea - 3, Lime Green Tea-1", "Lime Green Tea -2, Black Tea - 3"], [("Lime Green Tea", 3.60), ("Black Tea", 3.10), ("Grapefruit Yakult", 7.40)])