from q1a import get_hashtags

def count_hashtags(hashtag_list):
    x = []
    final_list = []
    lis = get_hashtags(hashtag_list)
    for item in lis:
        lower_item = item.lower()
        if lower_item not in x:
            x.append(lower_item)
    for q in x:
        count = 0
        for item in lis:
            if q == item.lower():
                count = count + 1
        tup = (q, count)
        final_list.append(tup)
    print(final_list) 



r = ["#smukitty #smucat #Meow If you see me around school please approach me slowly cos I am very shy and get scared easily", "The Official Instagram for Grumpy Cat. #TeamGrumpy #GrumpyCat", "#Meow Definitely not a #grumpycat"]

count_hashtags(r)