#
# Name: 
# Email ID: 
#

def get_hashtags(post_list):
    '''
    This function returns the list of hashtagged words in post_list. 
    A hashtagged word is a word that begins with '#'  
    '''
    # write your answer between #start and #end
    #start
    return []
    #end 