#
# Name: 
# Email ID: 
#

import q1a 

def count_hashtags(hashtag_list):
    '''
    The function should return a list of tuples, where each tuple has two elements – one containing the unique hashtagged word in lowercase and the other containing the number of times that this unique hashtagged word has appeared in the given hashtag_list. 
    '''
    # write your answer between #start and #end
    #start
    return []
    #end 