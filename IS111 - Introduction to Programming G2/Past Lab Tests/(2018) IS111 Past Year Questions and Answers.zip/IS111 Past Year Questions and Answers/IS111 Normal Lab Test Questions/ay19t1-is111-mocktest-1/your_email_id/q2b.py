#
# Name: 
# Email ID: 
#

import q2a

def get_revenue(order_list, price_list):
    '''
    This function computes the total revenue collected from the sales
    of the bubble tea, and returns this total revenue.  
    '''
    # write your answer between #start and #end
    #start
    return 0
    #end 