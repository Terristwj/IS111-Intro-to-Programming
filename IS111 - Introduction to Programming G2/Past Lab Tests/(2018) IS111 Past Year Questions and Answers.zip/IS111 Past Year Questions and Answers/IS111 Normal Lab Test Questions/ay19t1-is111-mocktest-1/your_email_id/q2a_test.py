from q2a import get_order_amount

########## TEST CASE 1 ##########
print('Test 1')
print('Expected:', 16.5)
result = get_order_amount("Lime Green Tea -2, Black Tea - 3", [("Lime Green Tea", 3.60), ("Black Tea", 3.10)]) 
print('Actual:  ', result)
print()

########## TEST CASE 2 ##########
print('Test 2')
print('Expected:', 0)
result = get_order_amount("", [("Lime Green Tea", 3.60), ("Black Tea", 3.10)]) 
print('Actual:  ', result)
print()

########## TEST CASE 3 ##########
print('Test 3')
print('Expected:', 49.9)
result = get_order_amount("Grapefruit Yakult -5, Black Tea - 3, Lime Green Tea-1", [("Lime Green Tea", 3.60), ("Black Tea", 3.10), ("Grapefruit Yakult", 7.40)])
print('Actual:  ', result)
print()
