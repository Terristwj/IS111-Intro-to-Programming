#
# Name: 
# Email ID: 
#

import q2a

def get_revenue(order_list, price_list):
    '''
    This function computes the total revenue collected from the sales
    of the bubble tea, and returns this total revenue.  
    '''
    # write your answer between #start and #end
    #start
    total = 0
    for order in order_list: 
        total += q2a.get_order_amount(order, price_list)
    return round(total,2)
    #end 