#
# Name: 
# Email ID: 
#

def get_hashtags(post_list):
    '''
    This function returns the list of hashtagged words in post_list. 
    A hashtagged word is a word that begins with '#'  
    '''
    # write your answer between #start and #end
    #start
    hashtag_list = []
    for post in post_list:
        splitted = post.split()
        for word in splitted:
            if word[0] == '#':
                hashtag_list.append(word)
    return hashtag_list
    #end 