#
# Name: 
# Email ID: 
#

import q1a 

def count_hashtags(hashtag_list):
    '''
    The function should return a list of tuples, where each tuple has two elements – one containing the unique hashtagged word in lowercase and the other containing the number of times that this unique hashtagged word has appeared in the given hashtag_list. 
    '''
    # write your answer between #start and #end
    #start
    x = []
    hashtags = q1a.get_hashtags(post_list)
    for i in range(len(hashtags)):
        hashtags[i] = hashtags[i].lower()
    for i in hashtags:
        
        tmp = (i, hashtags.count(i))
        if tmp not in x:
            x.append(tmp)
    return x        
    #end 