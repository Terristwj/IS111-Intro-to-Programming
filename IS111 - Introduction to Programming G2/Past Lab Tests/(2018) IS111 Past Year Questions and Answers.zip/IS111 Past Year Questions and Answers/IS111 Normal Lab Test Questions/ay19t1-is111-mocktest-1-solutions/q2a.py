#
# Name: 
# Email ID: 
#

def get_order_amount(order_string, price_list):
    '''
    This function returns the order amount, based on the items in the 
    order string, and the price of each item in the price list. 
    '''
    # write your answer between #start and #end
    #start
    total = 0
    each_item_tuple = order_string.split(',')
    for x in each_item_tuple:
        xx = x.split('-')
        for price in price_list:
            if price[0] == xx[0].strip():
                total += price[1]  * int(xx[1].strip())
    return total 
    #end 