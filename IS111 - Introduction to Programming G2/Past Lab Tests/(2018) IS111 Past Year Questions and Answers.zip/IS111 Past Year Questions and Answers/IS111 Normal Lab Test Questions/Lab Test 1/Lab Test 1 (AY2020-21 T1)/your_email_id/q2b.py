# Name:
# Email ID:

def get_max_of_min(list_of_num_tuples):
    # Replace the code below with your implementation.
    
    # Note: You’re NOT allowed to use either min()or max()to solve this problem.
    
    return None