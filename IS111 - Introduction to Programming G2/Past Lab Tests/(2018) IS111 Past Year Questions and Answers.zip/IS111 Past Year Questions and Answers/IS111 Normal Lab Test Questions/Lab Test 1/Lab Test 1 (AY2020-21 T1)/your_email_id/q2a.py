# Name:
# Email ID:

def get_sum_of_digits(my_str):
    # Replace the code below with your implementation.
    return None