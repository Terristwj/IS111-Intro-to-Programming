# Name:
# Email ID:

def is_compatible(patient_group, donor_group):
    # Replace the code below with your implementation.
    return None