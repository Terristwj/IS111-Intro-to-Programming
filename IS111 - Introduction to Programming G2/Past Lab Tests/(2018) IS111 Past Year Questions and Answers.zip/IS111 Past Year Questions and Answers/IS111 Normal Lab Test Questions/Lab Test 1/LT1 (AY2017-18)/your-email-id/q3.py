# Name    :
# Email ID:

# start of answer

def reverse_num(number):
    return None # added so that this script will run. feel free to modify it

# end of answer

print("Test 1: Test that the return value is an int value")
print("Expected:True")
print("Actual  :" + str(isinstance(reverse_num(123), int)))
print()

print("Test 2")
print("Expected:2017")
print("Actual  :" + str(reverse_num(7102)))
print()

print("Test 3")
print("Expected:32")
print("Actual  :" + str(reverse_num(230)))
print()

print("Test 4")
print("Expected:0")
print("Actual  :" + str(reverse_num(0)))
print()

print("Test 5")
print("Expected:-21")
print("Actual  :" + str(reverse_num(-12)))
print()

