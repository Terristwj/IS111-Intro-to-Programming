# Name:
# Email ID:

def trace_contacts(patient, history):
    # Replace the code below with your implementation.
    return None