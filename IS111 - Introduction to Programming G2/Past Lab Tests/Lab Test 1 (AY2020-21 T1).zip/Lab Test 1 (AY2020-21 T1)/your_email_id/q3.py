# Name:
# Email ID:

def check_math(list_of_equations):
    # Replace the code below with your implementation.
    return None