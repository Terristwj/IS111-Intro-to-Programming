# YOUR CODE GOES HERE
# Copy and paste your code from q1.py over here
