##
# Author : Stephen Pang
# Created : August 19, 2021
# Last Updated : August 19, 2021
#
# Copyright (C) 2021 Stephen Pang
##

import random

def shoot_shurikens(num):
    # YOUR CODE GOES HERE
    return None


# DO NOT MODIFY THE CODE BELOW:
print('----Test Case 1----')
result = shoot_shurikens(3)

print('----Test Case 2----')
result = shoot_shurikens(12)
