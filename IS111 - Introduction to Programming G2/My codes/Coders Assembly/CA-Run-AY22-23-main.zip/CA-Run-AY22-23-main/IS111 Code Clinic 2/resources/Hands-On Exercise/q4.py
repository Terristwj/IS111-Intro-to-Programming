def get_alpha_num(string):
    # YOUR CODE GOES HERE
    return ()




    