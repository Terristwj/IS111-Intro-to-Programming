# PART A 

def banned_words(banned_string,word_list):
    # Add code here
    return None

# PART B
# Add your Program Code Here



# PART C
def banned_words2(banned_list,word_list):
    # Add code here
    return None

# PART C Program
# Add your program code here















