def unique_sort(sentence):
    ## YOUR CODE GOES BELOW ##
    return None