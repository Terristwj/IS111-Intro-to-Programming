##
# This question was adapted from SPM Programming Exercise, Roman Numerals
# Author : Stephen Pang Qing Yang
# Created : August 30, 2021
# Last Updated : August 30, 2021
#
# Copyright (C) 2021 Stephen Pang Qing Yang
##

def get_factorial(n):
    # YOUR CODE GOES HERE
    # Make sure you use WHILE LOOP to solve this question
    total = 1
    while n!=1:
        total *= n
        n -= 1
    return total


# DO NOT MODIFY THE CODE BELOW
print('----Test Case 1----')
result = get_factorial(5)
print("Expected: 120" )
print("Actual:   " + str(result))
print()
print('----Test Case 2----')
result = get_factorial(8)
print("Expected: 40320" )
print("Actual:   " + str(result))
print()
print('----Test Case 3----')
result = get_factorial(4)
print("Expected: 24" )
print("Actual:   " + str(result))
print()
print('----Test Case 4----')
result = get_factorial(10)
print("Expected: 3628800" )
print("Actual:   " + str(result))
print()