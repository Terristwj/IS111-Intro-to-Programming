weapons_dict = {
    "kunai": 5,
    "shuriken": 20,
    "hammer": 2,
    "spiked ball": 24,
    "metal spear": 4,
    "senbon": 84,
    "six-edged disc": 42,
    "crossbow": 1,
    "dual-swords": 3,
    "kunai chains": 2,
    "iron fan": 5,
    "scythe": 9,
    "scimitar": 12
}

# YOUR PROGRAM CODE GOES HERE