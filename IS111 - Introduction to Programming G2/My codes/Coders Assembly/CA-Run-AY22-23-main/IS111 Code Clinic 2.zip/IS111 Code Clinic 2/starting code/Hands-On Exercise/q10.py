def surround(field_list):
    # YOUR CODE GOES HERE
    return None