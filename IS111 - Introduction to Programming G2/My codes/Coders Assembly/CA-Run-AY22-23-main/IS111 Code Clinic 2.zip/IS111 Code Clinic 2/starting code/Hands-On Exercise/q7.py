def add_receipient(email, receipient_list):
    # Your code goes here (There won't be a function test because it is REALLY simple)
    return None

## PART B Code Goes HERE