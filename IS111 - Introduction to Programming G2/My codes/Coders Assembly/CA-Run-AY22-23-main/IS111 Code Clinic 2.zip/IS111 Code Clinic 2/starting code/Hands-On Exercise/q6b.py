def binary_to_music2(binary_code):
    ## YOUR CODE GOES HERE ##
    return None