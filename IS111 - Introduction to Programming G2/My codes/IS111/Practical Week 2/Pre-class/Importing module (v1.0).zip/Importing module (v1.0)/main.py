

name = input('Enter your name :')
greet.say_hello(name)
greet.say_bye(name)



