# Name:
# Email ID:

def get_max(num_str):
    # This function returns the maximum number (as a str) found in the given
    # group of numbers.
    # If the given num_str is empty, the function returns 'NA'.
    if num_str == '':
        return 'NA'
        
    nums = num_str.split(' ')
    max_num = int(nums[0])
    for num in nums:
        num = int(num)
        if num > max_num:
            max_num = num
    return str(max_num)

def process_numbers(input_filename, output_filename):
    with open(input_filename, 'r') as input_file:
        with open(output_filename, 'w') as output_file:
        
            for line in input_file:
                line = line.rstrip('\n')
                
                # After the split, groups is a list of strings, where each
                # string contains several numbers.
                groups = line.split('*')
                
                num_groups = len(groups)
                output_file.write(str(num_groups) + ': ')            
                
                # max_str will contain the maximum numbers from different 
                # groups, separated by '*'.
                max_str = ''
                for group in groups:
                    # group is a string containing multiple numbers.
                    # E.g., '3 2 34'.
                    # We call the function get_max() defined above to obtain
                    # the maximum number in group.
                    max_num = get_max(group)
                    max_str += max_num + '*'
                   
                # Remove the extra '*' in the end.
                max_str = max_str.rstrip('*')
                
                
                output_file.write(max_str + '\n')
    