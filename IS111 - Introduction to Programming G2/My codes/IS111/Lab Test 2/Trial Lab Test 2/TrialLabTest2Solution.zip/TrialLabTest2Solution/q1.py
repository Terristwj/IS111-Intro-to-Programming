def get_avg(temp_list):
    # This function returns the average temperature 
    # value of the given list of temperature readings.
    temp_sum = 0.0
    for temp in temp_list:
        temp_sum += temp
        
    avg_temp = temp_sum / len(temp_list)
    return avg_temp

def has_fever(temp_list):
    avg_temp = get_avg(temp_list)
    if avg_temp > 37.5:
        return True
    else:
        return False

def get_ppl_with_fever(ppl_list):

    result_list = []
    for person_info in ppl_list:
        name = person_info[0]
        temp_list = person_info[1]

        if has_fever(temp_list):
            result_list.append(name)

    return result_list
