# Name:
# Email ID:
def extract_school_year(email):
    # This function returns a string that contains the school name
    # and the enrolment year found in the email address.
    # If the email doesn't have a year or doesn't have a school name,
    # then the function returns None.

    (email_id, domain) = email.split('@')
    
    email_id_parts = email_id.split('.')
    last_part = email_id_parts[-1]
    
    # If the last part of the email ID contains a digit, then it must be the year.
    if last_part[0] not in '0123456789':
        return None
        
    year = last_part
    
    domain_parts = domain.split('.')
    first_part = domain_parts[0]
    
    # If the first part of domain is 'smu', then there's no school name in the 
    # email address.
    if first_part == 'smu':
        return None
    
    school = first_part
    
    return school + '-' + year

def create_email_dict(email_list):

    email_dict = {}
    
    for email in email_list:
        
        school_year = extract_school_year(email)
        if school_year != None:
            if school_year in email_dict:
                email_dict[school_year].append(email)
            else:
                email_dict[school_year] = [email]
    
    return email_dict
    
