def get_index_of_longer_string(a_str, a_sorted_list):
    # This function looks for the first string
    # inside a_sorted_list whose length is larger than
    # the length of a_str.
    # If no such string is found, -1 is returned.
    for index in range(0, len(a_sorted_list)):
        if len(a_sorted_list[index]) > len(a_str):
            return index
    return -1

def sort_strings(str_list):

    sorted_list = []
    
    for my_str in str_list:
        # Find the index of the first string in sorted_list that is longer than my_str.
        index = get_index_of_longer_string(my_str, sorted_list)
        if index == -1:
            sorted_list.append(my_str)
        else:
            # insert my_str to be between sorted_list[index-1] and sorted_list[index]
            sorted_list = sorted_list[:index] + [my_str] + sorted_list[index:]
    
    return sorted_list
