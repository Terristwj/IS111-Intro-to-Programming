def is_pangram(sentence):
    alphabet = 'abcdefghijklmnopqrstuvwxyz'
    sentence = sentence.lower()
    for ch in alphabet:
        if ch not in sentence:
            return False
    return True