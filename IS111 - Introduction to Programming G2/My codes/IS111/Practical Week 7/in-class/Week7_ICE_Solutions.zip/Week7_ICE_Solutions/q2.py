def print_triangle(ch, num_rows):
    for row in range(1, num_rows+1):
        
        # Figure out the number of spaces to be printed in the current row.
        num_spaces = num_rows - row
        
        # Figure out the number of ch to be printed in the current row.
        num_of_ch = 2 * row - 1
        
        # Print the spaces and the ch
        print(' ' * num_spaces + ch * num_of_ch) 


def print_frame(ch, num_rows, num_cols):

    # Step 1: print the first row
    print(ch * num_cols)
    
    # Step 2: print rows in the middle
    for i in range(num_rows - 2):
        
        # Figure out the number of spaces between the characters
        num_spaces = num_cols - 2
        
        # Print the characters and the spaces
        print(ch + ' ' * num_spaces + ch)
        
    # Step 3: print last row
    print(ch * num_cols)

def print_diamond(ch, n):

    # Step 1: print the very first row, which has only a single ch
    # Step 1.1: figure out how many spaces to print
    num_spaces = n - 1
    # Step 1.2: print the spaces followed by ch
    print(' ' * num_spaces + ch)

    # Step 2: print the top half of the diamond, excluding the first row but including the middle row
    # We can refer to the code that prints triangles in Part (a) for help.
    for row in range(2, n + 1):
        # figure out the number of spaces on the left of the current row
        num_left_spaces = n - row
        # figure out the number of spaces in the middle of the current row
        num_middle_spaces = 2 * row - 3
        # print the current row
        print(' ' * num_left_spaces + ch + ' ' * num_middle_spaces + ch)
    
    # Step 3: print the bottom half of the diamond, excluding the middle row and the last row
    # We can think of this as a trangle turned upside down.
    for row in range(n - 1, 1, -1):
        # figure out the number of spaces on the left of the current row
        num_left_spaces = n - row
        # figure out the number of spaces in the middle of the current row
        num_middle_spaces = 2 * row - 3
        # print the current row
        print(' ' * num_left_spaces + ch + ' ' * num_middle_spaces + ch)
        
    # Step 4: print the last row, which has only a single ch
    # Since the last row is the same as the first row, we can reuse the code.
    num_spaces = n - 1
    print(' ' * num_spaces + ch)    
    