# Name: Tan Wei Jun, Terris
# Email ID: terris.tan.2022@scis.smu.edu.sg

from q4a import is_overlapping
def find_overlapping_pairs(rect_list):
    # print(rect_list)
    overlap_list = []
    for rect1 in rect_list:
        for rect2 in rect_list:
            if rect1 != rect2:
                if is_overlapping(rect1, rect2):
                    if overlap_list:
                        in_list = False
                        for item in overlap_list:
                            # print(rect1[0], rect2[0])
                            # print(item)
                            if (rect1[0] == item[0] and rect2[0] == item[1]) or (rect2[0] == item[0] and rect1[0] == item[1]):
                                # print("append")
                                # print(rect1[0], rect2[0])
                                # print(item)
                                in_list = True
                            # if (rect1[0] != item[0] and rect2[0] != item[1]) or (rect2[0] != item[0] and rect1[0] != item[1]):
                                # overlap_list.append((rect1[0], rect2[0]))
                        if not in_list:
                            overlap_list.append((rect1[0], rect2[0]))
                    else:
                        overlap_list.append((rect1[0], rect2[0]))
    # Replace the code below with your implementation.
    return overlap_list