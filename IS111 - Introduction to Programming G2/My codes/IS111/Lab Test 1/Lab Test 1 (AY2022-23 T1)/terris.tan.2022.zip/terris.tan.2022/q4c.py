# Name: Tan Wei Jun, Terris
# Email ID: terris.tan.2022@scis.smu.edu.sg

def find_overlap_size(rect_1, rect_2):

    # Replace the code below with your implementation.
    return 0