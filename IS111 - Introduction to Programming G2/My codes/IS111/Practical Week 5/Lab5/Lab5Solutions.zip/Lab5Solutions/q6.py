def get_all_combinations(str_list, num_list):
    
    result_list = []
    
    for a_str in str_list:
        for a_num in num_list:
            result_list.append((a_str, a_num))
            
    return result_list
    
def get_larger_numbers(num_list1, num_list2):
    
    result_list = []
    
    for num1 in num_list1:
        is_larger = True
        for num2 in num_list2:
            if num1 <= num2:
                is_larger = False
                
        if is_larger:
            result_list.append(num1)
    
    return result_list
    
def get_non_common_strings(str_list1, str_list2):
    result_list = []
    
    for str1 in str_list1:
        if str1 not in str_list2:
            result_list.append(str1)
    
    for str2 in str_list2:
        if str2 not in str_list1:
            result_list.append(str2)
    
    return result_list

r_list = get_all_combinations(["a", "b"], [1, 2, 3])
print("Expected: [('a', 1), ('a', 2), ('a', 3), ('b', 1), ('b', 2), ('b', 3)]")
print("Actual  : " + str(r_list))
print()

r_list = get_larger_numbers([4, 6, 10], [1, 3, 5])
print("Expected: [6, 10]")
print("Actual  : " + str(r_list))
print()

r_list = get_non_common_strings(["a", "b", "c", "d"], ["b", "d", "e", "f"])
print("Expected: ['a', 'c', 'e', 'f']")
print("Actual  : " + str(r_list))
print()