def calculate_meter_fare_based_on_rate(distance, distance_unit, rate):
    num_units = distance // distance_unit
    if (distance % distance_unit != 0):
        num_units += 1
    return rate * num_units

def prompt_for_rates_and_distance():
    flag_down = float(input("What's the flag-down fare: $"))
    rate_1 = float(input("What's the rate per 400 meters within 9.8km? $"))
    rate_2 = float(input("What's the rate per 350 meters beyond 9.8km? $"))
    distance = float(input("What's the distance traveled (in meters)? "))
    return (flag_down, rate_1, rate_2, distance)

def prompt_for_surcharge_info():
    peak_hour = input("Is the ride during a peak period? [yes/no] ")
    midnight = 'no'
    if peak_hour == 'no':
        midnight = input("Is the ride between midnight and 6am? [yes/no] ")
    location = input("Is there any location surcharge? [yes/no] ")
    location_surcharge = 0.0
    if location == 'yes':
        location_surcharge = float(input("What's the amount of location surcharge? $"))
    return(peak_hour == 'yes', midnight == 'yes', location_surcharge)

# The following is the main body of the program.
(flag_down, rate_1, rate_2, distance) = prompt_for_rates_and_distance()
    
meter_fare = flag_down
if distance > 9800:    
    meter_fare += calculate_meter_fare_based_on_rate(9800 - 1000, 400, rate_1) + calculate_meter_fare_based_on_rate(distance - 9800, 350, rate_2)
elif distance > 1000:
    meter_fare += calculate_meter_fare_based_on_rate(distance - 1000, 400, rate_1)   

(is_peak_ride, is_midnight_ride, location_surcharge_amount) = prompt_for_surcharge_info()

total = meter_fare

if is_peak_ride:
    total += meter_fare * 0.25
elif is_midnight_ride:
    total += meter_fare * 0.5

total += location_surcharge_amount

# We use the round() function to show two decimal places only.
print("The total fare is $" + str(round(total, 2)))