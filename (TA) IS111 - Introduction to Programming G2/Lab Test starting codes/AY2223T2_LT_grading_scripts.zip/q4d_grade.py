import sys


def run_test():
    print('########## TESTING Q4d ##########')
    # Test Cases
    test_cases = [
        (('beverage_preference_grade.txt', 'Grey Goose'), ('Alpha', 0.5), 0.5),
        (('beverage_preference_grade.txt', 'Lagavulin 12'), ('Delta', 0.5), 0.25),
        (('beverage_preference_grade.txt', 'Tiger'), (None, 0), 0.25),
    ]

    # ##########

    total_score = 0.0
    counter = 0

    try:
        from q4d import get_user_with_highest_rating

        for (params, expected_result, score) in test_cases:

            print(f'\nTest Case: get_user_with_highest_rating({", ".join(str(i) for i in params)})')

            try:
                result = get_user_with_highest_rating(params[0], params[1])

                print('Expected output:', expected_result)
                print('Actual output  :', result)

                if result == expected_result:
                    total_score += score
                    counter += 1
                    print("+" + str(score) + "/" + str(score)
                            + " marks")
                else:
                    print("+0.0/" + str(score) + " marks")

            except:
                print('Exception:', sys.exc_info())
                
    except:
        print('Exception:', sys.exc_info())


    total_score = round(total_score, 2)
    print('\nTotal Marks: ' + str(total_score) + " out of 1.0")

    return (counter, total_score)

if __name__ == "__main__":
    run_test()