import sys


def run_test():
    print('########## TESTING Q4b ##########')
    # Test Cases
    test_cases = [
        (('beverage_preference_grade.txt', 'GIN'), {'Alpha': [('The Botanist', 0.5)], 'Beta': [('Peddlers', 0.2)], 'Delta': [('The Botanist', 0.3)]}, 1),
        (('beverage_preference_grade.txt', 'BEER'), {}, 0.5),
        (('beverage_preference_grade.txt', ''), {}, 0.5),
    ]

    # ##########

    total_score = 0.0
    counter = 0

    try:
        from q4b import get_user_preferences_by_category

        for (params, expected_result, score) in test_cases:

            print(f'\nTest Case: get_user_preferences_by_category({", ".join(str(i) for i in params)})')

            try:
                result = get_user_preferences_by_category(params[0], params[1])

                print('Expected output:', expected_result)
                print('Actual output  :', result)

                if result == expected_result:
                    total_score += score
                    counter += 1
                    print("+" + str(score) + "/" + str(score)
                            + " marks")
                else:
                    print("+0.0/" + str(score) + " marks")

            except:
                print('Exception:', sys.exc_info())
                
    except:
        print('Exception:', sys.exc_info())


    total_score = round(total_score, 2)
    print('\nTotal Marks: ' + str(total_score) + " out of 2.0")

    return (counter, total_score)

if __name__ == "__main__":
    run_test()