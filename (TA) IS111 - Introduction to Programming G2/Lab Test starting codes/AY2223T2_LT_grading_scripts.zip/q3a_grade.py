import sys


def run_test():
    print('########## TESTING Q3a ##########')
    # Test Cases
    test_cases = [
        (
            ({
                100: (100.0, 1),
                200: (400.0, 2),
                300: (900.0, 3),
            },),
            {
                100: 100.0,
                200: 200.0,
                300: 300.0,
            },
            1
        ),
        (
            ({
                100: (100.5, 1),
                200: (201, 2),
                300: (200, 3),
            },),
            {
                100: 100.5,
                200: 100.5,
                300: 66.67,
            },
            1
        ),
    ]

    # ##########

    total_score = 0.0
    counter = 0

    try:
        from q3a import create_avg_income_per_person_dict

        for (params, expected_result, score) in test_cases:

            print(f'\nTest Case: create_avg_income_per_person_dict({", ".join(str(i) for i in params)})')


            try:
                result = create_avg_income_per_person_dict(params[0])

                print('Expected output:', expected_result)
                print('Actual output  :', result)

                if result == expected_result:
                    total_score += score
                    counter += 1
                    print("+" + str(score) + "/" + str(score)
                            + " marks")
                elif result == {k: int(v) for k, v in expected_result.items()}:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, rounded incomes to nearest int.")
                else:
                    print("+0.0/" + str(score) + " marks")

            except:
                print('Exception:', sys.exc_info())
                
    except:
        print('Exception:', sys.exc_info())


    total_score = round(total_score, 2)
    print('\nTotal Marks: ' + str(total_score) + " out of 2.0")

    return (counter, total_score)

if __name__ == "__main__":
    run_test()