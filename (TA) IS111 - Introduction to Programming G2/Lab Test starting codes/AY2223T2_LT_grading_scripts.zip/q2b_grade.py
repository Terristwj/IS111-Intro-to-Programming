import sys


def run_test():
    print('########## TESTING Q2b ##########')
    # Test Cases
    test_cases = [
        (([], 0), [0], 1),
        (([2, 3], 1), [1, 2, 3], 0.5),
        (([1, 3], 2), [1, 2, 3], 0.5),
        (([1, 2], 3), [1, 2, 3], 0.5),
        (([0, 1], -1), [-1, 0, 1], 0.5),
    ]
                
    # ##########

    total_score = 0.0
    counter = 0

    try:
        from q2b import insert_into_list

        for (params, expected_result, score) in test_cases:

            print(f'\nTest Case: insert_into_list({", ".join(str(i) for i in params)})')

            try:
                result = insert_into_list(params[0], params[1])

                print('Expected output:', expected_result)
                print('Actual output  :', result)

                if result == expected_result:
                    total_score += score
                    counter += 1
                    print("+" + str(score) + "/" + str(score)
                            + " marks")
                elif result == reversed(expected_result):
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, result in reversed order.")
                elif {*result} == {*expected_result}:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, inserted in wrong order.")
                else:
                    print("+0.0/" + str(score) + " marks")

            except:
                print('Exception:', sys.exc_info())
                
    except:
        print('Exception:', sys.exc_info())


    total_score = round(total_score, 2)
    print('\nTotal Marks: ' + str(total_score) + " out of 3.0")

    return (counter, total_score)

if __name__ == "__main__":
    run_test()