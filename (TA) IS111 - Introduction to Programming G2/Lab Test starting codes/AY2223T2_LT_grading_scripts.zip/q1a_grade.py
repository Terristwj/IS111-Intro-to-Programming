import sys


def run_test():
    print('########## TESTING Q1a ##########')
    # Test Cases
    test_cases = [
        ((100, 0.0, 0), 135.0, 1),
        ((100, 0.1, 0), 148.5, 1),
        ((100, 0.0, 10), 145.0, 1),
        ((100, 0.1, 10), 158.5, 1),
        ((100, 2.0, 10), 415.0, 1),   
    ]

    # ##########

    total_score = 0.0
    counter = 0

    try:
        from q1a import get_cif_in_sgd

        for (params, expected_result, score) in test_cases:

            print(f'\nTest Case: get_cif_in_sgd({", ".join(str(i) for i in params)})')

            try:
                result = get_cif_in_sgd(params[0], params[1], params[2])

                print('Expected output:', expected_result)
                print('Actual output  :', result)

                if result == expected_result:
                    total_score += score
                    counter += 1
                    print("+" + str(score) + "/" + str(score)
                            + " marks")
                elif result * 1.35 == expected_result:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, missed conversion from USD to SGD.")
                elif round(result , 2) == expected_result:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, did not round to 2 decimal places.")
                else:
                    print("+0.0/" + str(score) + " marks")

            except:
                print('Exception:', sys.exc_info())
                
    except:
        print('Exception:', sys.exc_info())


    total_score = round(total_score, 2)
    print('\nTotal Marks: ' + str(total_score) + " out of 5.0")

    return (counter, total_score)

if __name__ == "__main__":
    run_test()