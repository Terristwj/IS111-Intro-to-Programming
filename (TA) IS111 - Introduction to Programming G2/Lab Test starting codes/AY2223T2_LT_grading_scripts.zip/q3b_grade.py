import sys


def run_test():
    print('########## TESTING Q3b ##########')
    # Test Cases
    test_cases = [
        (
            ({
                1: (100, 1),
                2: (400, 2),
                3: (900, 3),
            }, 10),
            [],
            1
        ),
        (
            ({
                1: (100, 1),
                2: (400, 2),
                3: (900, 3),
            }, 200),
            [1],
            1
        ),        
    ]

    # ##########

    total_score = 0.0
    counter = 0

    try:
        from q3b import retrieve_low_income_households

        for (params, expected_result, score) in test_cases:

            print(f'\nTest Case: retrieve_low_income_households({", ".join(str(i) for i in params)})')

            try:
                result = retrieve_low_income_households(params[0], params[1])

                print('Expected output:', expected_result)
                print('Actual output  :', result)

                if result == expected_result:
                    total_score += score
                    counter += 1
                    print("+" + str(score) + "/" + str(score)
                            + " marks")
                elif retrieve_low_income_households(params[0], params[1] - 1) == expected_result:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, returned household with avg. income equal to query.")
                else:
                    print("+0.0/" + str(score) + " marks")

            except:
                print('Exception:', sys.exc_info())
                
    except:
        print('Exception:', sys.exc_info())


    total_score = round(total_score, 2)
    print('\nTotal Marks: ' + str(total_score) + " out of 2.0")

    return (counter, total_score)

if __name__ == "__main__":
    run_test()