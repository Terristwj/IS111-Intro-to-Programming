import sys


def run_test():
    print('########## TESTING Q5a ##########')
    # Test Cases
    test_cases = [
        (
            ('region_data_grade.txt',),
            {
                 '2021-01-01T12:00:00': [1, 2, 3, 4, 5],
                 '2021-01-01T13:00:00': [10, 20, 30, 40, 50],
                 '2021-02-02T12:00:00': [100, 200, 300, 400, 500],
            },
            2
        ),
    ]

    # ##########

    total_score = 0.0
    counter = 0

    try:
        from q5a import summarize_region_data

        for (params, expected_result, score) in test_cases:

            print(f'\nTest Case: summarize_region_data({", ".join(str(i) for i in params)})')

            try:
                result = summarize_region_data(params[0])

                print('Expected output:', expected_result)
                print('Actual output  :', result)

                if result == expected_result:
                    total_score += score
                    counter += 1
                    print("+" + str(score) + "/" + str(score)
                            + " marks")
                elif result == {k: [v[-1], *v[:-1]] for k, v in expected_result.items()}:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, skipped first drink in result.")
                else:
                    print("+0.0/" + str(score) + " marks")

            except:
                print('Exception:', sys.exc_info())
                
    except:
        print('Exception:', sys.exc_info())


    total_score = round(total_score, 2)
    print('\nTotal Marks: ' + str(total_score) + " out of 2.0")

    return (counter, total_score)

if __name__ == "__main__":
    run_test()