import sys


def run_test():
    print('########## TESTING Q2a ##########')
    # Test Cases
    test_cases = [
        ((1, 2), [1, 2], 0.5),
        ((2, 1), [1, 2], 0.5),
        ((-1, -2), [-2, -1], 0.5),
        ((1, -1), [-1, 1], 0.5),
    ]
                
    # ##########

    total_score = 0.0
    counter = 0

    try:
        from q2a import get_ordered_list

        for (params, expected_result, score) in test_cases:

            print(f'\nTest Case: get_ordered_list({", ".join(str(i) for i in params)})')

            try:
                result = get_ordered_list(params[0], params[1])

                print('Expected output:', expected_result)
                print('Actual output  :', result)

                if result == expected_result:
                    total_score += score
                    counter += 1
                    print("+" + str(score) + "/" + str(score)
                            + " marks")
                elif result == expected_result[0:1]:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, only returned first element.")
                elif result == expected_result[1:]:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, only returned last element.")
                elif result == [expected_result[0], expected_result[0]]:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, returned first element twice.")
                elif result == [expected_result[1], expected_result[1]]:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, returned last element twice.")
                elif result == reversed(expected_result):
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, result in reversed order.")
                else:
                    print("+0.0/" + str(score) + " marks")

            except:
                print('Exception:', sys.exc_info())
                
    except:
        print('Exception:', sys.exc_info())


    total_score = round(total_score, 2)
    print('\nTotal Marks: ' + str(total_score) + " out of 2.0")

    return (counter, total_score)

if __name__ == "__main__":
    run_test()