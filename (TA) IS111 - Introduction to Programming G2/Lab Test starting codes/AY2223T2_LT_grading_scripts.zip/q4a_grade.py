import sys


def run_test():
    print('########## TESTING Q4a ##########')
    # Test Cases
    test_cases = [
        (
            ('beverage_preference_grade.txt',),
            {
                'Alpha': [
                    ('Grey Goose', 'VODKA', 0.5),
                    ('The Botanist', 'GIN', 0.5),
                ],
                'Beta': [
                    ('Grey Goose', 'VODKA', 0.5),
                    ('Lagavulin 12', 'WHISKEY', 0.3),
                    ('Peddlers', 'GIN', 0.2),
                ],
                'Delta': [
                    ('Glenfiddich', 'WHISKEY', 0.2),
                    ('Lagavulin 12', 'WHISKEY', 0.5),
                    ('The Botanist', 'GIN', 0.3),
                ],
            },
            2
        ),
    ]

    # ##########

    total_score = 0.0
    counter = 0

    try:
        from q4a import read_file

        for (params, expected_result, score) in test_cases:

            print(f'\nTest Case: read_file({", ".join(str(i) for i in params)})')

            try:
                result = read_file(params[0])

                print('Expected output:', expected_result)
                print('Actual output  :', result)

                if result == expected_result:
                    total_score += score
                    counter += 1
                    print("+" + str(score) + "/" + str(score)
                            + " marks")
                elif result == {k: [(el[0], el[1], str(el[2])) for el in v] for k, v in expected_result.items()}:
                    total_score += round(score*0.75, 2)
                    counter += 0.5
                    print("+" + str(round(score*0.75, 2)) + "/" + str(score)
                              + " marks, wrong data type (str) for score.")
                elif result == {k: v[1:] for k, v in expected_result.items()}:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, skipped first drink in result.")
                elif result == {k: v[:-1] for k, v in expected_result.items()}:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, skipped last drink in result.")
                elif result == {k: [','.join(str(i) for i in el) for el in v] for k, v in expected_result.items()}:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, returned str instead of tuple.")
                else:
                    print("+0.0/" + str(score) + " marks")

            except:
                print('Exception:', sys.exc_info())
                
    except:
        print('Exception:', sys.exc_info())


    total_score = round(total_score, 2)
    print('\nTotal Marks: ' + str(total_score) + " out of 2.0")

    return (counter, total_score)

if __name__ == "__main__":
    run_test()