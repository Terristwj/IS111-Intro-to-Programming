import sys


def run_test():
    print('########## TESTING Q1b ##########')
    # Test Cases
    test_cases = [
        ((300.0, 2022), 300.0, 0.5),
        ((400.0, 2022), 400.0, 0.5),
        ((500.0, 2022), 535.0, 0.5),
        ((100.0, 2023), 108.0, 0.5),
        ((100.0, 2024), 109.0, 0.5),
        ((0.0, 2023), 0.0, 0.5),
    ]
                
    # ##########

    total_score = 0.0
    counter = 0

    try:
        from q1b import get_bill_with_gst

        for (params, expected_result, score) in test_cases:

            print(f'\nTest Case: get_bill_with_gst({", ".join(str(i) for i in params)})')

            try:
                result = get_bill_with_gst(params[0], params[1])

                print('Expected output:', expected_result)
                print('Actual output  :', result)

                if result == expected_result:
                    total_score += score
                    counter += 1
                    print("+" + str(score) + "/" + str(score)
                            + " marks")
                elif result * (1.07/1.00) == expected_result:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, wrong GST rate (applied 0%, should be 7%).")
                elif result * (1.08/1.00) == expected_result:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, wrong GST rate (applied 0%, should be 8%).")
                elif result * (1.09/1.00) == expected_result:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, wrong GST rate (applied 0%, should be 9%).")
                elif result * (1.00/1.07) == expected_result:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, wrong GST rate (applied 7%, should be 0%).")
                elif result * (1.08/1.07) == expected_result:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, wrong GST rate (applied 7%, should be 8%).")
                elif result * (1.09/1.07) == expected_result:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, wrong GST rate (applied 7%, should be 9%).")
                elif result * (1.00/1.08) == expected_result:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, wrong GST rate (applied 8%, should be 0%).")
                elif result * (1.07/1.08) == expected_result:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, wrong GST rate (applied 8%, should be 7%).")
                elif result * (1.09/1.08) == expected_result:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, wrong GST rate (applied 8%, should be 9%).")
                elif result * (1.00/1.09) == expected_result:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, wrong GST rate (applied 9%, should be 0%).")
                elif result * (1.07/1.09) == expected_result:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, wrong GST rate (applied 9%, should be 7%).")
                elif result * (1.08/1.09) == expected_result:
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, wrong GST rate (applied 9%, should be 8%).")
                else:
                    print("+0.0/" + str(score) + " marks")

            except:
                print('Exception:', sys.exc_info())
                
    except:
        print('Exception:', sys.exc_info())


    total_score = round(total_score, 2)
    print('\nTotal Marks: ' + str(total_score) + " out of 3.0")

    return (counter, total_score)

if __name__ == "__main__":
    run_test()