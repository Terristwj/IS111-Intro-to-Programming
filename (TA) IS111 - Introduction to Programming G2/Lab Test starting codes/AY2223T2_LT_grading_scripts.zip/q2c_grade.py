import sys


def run_test():
    print('########## TESTING Q2c ##########')
    # Test Cases
    test_cases = [
        (([],), [], 0.5),
        (([0],), [0], 0.5),
        (([1, 2, 3],), [1, 2, 3], 0.5),
        (([3, 2, 1],), [1, 2, 3], 0.5),
        (([10, 8, 6, 4, 2, 1, 3, 5, 7, 9],), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 0.5),
        (([1, 0, -1],), [-1, 0, 1], 0.5),
    ]

    # ##########

    total_score = 0.0
    counter = 0

    try:
        from q2c import return_ordered_ints

        for (params, expected_result, score) in test_cases:

            print(f'\nTest Case: return_ordered_ints({", ".join(str(i) for i in params)})')

            try:
                result = return_ordered_ints(params[0])

                print('Expected output:', expected_result)
                print('Actual output  :', result)

                if result == expected_result:
                    total_score += score
                    counter += 1
                    print("+" + str(score) + "/" + str(score)
                            + " marks")
                elif result == reversed(expected_result):
                    total_score += round(score/2, 2)
                    counter += 0.5
                    print("+" + str(round(score/2, 2)) + "/" + str(score)
                              + " marks, result in reversed order.")
                else:
                    print("+0.0/" + str(score) + " marks")

            except:
                print('Exception:', sys.exc_info())
                
    except:
        print('Exception:', sys.exc_info())


    total_score = round(total_score, 2)
    print('\nTotal Marks: ' + str(total_score) + " out of 3.0")

    return (counter, total_score)

if __name__ == "__main__":
    run_test()