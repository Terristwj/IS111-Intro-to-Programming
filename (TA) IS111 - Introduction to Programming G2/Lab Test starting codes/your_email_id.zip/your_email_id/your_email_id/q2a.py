# Name: 
# Email ID:

def get_ordered_list(int_1, int_2):

    # Modify the code below
    return None