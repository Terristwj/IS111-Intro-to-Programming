# Name: 
# Email ID:

def read_file(beverage_preference):

    # Modify the code below
    return None