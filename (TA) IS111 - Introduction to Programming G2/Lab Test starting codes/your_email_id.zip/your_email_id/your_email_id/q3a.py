# Name: 
# Email ID:

def create_avg_income_per_person_dict(a_dict):

    # Modify the code below
    return None