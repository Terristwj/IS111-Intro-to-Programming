# Name: 
# Email ID:

def get_bill_with_gst(cif_in_SGD, purchase_year):

    # Modify the code below
    return None