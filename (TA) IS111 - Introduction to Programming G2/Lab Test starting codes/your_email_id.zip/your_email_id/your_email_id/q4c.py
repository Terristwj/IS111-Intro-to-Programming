# Name: 
# Email ID:

def get_user_rating_for(beverage_preference, beverage):

    # Modify the code below
    return None