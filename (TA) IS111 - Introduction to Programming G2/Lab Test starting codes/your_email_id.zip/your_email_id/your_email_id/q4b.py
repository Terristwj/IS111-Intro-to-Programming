# Name: 
# Email ID:

from q4a import read_file

def get_user_preferences_by_category(beverage_preference, category):

    # Modify the code below
    return None