# Name: 
# Email ID:

def insert_into_list(ordered_list, new_int):

    # Modify the code below
    return None