# Name: 
# Email ID:

from q3a import create_avg_income_per_person_dict

def retrieve_low_income_households(income_dict, avg_income_per_person_across_all_households):

    # Modify the code below
    return None