# Name: 
# Email ID:

def get_cif_in_sgd(cost_in_usd, insurance_rate, freight_charges):

    # Modify the code below
    return cost_in_usd * insurance_rate + freight_charges