# Name: 
# Email ID:

def summarize_region_data(region_data):

    # Modify the code below
    return None