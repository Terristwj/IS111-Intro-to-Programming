# Name:
# Email ID:
def get_ppl_with_fever(ppl_list):

    # Modify the code below.
    return_list = []

    for person in ppl_list:
        average_temp = (sum(person[1]) / len(person[1]))
        if average_temp > 37.5:
            return_list.append(person[0])

    return return_list

