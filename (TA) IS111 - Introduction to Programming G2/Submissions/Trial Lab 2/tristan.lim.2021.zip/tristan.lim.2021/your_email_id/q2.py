# Name:
# Email ID:
def process_numbers(input_filename, output_filename):
    # Modify the code below.
    return_str = ''
    str_len = 0
    
    with open(input_filename, 'r') as file:
        for line in file:
            line_group = line.split("*")
            str_len = len(line_group)
            group_max = []
            largest_num = 0
            for indv_group in line_group:
                indv_group = indv_group.split(" ")
                # split into individual numbers
                for indv_num in indv_group:
                    
                    try:
                        indv_num = int(indv_num)
                        if indv_num > largest_num:
                            largest_num = indv_num
                    except:
                        largest_num = "NA"
                group_max.append(str(largest_num))
            # Mergingin the string
            return_str = "*".join(group_max)
            print(return_str)   
            with open(output_filename, 'w') as output_file:
                output_file.write(f'{str_len}: {return_str}')
                output_file.close()

    return None
    


