# Name: Natashia pek shi min
# Email ID:Natashiapek.2019
def create_email_dict(email_list):
    # Modify the code below.
    school = {}

    for email in email_list:
        email_split = email.split('@')
        email_id = email_split[0]
        email_school = email_split[1]
        if len(email_school) == 3:
            

        for email_id in email:
            name = email_id.split('.')
            


    return name
    

    
