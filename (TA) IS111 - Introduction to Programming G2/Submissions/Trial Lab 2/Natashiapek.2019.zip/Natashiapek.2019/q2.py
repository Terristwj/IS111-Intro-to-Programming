# Name: Natashia pek shi min
# Email ID:Natashiapek.2019
def process_numbers(input_filename, output_filename):
    # Modify the code below.

    with open(input_filename, 'r') as input_file:
        with open(output_filename, 'w') as output_file:
            for line in input_file:
                number_groups = line.split('*')
                output_file.write(str(len(number_groups)))
                for i in number_groups:
                    max_num = maximum(number_groups)
                    if max_num == 0:
                        output_file.write('NA')
                    else:
                        output_file.write(str(max_num)
