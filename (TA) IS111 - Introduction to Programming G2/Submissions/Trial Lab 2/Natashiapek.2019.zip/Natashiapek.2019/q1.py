# Name: Natashia Pek Shi Min
# Email ID: Natashiapek.2019
def get_ppl_with_fever(ppl_list):

    # Modify the code below.

    result = []

    for ppl in ppl_list: 
      name = ppl[0]
      temperatures = str(ppl[1])
      for i in temperatures:
        avg_temperature = sum(float(i))/len(int(i))
        if avg_temperature > 37.5:
              result.append[ppl]
    return result

