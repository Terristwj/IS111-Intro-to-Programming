# Name: Lim Jian Hao
# Email ID: jianhao.lim.2020
def is_student(email_type):
    valid_digits = "0123456789"
    is_student = False
    for char in email_type:
        if char in valid_digits:
            is_student = True
    
    return is_student

def has_school(domain):
    if domain == "smu.edu.sg":
        return False
    return True

def create_email_dict(email_list):
    output_dict = {}
    for email in email_list:
        type_of_email , domain = email.split("@")
        if (is_student(type_of_email) and has_school(domain)):
            school = domain.split(".")[0]
            year = type_of_email.split(".")[-1]
            school_year_key = school + "-" + year
            
            if school_year_key not in output_dict:
                output_dict[school_year_key] = [email]
            else:
                output_dict[school_year_key].append(email)
    return output_dict

    
