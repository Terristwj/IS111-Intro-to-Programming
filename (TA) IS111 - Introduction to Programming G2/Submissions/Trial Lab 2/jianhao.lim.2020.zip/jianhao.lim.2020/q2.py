# Name: Lim Jian Hao
# Email ID: jianhao.lim.2020
def process_numbers(input_filename, output_filename):
    
    output = ""
    with open(input_filename, 'r') as input_f:
        
        for line in input_f:
            groups_list = line.rstrip("\n").split("*")
            num_of_groups = len(groups_list)
            output += str(num_of_groups) + ": "
            for group in groups_list:
                
                if not (group):
                    output += "NA*"
                list_of_nums = group.split(" ")
                list_of_nums_int = []
                # convert every number string to an int
                for item in list_of_nums:
                    # if nothing, ignore
                    if (item):
                        list_of_nums_int.append(int(item))
                # if nothing, ignore    
                if (list_of_nums_int):
                    max_num = max(list_of_nums_int)
                    output += str(max_num) + "*"
            output = output[:-1]
            output += "\n"
        
        
    with open(output_filename, 'w') as output_f:
        output_f.write(output)
    


