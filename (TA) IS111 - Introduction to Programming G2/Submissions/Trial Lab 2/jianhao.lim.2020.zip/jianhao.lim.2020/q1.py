# Name: Lim Jian Hao
# Email ID: jianhao.lim.2020
def get_ppl_with_fever(ppl_list):

    if not (ppl_list):
        return []
    
    fever_list = []
    for person in ppl_list:
        total_temp = 0
        temp_list = person[1]
        for temp in temp_list:
            total_temp += temp
        ave_temp = total_temp / (len(temp_list))
        
        if (ave_temp) > 37.5:
            fever_list.append(person[0])
    
    return fever_list

