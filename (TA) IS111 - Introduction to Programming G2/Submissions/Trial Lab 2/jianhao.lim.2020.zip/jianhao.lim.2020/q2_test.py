from q2 import process_numbers

print("Test Case 1:")
print()

process_numbers("numbers-1.txt", "output-1.txt")
print("Please check whether the file 'output-1.txt' generated is the same as the file 'expected-output-1.txt' that we've provided.")

print()
print("Test Case 2:")
print()

process_numbers("numbers-2.txt", "output-2.txt")
print("Please check whether the file 'output-2.txt' generated is the same as the file 'expected-output-2.txt' that we've provided.")

print()
print("Test Case 3:")
print()

process_numbers("numbers-3.txt", "output-3.txt")
print("Please check whether the file 'output-3.txt' generated is the same as the file 'expected-output-3.txt' that we've provided.")
