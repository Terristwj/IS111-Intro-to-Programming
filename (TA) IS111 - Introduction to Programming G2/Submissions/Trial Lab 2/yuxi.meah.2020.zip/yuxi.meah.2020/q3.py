# Name: Meah Yuxi
# Email ID: yuxi.meah.2020
def create_email_dict(email_list):
    # Modify the code below.
    returndict = {}
    for item in email_list:
        column = item.split('@')    
    
    return returndict
    
    

    
