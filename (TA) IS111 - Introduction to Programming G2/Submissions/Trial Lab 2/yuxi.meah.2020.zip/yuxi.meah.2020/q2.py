# Name: Meah Yuxi
# Email ID: yuxi.meah.2020
def process_numbers(input_filename, output_filename):
    # Modify the code below.
    totalgroup = 0
    maxnumlist = []
    resultlist = ''
    with open(input_filename, 'r') as infile:
        #for every line
        for line in myfile:
            #split them up
            line = line.rstrip('\n')
            column = line.split('*')    
            #how cal how many column/totalgroup and separate them?
            
            totalgroup += 1
            
            #return maximum number for each group
            for i in group:
                maxnum = 0
                if i > maxnum:
                    maxnum = i
            maxnumlist.append(maxnum)
                

                
            resultlist = print(totalgroup + ": " + '*'.join(maxnumlist))
    return resultlist
    
    with open(output_filename,'w') as outfile:
        for line in resultlist:
        outfile.write(line + '\n')
    


