# Name: Meah Yuxi
# Email ID:yuxi.meah.2020
def get_ppl_with_fever(ppl_list):

    # Modify the code below.
    sickppl = []
    totaltemp = 0
    #for every list
    for i in ppl_list:
        #for temp in every tuple
        for ch in i[1]:   #did i sep out the temp?python
        #add temp tgt
            totaltemp += ch
            return totaltemp
        if totaltemp > 37.5:
            sickppl += i[0]
    return sickppl

