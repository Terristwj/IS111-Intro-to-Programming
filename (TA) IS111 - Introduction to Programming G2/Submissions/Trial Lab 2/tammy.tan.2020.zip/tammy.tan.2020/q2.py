# Name: Tan Jen, Tammy
# Email ID: tammy.tan.2020
def process_numbers(input_filename, output_filename):
    # Modify the code below.
    with open(input_filename, 'r') as i:
        numlist = "0123456789"
        for line in i:
            line = line.rstrip('\n')
            group = line.split('*')
            
            
            
            
            
            with open(output_filename, 'w') as q2_output:
                q2_output.write()
    


