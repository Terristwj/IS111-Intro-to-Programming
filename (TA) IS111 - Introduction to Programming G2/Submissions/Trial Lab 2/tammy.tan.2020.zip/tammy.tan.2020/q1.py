# Name: Tan Jen, Tammy
# Email ID: tammy.tan.2020
def get_ppl_with_fever(ppl_list):
    
    # Modify the code below.
    
    count = 0
    total_temp = 0
    
    if len(ppl_list) == 0:
        return []
    
    for tup_item in ppl_list:
        above_avg = []
        name = tup_item[0]
        temp = tup_item[1]
        
        
        for temperature in temp:
            
            total_temp += temperature
            count += 1
            avg_temp = total_temp / count
            
            if avg_temp < 37.5:
                return []
            
            else:
                above_avg.append(name)
                
        return above_avg
        
                    
            