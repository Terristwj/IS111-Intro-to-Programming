# Name: Tan Jen, Tammy
# Email ID: tammy.tan.2020
def create_email_dict(email_list):
    # Modify the code below.
    sch_dict = {}
    for address in email_list:
        for email in address:
            x = email.rstrip('@')
            year = email.lstrip('@')
            
            if len(x) < 10:
                sch_dict = {}
            # 10 characters for smu.edu.sg
            if len(x) > 10:
                school = x.lstrip(".")
                
                
    return sch_dict 
                            
            

    
