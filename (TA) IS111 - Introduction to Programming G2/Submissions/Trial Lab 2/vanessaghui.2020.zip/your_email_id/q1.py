# Name: Vanessa Ghui Yinn
# Email ID: vanessaghui.2020
def get_ppl_with_fever(ppl_list):

    # Modify the code below.
    sum_temp = 0
    count = 0
    count_people = 0 
    fever_list = []
    for people in ppl_list:
    	count_people += 1 

    	if count_people >= 1: 
    		for people in ppl_list:

    			for temp in people[1]:
    				sum_temp += temp 
    				count += 1

    			avg_temp = sum_temp / count 
    			if avg_temp > 37.5:
    				if people[0] not in fever_list:
    					fever_list.append(people[0])

    return fever_list






