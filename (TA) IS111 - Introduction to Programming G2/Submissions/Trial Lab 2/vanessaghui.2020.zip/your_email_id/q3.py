# Name: Vanessa Ghui Yinn
# Email ID: vanessaghui.2020

def check_student (email):
	email_split = email.split("@")
	email_id = email_split[0]
	year = email_id[-4:]
	count = 0 
	for num in year: 
		if num not in "0123456789":
			count += 1
	if count != 0:
		return False 

def check_if_smu (email):
	email_split = email.split("@")
	domain = email_split[1]
	if "smu.edu.sg" not in domain:
		return False
	else:
		return True



def create_email_dict(email_list):
    # Modify the code below.
    email_dict = {}
    sch_list = []

    for person in email_list:
    	if check_if_smu == True:
    		if check_student == True: 
    			split = person.split(".")
				trying = split[1]
				splitagain = trying.split("@")
				school = splitagain[1]
				year = splitagain[0]
				key = school + "-" + year 


    return None
    

    
