# Name: Vanessa Ghui Yinn
# Email ID: vanessaghui.2020
def process_numbers(input_filename, output_filename):
    # Modify the code below.

    with open (input_filename, "r") as input_file:
    	with open (output_filename, "w") as output_filename:
    		temp_list = []
    		count = 0
    		for line in input_file:
    			line = line.rstrip("\n")
    			group = line.split("*")
    			print (group)

    			
    			for count_group in group:
    				count += 1 
    				temp_list.append(count_group + "*")
    				

    			output_filename.write(str(count) + ": " + "\n")
    			output_filename.write(count_group)


    			


 
    


