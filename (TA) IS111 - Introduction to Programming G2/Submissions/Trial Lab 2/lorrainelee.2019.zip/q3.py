# Name: Lorraine Lee
# Email ID: lorrainelee.2019

def create_email_dict(email_list):
    # Modify the code below.
    dict_result = {}
    for email in email_list:
        id, domain = email.split('@')
        year = id[-4:]

        sch = domain[:domain.index('.')]
        sch_year = sch+'-'+year

        if year.isdigit() == True and sch != 'smu':
            if sch_year not in dict_result:
                dict_result[sch_year] = [email]
                
            else:
                dict_result[sch_year].append(email)
            

    return dict_result

    
