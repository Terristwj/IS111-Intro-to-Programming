# Name: Lorraine Lee
# Email ID: lorrainelee.2019

def get_ppl_with_fever(ppl_list):

    # Modify the code below.
    result = []
    for ppl in ppl_list:
        sum = 0
        count = 0
        for j in ppl[1]:
            sum += j
            count += 1
            
        avg_temp = sum/count
        if avg_temp > 37.5:
            result.append(ppl[0])

    return result
