def get_ppl_with_fever(ppl_list):

    # Modify the code below.
    result = []
    for ppl in ppl_list:
        sum = 0
        count = 0
        for j in ppl[1]:
            sum += j
            count += 1
            
        avg_temp = sum/count
        if avg_temp > 37.5:
            result.append(ppl[0])

    return result

print('Test Case 1:')
result = get_ppl_with_fever([('John', [37.6, 37.8]), ('George', [38.1, 37.2, 37.5]), ('Vivian', [36.7])])
print("Expected: ['John', 'George']")
print('Actual  : ' + str(result))

print("Expected type of returned value: <class 'list'>")
print('Actual type of returned value  : ' + str(type(result)))


print('\nTest Case 2:')
result = get_ppl_with_fever([])
print("Expected: []")
print('Actual  : ' + str(result))

print('\nTest Case 3:')
result = get_ppl_with_fever([('Gideon', [36.5, 36.7]), ('Mary', [37.6, 36.8, 36.9, 36.8])])
print("Expected: []")
print('Actual  : ' + str(result))