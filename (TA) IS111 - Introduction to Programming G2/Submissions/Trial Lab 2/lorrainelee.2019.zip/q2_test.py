from q2 import process_numbers

def process_numbers(input_filename, output_filename):
    # Modify the code below.
    with open(input_filename, 'r') as input_file:
        with open(output_filename, 'w') as open_file:

            result = []

            for line in input_file:
                line = line.rstrip('\n')
                columns = line.split('*')

                for i in columns:
                    num_list = i.split(' ')

                    max = -1000000000000
                    for i in num_list:
                        if i == '':
                            max = 'NA'
                        elif int(i) > max:
                            max = int(i)
                    result.append(max)

                
            write_list = []
            for i in result:
                write_list.append(str(i))

            line = '*'.join(write_list)
            open_file.write(line)
            open_file.write("\n")



# print("Test Case 1:")
# print()

# process_numbers("numbers-1.txt", "output-1.txt")
# print("Please check whether the file 'output-1.txt' generated is the same as the file 'expected-output-1.txt' that we've provided.")

print()
print("Test Case 2:")
print()

process_numbers("numbers-2.txt", "output-2.txt")
print("Please check whether the file 'output-2.txt' generated is the same as the file 'expected-output-2.txt' that we've provided.")

print()
# print("Test Case 3:")
# print()

# process_numbers("numbers-3.txt", "output-3.txt")
# print("Please check whether the file 'output-3.txt' generated is the same as the file 'expected-output-3.txt' that we've provided.")
