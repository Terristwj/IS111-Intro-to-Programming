# Name: Lorraine Lee
# Email ID: lorrainelee.2019

def process_numbers(input_filename, output_filename):
    # Modify the code below.
    with open(input_filename, 'r') as input_file:
        with open(output_filename, 'w') as open_file:
            num_list = []
            num_lines_list = []
            result = []

            for line in input_file:
                line = line.rstrip('\n')
                columns = line.split('*')

                for i in columns:
                    num_list = i.split(' ')

                    max = -1000000000000
                    for i in num_list:
                        if i == '':
                            max = max
                        elif int(i) > max:
                            max = int(i)
                    result.append(max)

                print(result)
                
                write_list = []
                for i in result:
                    write_list.append(str(i))

                line = '*'.join(write_list)
                open_file.write(line)
                open_file.write("\n")


