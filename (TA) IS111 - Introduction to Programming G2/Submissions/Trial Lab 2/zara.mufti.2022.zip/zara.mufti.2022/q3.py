# Name: Zara Mufti
# Email ID: zara.mufti.2022
def create_email_dict(email_list):
    # Modify the code below.
    #create a dict with schools
    #if schools not in email_list item -> pass
    for items in email_list:
    return None
    

    
