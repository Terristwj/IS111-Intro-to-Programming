# Name: Zara Mufti
# Email ID: zara.mufti.2022
def process_numbers(input_filename, output_filename):
    # Modify the code below.
    with open(input_filename, 'r') as my_file:
        with open (output_filename, 'w') as out_file:
            num_list = []
            my_list = []
            
            for line in my_file:
                line = line.rstrip('\n')
                num_list = line.split('*')

                for items in num_list:
                    my_list.append(items.split(" "))
                for items in my_list:
                    max_number = -1000000
                    
                    for i in range(len(items)):    
                        if items[i].isnumeric() == True:
                            
                            if items[i-1] =='-':
                                num = -1 * int(items[i])
                            else:
                                num = int(items[i])
                                            
                            if num > max_number:
                                max_number = num


                    out_file.write(str(max_number) + '*')
                    


