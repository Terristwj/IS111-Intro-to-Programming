# Name: Zara Mufti
# Email ID: zara.mufti.2022
def get_ppl_with_fever(ppl_list):
    count=0
    name_list = []
    for items in ppl_list:
        temp = 0
        count = 0
        for ch in items[1]:
            temp += ch
            count+=1
        average_temp = temp/ count 
        if average_temp > 37.5:
            name_list.append(items[0])

    return name_list

