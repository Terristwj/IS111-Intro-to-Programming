# Name: Gu Jiawen
# Email ID: jiawen.gu.2020

def add_first_odd_digits(str_list):

    # Modify the code below
    
def find_odd(my_string):
    for i in my_string:
        if i.isdigit() == True and int(i) % 2 != 0:
        return 0
    else:
        return int(i)


def add_first_odd_digits(str_list):
    result = 0 
    for element in string_list:
        result = result + int(i)

