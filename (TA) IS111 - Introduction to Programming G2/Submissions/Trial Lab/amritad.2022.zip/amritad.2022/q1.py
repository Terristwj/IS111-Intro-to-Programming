# Name: amrita
# Email ID: amritad.2022

def add_first_odd_digits(str_list):

    def add_first_odd_digits(str_list):
    sum_list = 0
    for string_ in str_list:
        a_string = string_.split()
        #print(a_string)
        
        for a in range(len(a_string)):
            
                if a_string[a] ==int and a_string[a]%2 == 1: 
                    sum_list= sum_list+ a_string[a]
        return sum_list
        
        
  