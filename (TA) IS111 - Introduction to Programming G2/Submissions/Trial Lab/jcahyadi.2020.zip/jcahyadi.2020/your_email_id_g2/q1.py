# Name: Jesica Cahyadi
# Email ID: 01415562

def add_first_odd_digits(str_list):
    




    # Modify the code below
    temp = 0
    integerstring = ''
    for x in str_list:
        if x.isdigit()==True: 
            integerstring += x

        for y in integerstring:
            if y % 2 == 1:
                temp += y
            break

        return temp
