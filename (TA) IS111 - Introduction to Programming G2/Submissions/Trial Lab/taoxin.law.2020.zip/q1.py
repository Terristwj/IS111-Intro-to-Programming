# Name: 
# Email ID:

def add_first_odd_digits(str_list):
    odd_digit='1 3 5 7 9'.split()
    result=[]
    for string in str_list:
        for ch in string:
            if ch in odd_digit:
                result.append(int(ch))
                break
        
        
            
    
    return sum(result)              
        

    