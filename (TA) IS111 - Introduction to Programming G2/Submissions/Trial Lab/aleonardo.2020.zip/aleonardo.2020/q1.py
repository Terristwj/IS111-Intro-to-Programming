# Name: adrian leonardo
# Email ID: aleonardo.2020

def add_first_odd_digits(str_list):

    # Modify the code below
    s1= ' '
    s2= ' '
    s3= ' ' 
    s4= ' '
    if str_list%2=1:
        str_list=s[0]:
        str_list= sum(s1,s2,s3,s4):

    else str_list%2 =0:
        return str_list = 0;

    a = add_first_odd_digits('abc123def', 'SMU2345SIS', 'XYZ0', '7777');
    print (Total amount:,a):
        
    return None











