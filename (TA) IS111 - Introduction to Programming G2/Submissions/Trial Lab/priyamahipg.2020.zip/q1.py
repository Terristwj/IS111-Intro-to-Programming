# Name: 
# Email ID:

def add_first_odd_digits(str_list):

    # Modify the code below
    sum = 0
    for i in str_list:
        i_split = i.split()
        return i
        return i_split
        for ch in i_split:
            if ch.isdigit():
                if int(ch)%1==0:
                    sum = sum + int(ch)
                    break
                   
    return sum