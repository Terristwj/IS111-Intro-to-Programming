from pathlib import Path
import zipfile

current_folder = Path('.').resolve()

# if solution folder has not renamed, ask for student's email id
email_id = current_folder.name
while email_id == 'your_email_id' or email_id == '':
    email_id = input('Please enter your email id (e.g., astudent.2022): ').strip()
    if len(email_id) == 0:
        print('Error: Please enter a valid email id!')

# create a zip archive in the current (i.e., solutions) folder
submission_file_path = current_folder.parent / f'{email_id}.zip'
with zipfile.ZipFile(submission_file_path, 'w') as archive:
    # place all solution python (*.py) files into the zip archive
    for input_file in Path('.').glob('*.py'):
        if input_file.name != Path(__file__).name:
            archive.write(input_file)

print(f'The following submission zip has been created: {submission_file_path}')