# Name: Adele Yap
# Email ID: adele.yap.2021@business.smu.edu.sg

def add_first_odd_digits(str_list):
    print (str_list)
    # function goes through all the strings in this list --> for loop 
    # function: looks for odd numbers and adds the first of digit in teach string and returns the sum 
    # if str_list has odd nums (1,2,3,4,5), add up sum of first odd digit in each list 
    if str_list['1','3','5','7','9']:
        result = sum(str_list)
        return result 
        
    # if no odd digit in the string, then dont add anything 
    #if str_list is empty --> return 0 
    if str_list():
      pass
    

    # Modify the code below
    return None




