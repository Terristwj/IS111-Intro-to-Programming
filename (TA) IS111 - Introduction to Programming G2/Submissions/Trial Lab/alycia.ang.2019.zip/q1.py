# Name: Ang Qi Qian Alycia
# Email ID: 01391639

def add_first_odd_digits(str_list):
    # Modify the code below
    for i in range(len(str_list)):
        if i == type(int):
            i.split("",1)
            if (i%2==1):
                return (i)
    else:        
        return None