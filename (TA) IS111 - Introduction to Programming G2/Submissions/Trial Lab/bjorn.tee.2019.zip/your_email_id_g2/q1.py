# Name: Bjorn Tee
# Email ID: bjorn.tee.2019@accountancy.smu.edu.sg

def add_first_odd_digits(str_list):


    # Modify the code below
def add_first_odd_digits(str_list):
    summation = 0
    if str_list == 0:
        return 0
    for odd in str_list:
        odd1 = odd.split()
        if odd1.find(1 or 3 or 5 or 7 or 9) == 1
            summation = summation + int(odd1)
            return summation
        