# Name: Li Qin Cheng
# Email ID: liqin.cheng.2020

def add_first_odd_digits(str_list):
    sum_of_odd_digits=0
    odd_number_string="13579"
    for index in range(len(str_list)):
        if odd_number_string in str_list[index]:
            odd_number_string[index.odd_number_string]+=sum_of_odd_digits
    return sum_of_odd_digits
              
    # Modify the code below
    return None