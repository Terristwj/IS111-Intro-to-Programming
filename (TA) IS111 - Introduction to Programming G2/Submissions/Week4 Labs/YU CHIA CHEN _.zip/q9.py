
user = input("Enter a message")

for i in range(0, len(user)):
    print(user[0:i+1])
    
