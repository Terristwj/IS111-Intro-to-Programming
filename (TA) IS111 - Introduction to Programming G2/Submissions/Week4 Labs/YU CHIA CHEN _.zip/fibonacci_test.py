import fibonacci

fibonacci.display_fibonacci(3)
fibonacci.display_fibonacci(5)
fibonacci.display_fibonacci(10)


def display_fibonacci(n):
    
    prev_prev_number = 1 
    prev_number = 1
    print("1 1 ", end='')
    
  
    for i in range(2, n):
        
        curr_number = prev_prev_number + prev_number
        print( str(curr_number) + ' ', end='')
        
        
        prev_prev_number = prev_number
        prev_number = curr_number
        
    print()