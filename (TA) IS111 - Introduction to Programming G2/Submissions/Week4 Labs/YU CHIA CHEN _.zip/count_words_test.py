import count_words

print(count_words.count_a('I have a room with a window, a desk and a chair.'))

print(count_words.count_an('Every day I have an egg, an apple and a banana for breakfast.'))


def count_a(text):
    count = 0
    text = ' ' + text + ' '
    for i in range(0, len(text)-2):
        if text[i]==' ' and text[i+1]=='a' and text[i+2]==' ':
            count += 1
    return count
    
def count_an(text):
    count = 0
    text = ' ' + text + ' '
    for i in range(0, len(text)-3):
        if text[i]==' ' and text[i+1]=='a' and text[i+2]=='n' and text[i+3]==' ':
            count += 1
    return count

