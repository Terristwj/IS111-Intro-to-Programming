message = input('Enter a message :')

for n in range(0, len(msg)):
    print(message[0:n+1])