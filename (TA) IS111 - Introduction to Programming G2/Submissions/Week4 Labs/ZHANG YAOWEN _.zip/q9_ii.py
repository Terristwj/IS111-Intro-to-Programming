message = input('Enter a message :')

for n in range(0, len(message)):
    i = len(message) - n
    print(message[0:i])