def count_a(text):
    count = 0
    text = ' ' + text + ' '
    for i in range(0, len(text)-2):
        if text[i]==' ' and text[i+1]=='a' and text[i+2]==' ':
            count = count + 1
    return count
    
    


def count_an(text):
    count = 0
    text = ' ' + text + ' '
    for i in range(0, len(text)-3):
        if text[i]==' ' and text[i+1]=='a' and text[i+2]=='n' and text[i+3]==' ':
            count = count + 1
    return count