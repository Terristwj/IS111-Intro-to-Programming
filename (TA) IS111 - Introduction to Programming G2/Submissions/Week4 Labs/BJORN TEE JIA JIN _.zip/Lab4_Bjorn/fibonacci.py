def display_fibonacci(n):
    number1 = 1
    number2 = 1
    print(str(number1) ,end =' ')
    print(str(number2) ,end = ' ')
    for ch in range(2,n):
        number3 = number2 + number1
        number1 = number2
        number2 = number3
        print(str(number3) + " ", end= '')