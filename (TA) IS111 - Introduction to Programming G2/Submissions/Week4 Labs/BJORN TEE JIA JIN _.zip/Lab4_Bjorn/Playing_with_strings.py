message = input("Enter a message :")
contain = ""
for ch in message:
    contain = contain + ch
    print (contain)
    


message2 = input("Enter a message :")
length = len(message2)
for ch in range(length):
    ab = message2[0:length-ch]
    print(ab)