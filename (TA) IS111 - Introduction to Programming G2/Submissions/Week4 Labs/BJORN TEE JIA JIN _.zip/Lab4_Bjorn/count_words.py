def count_a(text):
    no_a = 0
    text_split = text.split()
    for ch in text_split:
        if ch == 'a':
            no_a = no_a + 1
    return no_a


def count_an(text2):
    no_an = 0
    text_split2 = text2.split()
    for ch in text_split2:
        if ch == 'an':
            no_an = no_an + 1
    return no_an

    
    