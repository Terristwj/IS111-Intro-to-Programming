msg = input('Enter a message :')

for i in range(0, len(msg)):
    x = len(msg) - i
    print(msg[0:x])