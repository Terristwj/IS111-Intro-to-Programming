def count_a(sentence):

    sentence = ' ' + sentence + ' '
    words = 0

    for x in range(0, len(sentence)-2):
        if sentence[x] == ' ' and sentence[x + 1] = 'a' and sentence[x + 2] == ' ':
            words += 1
    return words

def count_an(text):
    sentence = ' ' + sentence + ' '
    words = 0
    for x in range(0, len(sentence)-2):
        if sentence[x] == ' ' and sentence[x + 1] == 'an' and sentence[x + 2]==' ':
            words += 1
    return words
        