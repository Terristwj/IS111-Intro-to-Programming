def display_fibonacci(n):
    sum = 0
    value = (1,0)
    for i in range(1,n+1):
        sum = value[0]+value[1]
        first = value[1]
        second = sum
        value = (first, second)
        print(value[1], end = " ")
        
    