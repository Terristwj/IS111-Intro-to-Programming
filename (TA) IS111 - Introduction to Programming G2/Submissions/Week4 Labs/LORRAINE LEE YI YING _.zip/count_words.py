# Q7

# word = "I have a room with a window, a desk and a chair."

def count_a(string):
    sum = 0
    for i in range(len(string)):
        if string[i] == " ":
            if string[i+1] == "a" and string[i+2] == " ":
                sum += 1
            
    return sum

# print(count_a(word))


# word = "Every day I have an egg, an apple and a banana for breakfast."

def count_an(string):
    sum = 0
    for i in range(len(string)):
        if string[i] == " ":
            if string[i+1:i+3] == "an" and string[i+3] == " ":
                sum += 1
    return sum
    
    
# print(count_an(word))



