#Q9 part i

word = input("Enter a message: ")

for i in range(len(word)+1):
    print(word[0:i])
    