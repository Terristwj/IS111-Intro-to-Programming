word = input("Enter a message: ")

for i in range(len(word)+1):
    if i == 0:
        print(word)
    else:
        print(word[:-i])