def display_fibonacci(n):
    one=0
    two=1
    print(two,end=" ")
    for n in range(1,n):
        next_num=one+two
        print(next_num,end=" ")
        one=two
        two=next_num
        
        
