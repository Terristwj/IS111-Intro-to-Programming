def count_a(message):
    num_a=0
    length=len(message)
    for n in range(length+1):
        if message[n:n+3]==" a ":
            num_a=num_a+1
    return num_a
    
    
def count_an(message):
    num_an=0
    length=len(message)
    for n in range(length+1):
        if message[n:n+4]==" an ":
            num_an=num_an+1
    return num_an