message=input("Enter a message :")
length=len(message)
for n in range(length):
    print(message[:n+1])
    
print()
print()
#part2    
message=input("Enter a message :")
length=len(message)
print(message)
for n in range(length):
    print(message[:-n-1])