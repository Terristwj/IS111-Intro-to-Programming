def count_a(msg):
    num_a = 0
    
    for ch in range(len(msg)):
        if msg[ch] == "a":
            if ch == 0:
                if msg[ch + 1] == " ":
                    num_a = num_a + 1
            elif ch == (len(msg) - 1):
                if msg[ch - 1] == " ":
                    num_a = num_a + 1
            else:
                if msg[ch - 1] == " " and msg[ch + 1] == " ":
                    num_a = num_a + 1
    
    return(num_a)

def count_an(msg):
    num_an = 0
    
    for ch in range(len(msg)):
        if msg[ch] == "a":
            if ch == 0:
                if msg[ch + 1] == "n":
                    if msg[ch + 2] == " ":
                        num_an = num_an + 1
     
            else:
                if msg[ch - 1] == " " and msg[ch + 1] == "n" and msg[ch + 2] == " ":
                    num_an = num_an + 1
    
    return (num_an)