msg = input("Enter a message :"）
for ch in range(len(msg)):
    print(msg[0:ch+1])