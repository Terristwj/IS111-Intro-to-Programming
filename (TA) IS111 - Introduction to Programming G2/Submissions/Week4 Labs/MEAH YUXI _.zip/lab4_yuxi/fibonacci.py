def display_fibonacci(input):
    num1 = 1
    num2 = 1
    final_num = ""

    for num in range(input):
        if num == 0:
            final_num = final_num + '1 '
        elif num == 1:
            final_num = final_num + '1 '
        else:
            num3 = num1 + num2
            final_num = final_num + str(num3) + " "
            temp1 = num1
            temp2 = num2
            num1 = temp2
            num2 = num3
    return(final_num)

        
print(display_fibonacci(10))