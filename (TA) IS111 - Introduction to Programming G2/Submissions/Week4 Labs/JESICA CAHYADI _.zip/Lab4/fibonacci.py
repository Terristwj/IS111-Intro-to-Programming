def display_fibonacci(n):
	a = 1
	b = 1
	if n >= 3: 
		print (a,b, end=' ')
		for x in range(3,n+1):
			c = a + b
			print (c, end= ' ')
			a = b
			b = c
		print("\n")
		