msg = input("Enter a message :")

def msg_triangle(msg):
	n = len(msg)
	#create a loop for the number of rows (n)
	for x in range(n,0,-1):
		#create a loop for the columns, ch change according to the row number
		for y in range(1, x+1):
			print(msg[y-1], end = '')
		print("\r")




msg_triangle(msg)