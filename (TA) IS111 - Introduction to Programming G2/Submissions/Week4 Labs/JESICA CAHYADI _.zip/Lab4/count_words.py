words = ''

def count_a(words):
	x = 0
	for i in range(len(words)-1):
		if words[i] == ' ' and words[i+1] == 'a' and words[i+2] == ' ':
			x += 1
	return x


def count_an(words):
	j = 0 
	for i in range(len(words)-1):
		if words[i] == ' ' and words[i+1] == 'a' and words[i+2] == 'n' and words[i+3] == ' ': 
			j += 1
	return j





