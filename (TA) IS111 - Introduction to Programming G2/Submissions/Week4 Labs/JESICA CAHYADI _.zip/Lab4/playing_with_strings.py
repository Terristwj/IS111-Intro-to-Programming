msg = input("Enter a message :")

def msg_triangle(msg):
	n = len(msg)
	#create a loop for the number of rows (n)
	for x in range(0,n):
		#create a loop for the columns, ch change according to the row number
		for y in range(0, x+1):
			print(msg[y], end = '')
		print("\r")




msg_triangle(msg)
