def display_fibonacci(n): 

	prev_no = 1
	prev_prev_no = 1
	print (prev_no, prev_prev_no, end = " ")


	for i in range(2, n):
		current_no = prev_no + prev_prev_no
		print (str(current_no), end = " ")

		prev_prev_no = prev_no
		prev_no = current_no




