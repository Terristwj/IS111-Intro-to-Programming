msg = input ("Enter a message :")

for ch in range(0,len(msg)):
	print (msg[0:ch+1])