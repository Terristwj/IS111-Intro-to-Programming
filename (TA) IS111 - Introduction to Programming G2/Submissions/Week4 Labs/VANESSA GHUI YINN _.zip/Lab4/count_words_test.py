import count_words


print(count_words.count_a('I have a room with a window, a desk and a chair.'))

print(count_words.count_an('Every day I have an egg, an apple and a banana for breakfast.'))