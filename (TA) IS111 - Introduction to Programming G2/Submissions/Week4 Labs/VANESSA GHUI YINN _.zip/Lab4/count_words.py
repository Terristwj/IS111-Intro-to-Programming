def count_a(msg):

	count = 0
	for ch in range(len(msg)-1):
		if msg[ch] == " " and msg[ch+1] == "a" and msg[ch+2] == " ":
			count += 1
		
	return count


def count_an(msg):
	count = 0
	for ch in range(len(msg)-1):
		if msg[ch] == " " and msg[ch+1] == "a" and msg[ch+2] and msg[ch+3] == " ":
			count += 1
		
	return count