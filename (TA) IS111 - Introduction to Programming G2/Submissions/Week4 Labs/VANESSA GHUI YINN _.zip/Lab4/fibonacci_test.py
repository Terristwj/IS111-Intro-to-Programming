import fibonacci

fibonacci.display_fibonacci(3)
fibonacci.display_fibonacci(5)
fibonacci.display_fibonacci(10)