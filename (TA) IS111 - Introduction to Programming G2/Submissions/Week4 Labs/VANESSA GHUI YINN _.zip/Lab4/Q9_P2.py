msg = input ("Enter a message :")

for ch in range(0,len(msg)):
	new_ch = len(msg) - ch
	print(msg[0:new_ch])