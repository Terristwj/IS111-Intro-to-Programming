def count_a(msg):
	count_a = 0

	msg = " " + msg + " "

	for i in range (0, len(msg)-2):
		if msg[i] == " " and msg[i+1] == "a" and msg[i +2] == " ":
			count_a += 1
	return count_a


def count_an(msg):
	count_an = 0
	len(msg)

	msg = " " + msg + " "

	for i in range (0, len(msg)-2):
		if msg[i]==' ' and msg[i+1]=='a' and msg[i+2]=='n' and msg[i+3]==' ':
			count_an += 1
	return count_an