def count_a(quote):
	split_quote = quote.split()
	a_count = 0
	for i in split_quote:
		if i == "a":
			a_count += 1
	return a_count

def count_an(quote):
	split_quote = quote.split()
	an_count = 0
	for x in split_quote:
		if quote == "an":
			an_count += 1
	return an_count
	
