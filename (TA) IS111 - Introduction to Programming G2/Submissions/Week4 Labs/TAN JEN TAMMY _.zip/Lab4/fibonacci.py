def display_fibonacci(x):
	previous = 0
	current = 0

	if x < 3:
		print("Error")
		return


	for i in range (0,x):
		if i == 0:
			print("1", end=" ")
		elif  i == 1:
			print("1", end=" ")
			previous = 1
			current = 1

		else:
			temp = current
			current = previous + current
			previous = temp

			print(current, end=" ")

	print()