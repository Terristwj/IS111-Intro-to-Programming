message = input("Enter a message :")
length = len(message)

for i in range(length):
	for x in range(i + 1):
		print(message[x], end="")
	print()