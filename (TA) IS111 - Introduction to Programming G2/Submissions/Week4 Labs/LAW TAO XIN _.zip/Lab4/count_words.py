def count_a(text):
    lst= text.split()
    count=0
    for item in lst:
        if item=='a':
            count+=1
    return count

def count_an(text):
    lst= text.split()
    count=0
    for item in lst:
        if item=='an':
            count+=1
    return count