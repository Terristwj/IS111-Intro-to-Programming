def display_fibonacci(n):
    first_num=1
    second_num=1
    print(first_num, end=' ')
    print(second_num, end=' ')
    for num in range(1,n-1):
        next_num= first_num+ second_num
        first_num= second_num
        second_num= next_num
        print(next_num, end=' ')