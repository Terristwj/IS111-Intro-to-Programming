def function1():
    message= input('Enter a message :')
    for n in range(len(message)+1):
        print(message[:n])

def function2():
    message= input('Enter a message :')
    for n in range(len(message),0,-1):
        print(message[:n])
        
function1()
function2()