def count_a(string):
	num_a = 0
	for i in range(len(string) - 2):
		if string[i:i+3] == " a ":
			num_a += 1
	return num_a


def count_an(string):
	num_an = 0 
	for i in range(len(string) - 3):
		if string[i:i+4] == ' an ':
			num_an += 1
	return num_an

