def count_a(text):
    #text.split(): split the words and arranges them in a list
    # Modify the code below to return the number of "a" occurrences.
    text_split = text.split()
    count = 0
    for i in range(0, len(text_split)):
        if text_split[i] == 'a':
            count += 1
    return count
    

def count_an(text):
   
    # Modify the code below to return the number of "an" occurrences.
    text_split = text.split()
    print( text_split)
    count = 0
    for i in range(0, len(text_split)):
        if text_split[i] == 'an':
            count += 1
    return count
   