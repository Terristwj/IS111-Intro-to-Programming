def display_fibonacci(n):
    # Modify the code below to print the first n Fibonacci numbers
    a = 1
    b = 1
    c = 2
    if n < 3:
        print('Please input an integer greater than or equal to 3')
    elif n == 3:
        print(a, b, c)
    else:
        print(a, b, c, end = ' ')
        for i in range(4, n+1):
            d = b + c
            b = c
            c = d 
            print(d, end = ' ')
        print()