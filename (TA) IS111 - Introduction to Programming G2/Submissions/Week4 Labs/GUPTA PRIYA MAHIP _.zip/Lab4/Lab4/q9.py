#Part 1
msg = input('Enter a message :')
length = len(msg)
x = 1
for i in msg:
    if x < length + 1:
        print(msg[:x])
        x += 1

#Part 2
msg = input('Enter a message :')
length = len(msg)
x = 0
for i in msg:
    if x < length:
        print(msg[:length])
        length -= 1