# Part I
message = input("Enter a message: ")
n = 1
for char in message:
    print(message[0:n])
    n += 1
    
# Part II 
message = input("Enter a message: ")
n = 0
for char in message:
    print(message[0:len(message)-n])
    n += 1