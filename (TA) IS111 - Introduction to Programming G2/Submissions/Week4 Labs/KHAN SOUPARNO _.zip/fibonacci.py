def display_fibonacci(n):
    print("1", end = ' ')
    x = 0
    x1 = 1
    x2 = x + x1
    for num in range(n-1):
        print(x2, end = ' ')
        x = x1
        x1 = x2
        x2 = x + x1
    print("\n")
