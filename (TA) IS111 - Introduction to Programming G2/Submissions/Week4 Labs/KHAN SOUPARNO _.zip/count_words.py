def count_a(text): 
    split_text = text.split()
    a = 0
    for char in split_text:
        if char == 'a':
            a += 1
    return a

def count_an(text):
    split_text = text.split()
    an = 0
    for char in split_text:
        if char == 'an':
            an += 1
    return an