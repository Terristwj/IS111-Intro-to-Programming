def count_a(string):
    a_count=0
    for i in range(len(string)):
        if string[i] =="a" and string[i+1]==' ' and string[i-1]==' ':
            a_count+=1
    return a_count

def count_an(string):
    an_count=0
    for i in range(len(string)):
        if string[i] =='a' and string[i+1]=='n' and string[i+2]==" ":
            an_count+=1
    
    return an_count

