def display_fibonacci(n):
    
    a= 1 
    b = 1
    print("1 1 ", end='')
    

    for i in range(2, n):
        anb = a + b
        print( str(curr_number) + ' ', end='')
        
=
        a = b
        b= anb
      
    print()