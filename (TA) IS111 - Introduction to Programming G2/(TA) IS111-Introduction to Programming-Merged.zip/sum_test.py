import sum_utility

my_sum = sum_utility.compute_sum(4, 10)
print("The sum of integers between 4 and 10 is " + str(my_sum))

my_sum = sum_utility.compute_sum(50, 100)
print("The sum of integers between 50 and 100 is " + str(my_sum))
